# Handoff: Wanderer (the card-questions tarot app)

Last updated: Wednesday, October 7, 2026. Read this first in any new chat about the app, then
`card-questions-foundation.md` (the design and the writing rules), then the latest batch file.

## What this is, in one paragraph

Wanderer is a tarot app for Seth's notebook practice, informed by astrology. Its job is to make it
easier to open the notebook and write, especially on days when no thoughts come. It runs entirely
on the phone as one HTML file: no accounts, no network, **no AI at runtime** (many people in
spiritual circles are against AI, and Seth wants it usable without a Claude subscription). The
heart of it is a hand-written, offline database of questions: what each card asks, per
orientation, per Celtic Cross position, colored by the day's planet and the planetary hour, with
plain-language lines for when the sky "lights" a card. It suits A Way of Living (AWOL) work
without being tied to it or naming it.

## Seth's guiding rules (keep these)

- **The one test:** does it make it easier to open the notebook and write?
- Tarot first; astrology only as context that makes a card specific to today. The full astrology
  interpretation was overwhelming and not explained enough to be worth it; don't bring it back
  to the front.
- Attention-span friendly: folded by default, expand only on request, one step at a time.
- Plain language. Every astrology term gets its own short explanation where it appears.
- No fate, sin, guilt, moralizing, cheesy exercises or elementary-style prompts. Curious, honest, kind.
- He works from an Android phone and uploads to GitHub Pages from it, so deliverables are single
  files he can upload directly (not zips he has to unpack).

## Where things stand

| Piece | Status |
|---|---|
| Design (`card-questions-foundation.md`) | Settled. Changes only if Seth asks. |
| Batch 1: The Fool to The Chariot (`batch-01-majors-0-7.md`) | Written: 8 cards, 296 pieces |
| Batch 2: Strength to Temperance (`batch-02-majors-8-14.md`) | Written: 7 cards, 259 pieces |
| Batch 3: The Devil to The World (`batch-03-majors-15-21.md`) | Written: 7 cards, 258 pieces |
| Batch 4: Wands, Ace to Seven (`batch-04-wands-ace-7.md`) | Written: 7 cards, 254 pieces |
| Batch 5: Wands, Eight to King (`batch-05-wands-8-king.md`) | Written: 7 cards, first in the card-specific style |
| Batch 6: Cups, Ace to Seven (`batch-06-cups-ace-7.md`) | Written: 7 cards |
| Batch 7: Cups, Eight to King (`batch-07-cups-8-king.md`) | Written: 7 cards |
| Batch 8: Swords, Ace to Seven (`batch-08-swords-ace-7.md`) | Written: 7 cards |
| Batch 9: Swords, Eight to King (`batch-09-swords-8-king.md`) | Written: 7 cards |
| Batch 10: Pentacles, Ace to Seven (`batch-10-pentacles-ace-7.md`) | Written: 7 cards |
| Batch 11: Pentacles, Nine to King (`batch-11-pentacles-9-king.md`) | Written: 6 cards (the Eight was the template) |
| Eight of Pentacles (worked template inside the foundation file) | Written; built into the app |
| The read-through | Done (v2.4.0): stock frames rewritten deck-wide, repeat check clean |
| App v2.4.0 (`index.html` + optional `sw.js`) | All 78 cards, read-through applied; day and hour panels on the Clock; hour line only above questions, planets named in lit lines, Essence phrases in pair prompts and ladder |
| Source (`Wanderer-source.zip`) | Current; includes this file, the batches and the fonts |

**Next step:** the app is content-complete (v2.4.0). Wait for Seth to use it and react. Open
options: (a) vary the remaining position-naming openings ("Who around me is" 68×, "What do I
hope" 68×, "What am I deliberately" 32×, "Where am I the" 32×), about 200 questions, only if he
finds them samey in use; (b) Seth reads through in his own voice; (c) the deferred items below.

Read-through done Oct 8, 2026 (v2.4.0): rewrote 217 stock-frame questions in batches 1–4 and the
Eight of Pentacles, plus 80 more ("What would I dread about…", "What's coming that will ask me
to…") that had crept into batches 4–11. Zero stock frames left. Whole-deck near-repeat check
(rapidfuzz ratio ≥ 84 over all 2,652 questions and cues) finds none; the 80–83 band is pairs that
share a position's shape but say different things. Use `rapidfuzz.process.cdist` for this check;
plain difflib over the whole deck takes too long.

Oct 8, 2026 (v2.2.0): Seth asked for the day and the hour on the Clock to open like the cards
(Write/Read, an escalating ladder, back buttons on every step). Built: tappable day and hour on
the Clock open sheets (`src/planets.jsx`), content in `content/planets-days-hours.md` → 
`assets/planets.json` (7 planets × 4 day questions + 3 hour questions, a 5-step day ladder, a
4-step hour ladder, Read notes). Shared `Steps` ladder in `cards.jsx` now gives every step a
back button, and every open Write/Read view a "← Back to Write or Read". Seth: "This is edging
toward AWOL, but that's okay. It's more to help you write or read."

Plan agreed Oct 7, 2026 (Seth chose the recommendation): make everything as card-specific as
possible. Done this session: day line dropped from above questions (kept on the Clock); lit
lines name the actual planet; Essence phrases feed the pair prompts and ladder rung 4; all 30
earlier cards retrofitted with Essence and planet-naming lit lines. Still to do: rewrite the
stock frames in batches 1–4 (about 200 questions), folded into the read-through.

Session notes (Oct 7, 2026):
- Batches 2–11 written and built (v2.3.0): all 78 cards. The "drawing from the cards written so
  far" note and the whole-deck setting now hide themselves, since every card is written.
- Decan-card lit lines name the slice in plain words: "this card's slice of the sky (the first ten
  degrees of Aries)". Batch 4 also started varying the reversed Root opening ("What put out an early
  fire in me…", "Who taught me to stay inside the walls…"); keep doing that.
- The word "aspect" now carries its plain-language gloss everywhere it appears: "(a meaningful
  angle to one of the planets you were born with)", in batch 1, the Eight of Pentacles template,
  the generic line in `src/content.js` and batches 2–3. Keep using that gloss in later batches.
- For the read-through: two positions reuse one sentence frame from card to card. Reversed Root
  questions mostly read "Where did I learn …, and how much of this grows from that?", and Outcome
  questions read "If I keep …, where does it lead, and which thought or fear would I change …"
  (the lever). These are repeats within a position, not pairs. Across 78 cards they may feel
  samey; consider varying them. (The pairs stay as designed: Root ↔ Who you are, Front of mind ↔
  Hopes / fears, Coming in ↔ What surrounds you, Cross / boon bridging Passing away → Coming in.)

## The design in brief (details in the foundation file)

**Per card (about 38 hand-written pieces):**
- 20 questions: upright and reversed × the 10 Celtic Cross positions.
- 14 watch-for cues: upright and reversed × the 7 day rulers (Sun, Moon, Mars, Mercury, Jupiter,
  Venus, Saturn). Used on the day's card, so the same card asks different things on different weekdays.
- A low-tide pointer: one detail to *Notice* and one figure (or object) to *Become*.
- Lit lines for each way the card can be lit that applies to it.
- Essence: a short phrase upright, one reversed, and a figure (used in the pair prompts and in
  ladder rung 4, "Where have you been ___ lately?").

**Shared lines (written once, in `src/content.js`):** 7 day lines (shown on the Clock only), 7 hour
lines (how to answer; the only line above a question), the 5-rung ladder and its floor, 16 pair
prompts (filled with each card's name and Essence phrase), planet lines, generic lit lines for
cards not yet written.

**Seth's Celtic Cross, in order:** 1 Central theme · 2 Cross / boon (obstacle or help; the bridge
from 4 to 6) · 3 Root · 4 Passing away · 5 Front of mind (conscious direction, what he's
manifesting) · 6 Coming in · 7 Who you are · 8 What surrounds you · 9 Hopes / fears (back of mind)
· 10 Outcome. Pairs: 5↔9, 6↔8, 3↔7; 2 bridges 4→6; 5 + 9 → 10 are the levers for steering the
outcome, so every Outcome question ends with a lever. One card uses position 1; three cards use
4, 1, 6 as past, present, future.

**Ways a card is lit** (show at most two): Yours (natal planet in its degrees, or for planet cards,
its planet rules the rising or Sun sign or sits on an angle) · Touching you (its planet aspects the
birth chart) · Its season (Sun in its degrees) · Today's weather (Moon, Mercury, Venus or Mars there)
· The long season (Jupiter to Pluto there) · Turning (its planet retrograde). Which kinds each
card type gets is in the foundation file. Aces and Pages: Its season only.

**The ladder** (under every question, behind *Nothing coming?*, one step visible at a time):
1 Look (Visual Thinking Strategies) · 2 Become (picture-story method from the Thematic
Apperception Test, used as a writing starter) · 3 Lend them your feeling ("If they were feeling
what you're feeling, what would they do next? What would happen after they do that?", Seth's own
line) · 4 Bring it home · 5 Compare with the card's meaning, which stays hidden until this rung
("not connected at all is fine"). Floor: date, planet and card name; copy the question; one word;
close the notebook.

**Write or Read:** every card opens folded with two choices. Write = hour line + question + why
it's lit + ladder. Read = meaning, why it's lit, its piece of the sky, the watch-for cue on the day's card, and
a quiet "Want one question to carry?". In a spread the choice is made once and remembered for the
day only (no streaks).

## The app (v2)

- **Clock tab, opens first, one screen, never scrolls:** a 24-hour dial (midnight at the bottom,
  noon at the top, so the Sun rises on the left like the chart) ringed by today's planetary hours,
  the current sky inside with the Ascendant on the left, a hand at the current time. Below: the
  day's planet and hour, and the day's card with its watch-for cue; tap it for the card sheet.
- **The day's card** is seeded by name + the planetary day (it changes at **sunrise**, not
  midnight) + location rounded to 0.1° (about a town).
- **Cards tab:** one, three or Celtic Cross; Write/Read; pair prompts after a Celtic Cross in
  Write mode, "the shape of the spread" in Read mode. Until all batches exist, draws come from the
  written cards only, topped up from the deck when a spread needs more (Settings can switch to the
  whole deck; unwritten cards show their AWOL meaning's plain ask with a note).
- **People tab:** the birthday list (unknown birth time → sunrise chart). Birth chart and Compare
  (synastry, composite, Davison) are one tap deep, as reference only.
- **Settings:** current location, reversals, whole-deck toggle, house system, export/import
  people, USNO accuracy check. The optional Claude reading from v1 was removed.
- Accuracy: Swiss Ephemeris (WebAssembly) with the JPL-derived `.se1` files; sunrise, sunset and
  hours follow the USNO definition and are checked against published USNO times in-app.

## How to rebuild (sandbox state does not survive between chats)

The working copy was lost once already; always rebuild from the zips and always ship an updated
`Wanderer-source.zip` at the end of a session.

Needs: `Wanderer-source.zip` (this project) and `Astro-Tarot.zip` (for `ephe/*.se1` and the
78 card images in `cards/`).

```
unzip Wanderer-source.zip && unzip Astro-Tarot.zip      # side by side
cd wanderer-source
npm install                                             # @swisseph/browser 1.4.0, react 18, esbuild
cp node_modules/@swisseph/browser/dist/swisseph.wasm assets/
pip install brotli --break-system-packages              # only if regenerating fonts
python3 parse_cards.py                                  # content/*.md -> assets/questions.json
EPHE=../astro-tarot/ephe CARDS=../astro-tarot/cards python3 build.py 2.4.0   # -> dist/
python3 single.py                                       # -> dist-single/index.html + sw.js
```

- Fonts are prebuilt in `build/*.woff2`. To regenerate, subset `astro-tarot/awolstyle/fonts`
  (EB Garamond Regular/Italic/SemiBold, FreeSerif for the glyphs) with `pyftsubset --flavor=woff2`.
- Bump the version passed to `build.py` each release so installed copies refresh.
- New batches go in `content/` named `batch-NN-....md`. Card names must match
  `assets/meanings.json` exactly ("The Fool", "Eight of Pentacles"). `parse_cards.py` refuses a
  card missing any of its 10+10 questions, 7+7 cues, Notice/Become, Essence (Upright/Reversed/Figure),
  with an unknown lit kind, or with a weather/long-season line lacking {planet}.
- Test in headless Chromium (Playwright is installed) at 412×915, 412×740 and 412×640, light and
  dark: no console errors, and the Clock page's scroll height must equal the viewport.

**Source map:** `planets.jsx` day/hour panels · `engine.js` astronomy (incl. `planetaryDay`) · `tarot.js` card sky signatures,
seeded draw with pool top-up, `litKinds` · `content.js` shared lines · `cards.jsx` CardPanel,
ladder, pair prompts · `clock.jsx` the dial · `App.jsx` tabs, day's card, settings ·
`reference.jsx` chart and compare views (from v1) · `widgets.jsx`, `text.js` v1 helpers used by
the reference views.

## Batch plan

1. ~~Majors 0–7: The Fool to The Chariot~~ (done)
2. ~~Majors 8–14: Strength to Temperance~~ (done)
3. ~~Majors 15–21: The Devil to The World~~ (done)
4. ~~Wands, Ace–Seven~~ (done)
5. ~~Wands, Eight–King~~ (done)
6. ~~Cups, Ace–Seven~~ (done)
7. ~~Cups, Eight–King~~ (done)
8. ~~Swords, Ace–Seven~~ (done)
9. ~~Swords, Eight–King~~ (done)
10. ~~Pentacles, Ace–Seven~~ (done)
11. ~~Pentacles, Eight–King~~ (done)
12. ~~Read-through of all 1,560 questions for repeats, tone and pairings; final build~~ (done)

Write each card fully in one pass (questions, cues, low tide, lit lines) so it gets its own
attention. Questions start from something you can point to before asking what it means.

## Open threads

- Seth hasn't given detailed reactions to batch 1 or the app yet; he said to continue with batches 2–11, and needs to see it working to form an opinion.
- The questions are drafted by Claude. If that matters to the people he shares it with, he may
  edit them into his own voice (the read-through is the natural place) and decide what the README says.
- "Wanderer" is a placeholder name.
- Deferred: an AWOL-style PDF export from the app; syncing people across devices.

## Related, separate from the app

- **Astro-Tarot toolkit** (`Astro-Tarot.zip`, Python, run inside Claude chats): makes Seth's
  AWOL-style PDF readings. Upgraded this session: USNO-accurate sunrise and planetary hours
  (`scripts/validate.py`), sunrise charts for unknown birth times, saved people and synastry
  (`run_reading.py people`, `synastry`), and `references/astrology_deep_guide.md`. Seth's standing
  preference for readings run there: a PDF formatted like the A Way of Living book, every
  astrology term explained in plain words, with what each card, transit, feast and hour asks
  gathered in the synthesis.
