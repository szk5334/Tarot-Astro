# Wanderer

A tarot app for the notebook, informed by astrology. Free software under the GNU AGPL v3.
No accounts, no AI: everything is written in advance and runs on the phone, online or not.

- **Clock:** the sky clock on one screen: today's planetary hours around the dial, the sky right
  now inside it, the day's planet and hour (tap either for its own questions
  or reading), and your card of the day with what to watch for.
- **Cards:** one card, three cards or a Celtic Cross. Choose *Write* (a question for the page,
  with a line from the hour and a cue for what to watch for today) or *Read* (the meaning, nothing asked). When
  nothing is coming, a five-step ladder starts from the picture itself.
- **People:** saved birthdays; anyone can be the one the clock and cards are for. Birth charts
  and comparisons live here as reference.

## Time and shuffling

Clock times show in the phone's own time zone. When online, the app checks the phone's clock
against internet time servers that follow the atomic clocks (timeapi.io, worldtimeapi.org and the
site's own server) and corrects it if it's off. Each shuffle hashes in quantum noise from the
LfD QRNG (Hamburg) and the ANU QRNG (Canberra) together with the phone's own secure randomness, so
a source that doesn't answer never makes a draw less random. Settings can turn both off; nothing
about you is sent.

## Install on Android

Open the page in Chrome, then menu ⋮ → *Install app*.

## Publish on GitHub Pages

This single index.html is the whole app. Put it at the top of a repository, then Settings → Pages →
Deploy from a branch → main, / (root). Add the optional sw.js beside it to let the installed app
open with no connection.

## Accuracy

Planet positions: the Swiss Ephemeris (Astrodienst) reading NASA JPL's DE431 ephemeris. Sunrise,
sunset and planetary hours: the U.S. Naval Observatory definition. Settings → Accuracy re-checks
against published USNO times on the device.

## Credits

Swiss Ephemeris © Astrodienst AG (AGPL). Card meanings: original paraphrases, informed by Rachel Pollack, *Seventy-Eight Degrees of
Wisdom*.
Rider–Waite–Smith deck, 1909 (public domain). EB Garamond (OFL), GNU FreeSerif. Town list: GeoNames (CC BY 4.0).
