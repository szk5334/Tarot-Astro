# Wanderer

A tarot app for the notebook, informed by astrology. Free software under the GNU AGPL v3.
No accounts, no network, no AI: everything is written in advance and runs on the phone.

- **Clock:** the sky clock on one screen: today's planetary hours around the dial, the sky right
  now inside it, the day's planet and hour, and your card of the day with what to watch for.
- **Cards:** one card, three cards or a Celtic Cross. Choose *Write* (a question for the page,
  colored by the day's planet and the hour's) or *Read* (the meaning, nothing asked). When
  nothing is coming, a five-step ladder starts from the picture itself.
- **People:** saved birthdays; anyone can be the one the clock and cards are for. Birth charts
  and comparisons live here as reference.

## Install on Android

Open the page in Chrome, then menu ⋮ → *Install app*.

## Publish on GitHub Pages

This single index.html is the whole app. Put it at the top of a repository, then Settings → Pages →
Deploy from a branch → main, / (root). Add the optional sw.js beside it to let the installed app
open with no connection.

## Accuracy

Planet positions: the Swiss Ephemeris (Astrodienst) reading NASA JPL's DE431 ephemeris. Sunrise,
sunset and planetary hours: the U.S. Naval Observatory definition. Settings → Accuracy re-checks
against published USNO times on the device.

## Credits

Swiss Ephemeris © Astrodienst AG (AGPL). Card meanings written for the AWOL Almanac.
Rider–Waite–Smith deck, 1909 (public domain). EB Garamond (OFL), GNU FreeSerif. Town list: GeoNames (CC BY 4.0).
