import React, { useState } from 'react';
import * as T from './tarot.js';
import * as K from './content.js';
import { G } from './widgets.jsx';

const Q = K.QUESTIONS;
export const written = id => !!Q[id];
export const WRITTEN_IDS = Object.keys(Q).map(Number);
const lower = s => s.charAt(0).toLowerCase() + s.slice(1);

export function questionFor(id, reversed, pos) {
  const c = Q[id];
  if (c) return c[reversed ? 'rev' : 'up'][pos - 1];
  return T.cardAsk(id, reversed);
}
export function watchFor(id, reversed, dayRuler) {
  const c = Q[id];
  if (c) return c.watch[reversed ? 'rev' : 'up'][dayRuler];
  const card = T.CARDS[id];
  return `Watch for ${card.keywords[0]}${reversed ? ' getting stuck or overdone' : ''} today, and for signs of ${dayRuler}: ${K.DAY_TOWARD[dayRuler]}.`;
}
// The lit kinds this card can show (its own written lines, or the generic ones for unwritten cards).
// {planet} and {is} in a lit line become the planets that are actually there ("Mars is", "the Moon and Venus are").
const PNAME = p => (p === 'Sun' || p === 'Moon' ? `the ${p}` : p);
export function fillPlanets(text, planets) {
  const names = planets.map(PNAME);
  const list = names.length < 2 ? (names[0] || 'a planet') : `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
  const out = text.replace(/\{planet\}/g, list).replace(/\{is\}/g, names.length > 1 ? 'are' : 'is');
  return out.charAt(0).toUpperCase() + out.slice(1);
}
export function litLines(id, lit) {
  const own = Q[id]?.lit;
  return lit.filter(l => !own || own[l.kind]).slice(0, 2).map(l => ({ ...l, text: fillPlanets(own ? own[l.kind] : K.GENERIC_LIT[l.kind], l.planets) }));
}

export function ModeButtons({ mode, setMode }) {
  return (
    <div className="mode" role="group" aria-label="Write or read">
      <button className={mode === 'write' ? 'on' : ''} aria-pressed={mode === 'write'} onClick={() => setMode(mode === 'write' ? null : 'write')}><b>Write</b><span>a question for the page</span></button>
      <button className={mode === 'read' ? 'on' : ''} aria-pressed={mode === 'read'} onClick={() => setMode(mode === 'read' ? null : 'read')}><b>Read</b><span>the meaning, nothing asked</span></button>
    </div>
  );
}

// "Back" from an open Write or Read view to the folded choice.
export const BackToChoice = ({ onBack }) => <button className="link quiet back" onClick={onBack}>← Back to Write or Read</button>;

// The low-energy ladder under a question: one step visible at a time, each step a little more
// than the last. Every step can go back one, and the first goes back to the question.
// rungs: [{ name, text, extra? }]; floor: lines for "Not even that?"
export function Steps({ rungs, floor, opener = 'Nothing coming?' }) {
  const [rung, setRung] = useState(0);
  const [atFloor, setFloor] = useState(false);
  if (atFloor) return (
    <div className="rung floor">
      <p className="rung-name">Not even that? That's fine.</p>
      <ol>{floor.map((f, i) => <li key={i}>{f}</li>)}</ol>
      <div className="row gap">
        <button className="link quiet" onClick={() => setFloor(false)}>← Back a step</button>
        <button className="link quiet" onClick={() => { setFloor(false); setRung(0); }}>Back to the question</button>
      </div>
    </div>
  );
  if (!rung) return <button className="link quiet" onClick={() => setRung(1)}>{opener}</button>;
  const L = rungs[rung - 1], n = rungs.length;
  return (
    <div className="rung">
      <p className="rung-name">Step {rung} of {n} · {L.name}</p>
      <p>{L.text}</p>
      {L.extra}
      <div className="row gap">
        {rung < n && <button className="link" onClick={() => setRung(rung + 1)}>One more step</button>}
        {rung === 1 && <button className="link quiet" onClick={() => setFloor(true)}>Not even that?</button>}
        <button className="link quiet" onClick={() => setRung(rung - 1)}>{rung === 1 ? '← Back to the question' : '← Back a step'}</button>
      </div>
    </div>
  );
}

function Ladder({ id, question }) {
  const c = Q[id] || {};
  const card = T.CARDS[id];
  const rungs = K.LADDER.map((L, i) => ({
    name: L.name, text: L.text(c),
    extra: i === 4 ? <div className="meaning"><p className="kw">{card.keywords.join(', ')}</p><p>{card[question.reversed ? 'reversed' : 'upright']}</p></div> : null,
  }));
  return <Steps rungs={rungs} floor={K.FLOOR} />;
}

// Only the hour's line sits above a question: it says how to answer. (The day's planet already
// shapes each card's own watch-for cue, so its general line stays on the Clock.)
export function DayHour({ ctx }) {
  const { hourRuler } = ctx;
  if (!hourRuler) return null;
  return <p className="dayhour"><span><G p={hourRuler} /> {hourRuler}'s hour: {lower(K.HOUR_LINE[hourRuler])}</span></p>;
}

// One card, folded until you choose to write or read.
export function CardPanel({ c, slot, spreadMode, ctx, daily = false, dayHour = true }) {
  const [own, setOwn] = useState(undefined);
  const [carry, setCarry] = useState(false);
  const mode = own === undefined ? spreadMode : own;
  const card = T.CARDS[c.id];
  const pos = K.POSITIONS[slot.pos - 1];
  const lit = litLines(c.id, T.litKinds(c.id, ctx.natal, ctx.sky, ctx.transits));
  const q = questionFor(c.id, c.reversed, slot.pos);
  const sig = T.signature(c.id);
  const { dayRuler, hourRuler } = ctx;
  return (
    <article className="cp">
      <div className="cp-head">
        <img src={window.__CARD(c.id)} alt={card.name} className={c.reversed ? 'rev' : ''} />
        <div>
          {!daily && <p className="pos-name">{slot.label}{slot.label !== pos.label ? ` · ${pos.label}` : ''}<span className="muted"> · {pos.meaning}</span></p>}
          {daily && <p className="pos-name">Today's card</p>}
          <h3>{card.name}{c.reversed ? ', reversed' : ''}</h3>
          {lit.length > 0 && <p className="lit-chips">{lit.map(l => <span key={l.kind} className="lit">lit · {K.LIT_SHORT[l.kind]}</span>)}</p>}
          {daily && <p className="watch"><G p={dayRuler} /> {watchFor(c.id, c.reversed, dayRuler)}</p>}
        </div>
      </div>
      <ModeButtons mode={mode} setMode={setOwn} />
      {mode === 'write' && (
        <div className="cp-body">
          {dayHour && <DayHour ctx={ctx} />}
          <p className="question">{q}</p>
          {!written(c.id) && <p className="hint">This card's own questions aren't written yet; this is its plain ask for now.</p>}
          {lit.map(l => <p key={l.kind} className="litline"><span className="litk">Why it's lit</span> {l.text}</p>)}
          <Ladder id={c.id} question={c} />
          <BackToChoice onBack={() => setOwn(null)} />
        </div>
      )}
      {mode === 'read' && (
        <div className="cp-body">
          <p className="kw">{card.keywords.join(', ')}</p>
          <p>{card[c.reversed ? 'reversed' : 'upright']}</p>
          {lit.map(l => <p key={l.kind} className="litline"><span className="litk">Why it's lit</span> {l.text}{l.planets.filter(p => K.PLANET_LINE[p]).slice(0, 1).map(p => <span key={p} className="muted"> {p} is {K.PLANET_LINE[p]}</span>)}</p>)}
          <p className="sky small"><span className="litk">Its piece of the sky</span> {sig.label}.</p>
          {daily && <p className="watch"><G p={dayRuler} /> {watchFor(c.id, c.reversed, dayRuler)}</p>}
          {carry ? <p className="question small-q">{q}</p> : <button className="link quiet" onClick={() => setCarry(true)}>Want one question to carry?</button>}
          <BackToChoice onBack={() => setOwn(null)} />
        </div>
      )}
    </article>
  );
}

// The ten-card layout as a picture.
export function CrossLayout({ cards }) {
  return <div className="cross" aria-hidden="true">{cards.map((c, i) => <img key={i} src={window.__CARD(c.id)} className={`cc cc${i + 1} ${c.reversed ? 'rev' : ''}`} alt="" />)}</div>;
}

// Each card appears as its name plus its own short phrase: "Strength (the lion held gently)".
export function cardPhrase(id, reversed) {
  const card = T.CARDS[id], e = Q[id]?.essence;
  const phrase = e ? e[reversed ? 'rev' : 'up'] : card.keywords[0];
  return `${card.name}${reversed ? ' reversed' : ''} (${phrase})`;
}
export function pairPrompts(cards) {
  const nm = n => cardPhrase(cards[n - 1].id, cards[n - 1].reversed), rv = n => cards[n - 1].reversed;
  return K.PAIRS.map(p => {
    let v;
    if (p.b) v = p.v[(rv(p.a) ? 1 : 0) + (rv(p.b) ? 2 : 0)];
    else v = p.v[rv(p.a) ? 1 : 0];
    return { title: p.title, text: v.replace(/\{(\d+)\}/g, (_, n) => nm(+n)) };
  });
}
