import React, { useState } from 'react';
import * as E from './engine.js';
import * as T from './tarot.js';
import * as K from './content.js';
import { SIGN as SIGN_TEXT, RETRO_NOTE, WANDERER_DAY } from './text.js';
import { G } from './widgets.jsx';
import { ModeButtons, BackToChoice, Steps } from './cards.jsx';

// The day's planet and the hour's planet, opened from the Clock. Shaped like a card: folded,
// then Write (a question and a ladder of small steps) or Read (what it's about, nothing asked).
const daysSince = key => Math.floor(Date.UTC(+key.slice(0, 4), +key.slice(5, 7) - 1, +key.slice(8, 10)) / 86400000);
const lower = s => s.charAt(0).toLowerCase() + s.slice(1);

export function PlanetPanel({ kind, planet, ctx, pday, tz }) {
  const [mode, setMode] = useState(null);
  const [carry, setCarry] = useState(false);
  const P = K.PLANET_TEXT[planet][kind];
  const days = daysSince(ctx.dayKey);
  const q = kind === 'day' ? P.q[Math.floor(days / 7) % P.q.length] : P.q[(days * 24 + Math.max(0, pday?.current ?? 0)) % P.q.length];
  const pt = ctx.sky?.points?.[planet];
  const sign = pt ? E.SIGNS[Math.floor(E.norm(pt.lon) / 30)] : null;
  const cardId = K.PLANET_CARD[planet], card = T.CARDS[cardId];
  const next = kind === 'hour' && pday ? pday.hours[pday.current + 1] : null;
  const line = kind === 'day' ? K.DAY_LINE[planet].replace('Turn it', 'Today turns things') : K.HOUR_LINE[planet];
  const R = P.read;
  return (
    <article className="cp pp">
      <div className="cp-head">
        <div className="pp-glyph" aria-hidden="true"><G p={planet} /></div>
        <div>
          <p className="pos-name">{kind === 'day' ? `${WANDERER_DAY[planet].day}, sunrise to sunrise` : `This hour${pday?.hour ? `, until ${E.fmtTime(pday.hour.end, tz)}` : ''}`}</p>
          <h3>{planet}'s {kind}</h3>
          <p className="watch">{line}</p>
        </div>
      </div>
      <ModeButtons mode={mode} setMode={setMode} />
      {mode === 'write' && (
        <div className="cp-body">
          <p className="question">{q}</p>
          <Steps rungs={P.ladder} floor={K.PLANET_FLOOR[kind]} />
          <BackToChoice onBack={() => setMode(null)} />
        </div>
      )}
      {mode === 'read' && (
        <div className="cp-body">
          {kind === 'day' ? <>
            <p>{R.Meaning}</p>
            <p className="kw">{R.Qualities}</p>
            <p><span className="litk">Watch for</span> {R['Watch for']}</p>
            <p><span className="litk">Too much</span> {R['Too much']}</p>
            <p><span className="litk">Too little</span> {R['Too little']}</p>
          </> : <>
            <p><span className="litk">Good for</span> {R['Good for']}</p>
            <p><span className="litk">How to answer</span> {K.HOUR_LINE[planet]}</p>
            {next && <p className="muted small">Next: <G p={next.ruler} /> {next.ruler}'s hour, from {E.fmtTime(next.start, tz)}.</p>}
          </>}
          {sign && <p className="sky small"><span className="litk">In the sky now</span> {planet === 'Sun' || planet === 'Moon' ? `The ${planet}` : planet} is in {sign}, a sign that's {SIGN_TEXT[E.SIGNS.indexOf(sign)].style}.{pt.retro && RETRO_NOTE[planet] ? ` It's retrograde (seeming to move backward from here): ${RETRO_NOTE[planet]}` : ''}</p>}
          <div className="pp-card"><img src={window.__CARD(cardId)} alt="" /><p className="small"><span className="litk">Its card</span> {card.name}: {lower(card.keywords.join(', '))}.</p></div>
          {carry ? <p className="question small-q">{q}</p> : <button className="link quiet" onClick={() => setCarry(true)}>Want one question to carry?</button>}
          <BackToChoice onBack={() => setMode(null)} />
        </div>
      )}
    </article>
  );
}
