import MEANINGS from '../assets/meanings.json';
import { SIGNS, norm, signOf, fmtLon, TRAD_RULER } from './engine.js';

export const CARDS = MEANINGS.cards;
export const SPREADS = {
  one: [{ n: 1, position: 'Card of the day', meaning: 'The thread to follow today.' }],
  three: MEANINGS.spreads.three.map((p, i) => ({ ...p, n: i + 1 })),
  celtic: MEANINGS.spreads.celticCross,
};
const SUIT_ELEMENT = { Wands: 'Fire', Cups: 'Water', Swords: 'Air', Pentacles: 'Earth' };
const ELEMENT_SUIT = { Fire: 'Wands', Water: 'Cups', Air: 'Swords', Earth: 'Pentacles' };
const SUIT_BASE = { Wands: 22, Cups: 36, Swords: 50, Pentacles: 64 };
const RANKS = ['Ace', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Page', 'Knight', 'Queen', 'King'];
const CHALDEAN_DECAN = ['Mars', 'Sun', 'Venus', 'Mercury', 'Moon', 'Saturn', 'Jupiter'];
const ELEMENTS = ['Fire', 'Earth', 'Air', 'Water'];
const MAJOR = {
  0: ['element', 'Air', 'Uranus'], 1: ['planet', 'Mercury'], 2: ['planet', 'Moon'], 3: ['planet', 'Venus'], 4: ['sign', 'Aries'],
  5: ['sign', 'Taurus'], 6: ['sign', 'Gemini'], 7: ['sign', 'Cancer'], 8: ['sign', 'Leo'], 9: ['sign', 'Virgo'], 10: ['planet', 'Jupiter'],
  11: ['sign', 'Libra'], 12: ['element', 'Water', 'Neptune'], 13: ['sign', 'Scorpio'], 14: ['sign', 'Sagittarius'], 15: ['sign', 'Capricorn'],
  16: ['planet', 'Mars'], 17: ['sign', 'Aquarius'], 18: ['sign', 'Pisces'], 19: ['planet', 'Sun'], 20: ['element', 'Fire', 'Pluto'], 21: ['planet', 'Saturn', 'Earth'],
};
const COURT_START = {
  'Wands Knight': 230, 'Wands Queen': 350, 'Wands King': 110, 'Cups Knight': 320, 'Cups Queen': 80, 'Cups King': 200,
  'Swords Knight': 50, 'Swords Queen': 170, 'Swords King': 290, 'Pentacles Knight': 140, 'Pentacles Queen': 260, 'Pentacles King': 20,
};
const COURT_SUB = { Knight: 'Fire', Queen: 'Water', King: 'Air' };
const QUAD = { Wands: 90, Cups: 180, Swords: 270, Pentacles: 0 };

export function decanCard(lon) {
  const d = Math.floor(norm(lon) / 10), s = Math.floor(d / 3);
  const suit = ELEMENT_SUIT[ELEMENTS[s % 4]];
  return SUIT_BASE[suit] + [2, 5, 8][s % 3] + (d % 3) - 1;
}
export function courtCard(lon) {
  for (const [k, st] of Object.entries(COURT_START)) if (norm(lon - st) < 30) { const [suit, rank] = k.split(' '); return SUIT_BASE[suit] + RANKS.indexOf(rank); }
}
export const majorForSign = s => +Object.entries(MAJOR).find(([, v]) => v[0] === 'sign' && v[1] === SIGNS[s])[0];

export function signature(id) {
  const c = CARDS[id];
  if (c.arcana === 'major') {
    const [kind, value, also] = MAJOR[id];
    const sig = { kind, value, also };
    if (kind === 'sign') { const i = SIGNS.indexOf(value); sig.range = [i * 30, i * 30 + 30]; sig.label = `the sign ${value}`; }
    else if (kind === 'planet') sig.label = `the planet ${value}`;
    else sig.label = `the element ${value}${also ? ` (and ${also})` : ''}`;
    return sig;
  }
  const { suit, rank } = c;
  if (rank === 'Ace' || rank === 'Page') {
    const st = QUAD[suit];
    return { kind: 'quadrant', value: SUIT_ELEMENT[suit], range: [st, st + 90], label: `the ${SUIT_ELEMENT[suit].toLowerCase()} quarter of the year, ${SIGNS[st / 30]} through ${SIGNS[st / 30 + 2]}` };
  }
  if (COURT_SUB[rank]) {
    const st = COURT_START[`${suit} ${rank}`];
    return { kind: 'court', value: `${COURT_SUB[rank]} of ${SUIT_ELEMENT[suit]}`, range: [st, st + 30], label: `20° ${SIGNS[Math.floor(st / 30)]} to 20° ${SIGNS[(Math.floor(st / 30) + 1) % 12]}` };
  }
  for (let d = 0; d < 36; d++) if (decanCard(d * 10 + 5) === id) {
    const s = Math.floor(d / 3), planet = CHALDEAN_DECAN[d % 7];
    return { kind: 'decan', planet, sign: SIGNS[s], range: [d * 10, d * 10 + 10], label: `${planet} in ${SIGNS[s]} (${(d % 3) * 10}–${(d % 3) * 10 + 10}° ${SIGNS[s]})` };
  }
}
const inRange = (lon, [a, b]) => norm(lon - a) < b - a;
const PTS = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'Chiron', 'North Node', 'Asc', 'MC'];

// Where a card's signature is alive in this person's chart and today's sky.
export function resonance(id, natal, sky, transits) {
  const sig = signature(id); const hits = [];
  if (sig.range) {
    for (const n of PTS) if (natal.points[n] && (natal.timeKnown || !['Asc', 'MC'].includes(n)) && inRange(natal.points[n].lon, sig.range)) hits.push({ where: 'natal', text: `your natal ${n} sits here (${fmtLon(natal.points[n].lon)})` });
    for (const n of PTS.slice(0, 12)) if (inRange(sky.points[n].lon, sig.range)) hits.push({ where: 'sky', text: `${n} is passing through it today (${fmtLon(sky.points[n].lon)})` });
  }
  const planet = sig.kind === 'planet' ? sig.value : sig.planet;
  for (const p of [planet, sig.also]) {
    if (!p || !sky.points[p]) continue;
    for (const t of transits) if (t.transit === p || t.natal === p) hits.push({ where: 'transit', text: `${t.transit} is making a ${t.aspect} to your ${t.natal}` });
  }
  return { sig, hits: hits.slice(0, 5), lit: hits.length > 0 };
}

// Shuffle. `random` is a source from online.js (quantum pool + the phone's own randomness);
// a plain number seeds a small repeatable generator instead (used only for tests and previews).
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
export function hashSeed(s) { let h = 2166136261; for (const ch of s) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
export function draw(n, random, reversals = true) {
  let R = random;
  if (!R || typeof R !== 'object') { const r = rng(R ?? crypto.getRandomValues(new Uint32Array(1))[0]); R = { int: k => Math.floor(r() * k), coin: () => r() < 0.5 }; }
  const deck = [...Array(78).keys()];
  for (let i = deck.length - 1; i > 0; i--) { const j = R.int(i + 1); [deck[i], deck[j]] = [deck[j], deck[i]]; }
  return deck.slice(0, n).map(id => ({ id, reversed: reversals && R.coin() }));
}
// The "ask": the meanings file ends most readings with an instruction; use its last sentence.
const IMPERATIVE = new Set(('look ask let notice don’t don\'t take hold keep be rest read trust begin go name put find use know clear eat make stop choose mourn mix talk ' +
  'open write receive count stand answer celebrate pause believe decide expect get gather say grieve pick enjoy bring return stay borrow act soften give work care start cut reconnect re-engage').split(' '));
export function cardAsk(id, reversed) {
  const c = CARDS[id], t = c[reversed ? 'reversed' : 'upright'];
  const s = (t.match(/[^.!?]+[.!?]+/g) || [t]).map(x => x.trim());
  for (let i = s.length - 1; i >= 0; i--) if (IMPERATIVE.has(s[i].split(/\s+/)[0].toLowerCase().replace(/[,:]/g, ''))) return s[i];
  const [k0, k1] = c.keywords;
  return reversed ? `Look at where ${k0} is blocked or overdone, and set it right.` : `Make room for ${k0}${k1 ? ` and ${k1}` : ''}.`;
}
export const skyCards = lon => ({ decan: decanCard(lon), court: courtCard(lon), sign: majorForSign(signOf(lon)) });

// ---------------------------------------------------------------- how a card is lit
const MODERN = { 7: 'Pluto', 10: 'Uranus', 11: 'Neptune' };
const rulersOf = s => [TRAD_RULER[s], MODERN[s]].filter(Boolean);
const FAST = ['Moon', 'Mercury', 'Venus', 'Mars'], SLOW = ['Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'];
const NATAL = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'];
// Returns [{kind, planets:[...]}] in display order, for the ways this card's piece of sky is active.
export function litKinds(id, natal, sky, transits) {
  const sig = signature(id), out = {};
  const add = (k, p) => { (out[k] = out[k] || []).includes(p) || out[k].push(p); };
  const planet = sig.kind === 'planet' ? sig.value : sig.kind === 'element' ? sig.also : sig.kind === 'decan' ? sig.planet : null;
  if (sig.kind === 'planet' || sig.kind === 'element') {
    const P = natal.points;
    if (rulersOf(signOf(P.Sun.lon)).includes(planet)) add('Yours', planet);
    if (natal.timeKnown && rulersOf(signOf(P.Asc.lon)).includes(planet)) add('Yours', planet);
    if (natal.timeKnown && P[planet] && ['Asc', 'MC'].some(a => { const d = Math.abs(((P[planet].lon - P[a].lon + 540) % 360) - 180); return d < 5 || d > 175; })) add('Yours', planet);
  }
  if (sig.range && sig.kind !== 'quadrant') {
    for (const n of NATAL) if (inRange(natal.points[n].lon, sig.range)) add('Yours', n);
    if (natal.timeKnown) for (const n of ['Asc', 'MC']) if (inRange(natal.points[n].lon, sig.range)) add('Yours', n === 'Asc' ? 'your rising sign' : 'your Midheaven');
    for (const n of FAST) if (inRange(sky.points[n].lon, sig.range)) add("Today's weather", n);
    for (const n of SLOW) if (inRange(sky.points[n].lon, sig.range)) add('The long season', n);
  }
  if (sig.range && inRange(sky.points.Sun.lon, sig.range)) add('Its season', 'Sun');
  if (planet && sig.kind !== 'sign' && transits.some(t => t.transit === planet)) add('Touching you', planet);
  if (planet && !['Sun', 'Moon'].includes(planet) && sky.points[planet]?.retro) add('Turning', planet);
  return ['Yours', 'Touching you', 'Its season', "Today's weather", 'The long season', 'Turning'].filter(k => out[k]).map(k => ({ kind: k, planets: out[k] }));
}
