// Optional online checks: the time against atomic-clock-synced servers, and quantum noise for
// shuffles. Everything here fails quietly; offline, the phone's own clock and its secure random
// generator are used, and every draw mixes in the phone's randomness either way.
import { sha256 } from '@noble/hashes/sha256';

const KEY = 'wanderer:online';
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } };
let state = load();
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {} };
const listeners = new Set();
const emit = () => { save(); listeners.forEach(f => f({ ...state })); };
export const subscribe = f => { listeners.add(f); return () => listeners.delete(f); };
export const status = () => ({ ...state });
export const enabled = () => state.off !== true;
export function setEnabled(on) { state.off = !on; if (!on) state.offset = 0; emit(); }

async function timed(url, opts = {}, ms = 6000) {
  const ac = new AbortController(); const t = setTimeout(() => ac.abort(), ms);
  try { return await fetch(url, { cache: 'no-store', ...opts, signal: ac.signal }); } finally { clearTimeout(t); }
}
const hexBytes = h => Uint8Array.from((h.match(/[0-9a-f]{2}/gi) || []).map(b => parseInt(b, 16)));
const toHex = b => Array.from(b, x => x.toString(16).padStart(2, '0')).join('');
const cat = (...parts) => { const out = new Uint8Array(parts.reduce((s, p) => s + p.length, 0)); let i = 0; for (const p of parts) { out.set(p, i); i += p.length; } return out; };
const utf8 = s => new TextEncoder().encode(s);
const local = n => crypto.getRandomValues(new Uint8Array(n));

// ------------------------------------------------------------------ TIME
// Each source gives the server's time; the offset is measured against the midpoint of the request.
// The website's own Date header is only to the second, so it is used only to catch a clock that
// is clearly wrong. Applied only when a source answers; the phone's clock is the fallback.
const TIME_SOURCES = [
  { name: 'timeapi.io', fine: true, url: () => 'https://timeapi.io/api/Time/current/zone?timeZone=UTC',
    read: async r => { const j = await r.json(); return Date.UTC(j.year, j.month - 1, j.day, j.hour, j.minute, j.seconds, j.milliSeconds); } },
  { name: 'worldtimeapi.org', fine: true, url: () => 'https://worldtimeapi.org/api/timezone/Etc/UTC',
    read: async r => { const j = await r.json(); const m = String(j.utc_datetime).match(/^(.*T\d\d:\d\d:\d\d)(?:\.(\d{1,3})\d*)?/); return m ? Date.parse(`${m[1]}.${(m[2] || '0').padEnd(3, '0')}Z`) : NaN; } },
  { name: "this site's server", fine: false, url: () => location.protocol.startsWith('http') ? `${location.origin}${location.pathname}?time=${Date.now()}` : null, opts: { method: 'HEAD' },
    read: async r => { const d = Date.parse(r.headers.get('date')); return isFinite(d) ? d + 500 : NaN; } },
];

export const now = () => Date.now() + (enabled() ? (state.offset || 0) : 0);

let timeBusy = null;
export function syncTime() {
  if (!enabled() || timeBusy) return timeBusy;
  timeBusy = (async () => {
    const got = await Promise.all(TIME_SOURCES.map(async s => {
      const url = s.url(); if (!url) return null;
      try {
        const a = Date.now(); const r = await timed(url, s.opts); const b = Date.now();
        if (!r.ok) return { name: s.name, ok: false };
        const t = await s.read(r); if (!isFinite(t)) return { name: s.name, ok: false };
        return { name: s.name, ok: true, fine: s.fine, offset: t - (a + b) / 2, rtt: b - a };
      } catch { return { name: s.name, ok: false }; }
    }));
    const ok = got.filter(g => g && g.ok), fine = ok.filter(g => g.fine).sort((x, y) => x.rtt - y.rtt);
    let pick = null;
    if (fine.length) pick = fine[0];
    else if (ok.length && Math.abs(ok[0].offset) > 1500 + ok[0].rtt / 2) pick = ok[0];
    state.time = { at: Date.now(), sources: got.filter(Boolean).map(g => ({ name: g.name, ok: g.ok })), used: pick ? pick.name : null,
      offset: pick ? Math.round(pick.offset) : 0, err: pick ? Math.round((pick.fine ? 0 : 500) + pick.rtt / 2) : null };
    state.offset = pick ? Math.round(pick.offset) : 0;
    emit();
  })().finally(() => { timeBusy = null; });
  return timeBusy;
}

// ------------------------------------------------------------------ QUANTUM NOISE
// Free quantum random number services. Each answer is hashed into a 32-byte pool kept on the phone.
const QRNG = [
  { name: 'LfD QRNG, Hamburg', what: 'photons at a beam splitter (an ID Quantique device)', url: 'https://lfdr.de/qrng_api/qrng?length=32&format=HEX',
    read: async r => { const j = await r.json(); return hexBytes(j.qrn || ''); } },
  { name: 'ANU QRNG, Canberra', what: 'the quantum noise of empty space, measured with a laser', url: 'https://qrng.anu.edu.au/API/jsonI.php?length=32&type=uint8', gap: 65000,
    read: async r => { const j = await r.json(); return j.success ? Uint8Array.from(j.data) : new Uint8Array(0); } },
];
export const QRNG_SOURCES = QRNG.map(({ name, what }) => ({ name, what }));

const pool = () => state.pool ? hexBytes(state.pool) : new Uint8Array(32);
const mix = (...parts) => { state.pool = toHex(sha256(cat(pool(), ...parts))); };

let qBusy = null;
export function refreshQuantum({ maxAge = 0 } = {}) {
  if (!enabled()) return Promise.resolve(false);
  if (state.quantum?.at && Date.now() - state.quantum.at < maxAge) return Promise.resolve(true);
  if (qBusy) return qBusy;
  qBusy = (async () => {
    const tried = state.quantum?.tried || {};
    const res = await Promise.all(QRNG.map(async s => {
      if (s.gap && tried[s.name] && Date.now() - tried[s.name] < s.gap) { // resting: keep its last result
        const last = (state.quantum?.sources || []).find(p => p.name === s.name); return { ...(last || { name: s.name, ok: false }), carried: true };
      }
      tried[s.name] = Date.now();
      try {
        const r = await timed(s.url);
        if (!r.ok) return { name: s.name, ok: false };
        const b = await s.read(r);
        return b.length >= 16 ? { name: s.name, ok: true, bytes: b } : { name: s.name, ok: false };
      } catch { return { name: s.name, ok: false }; }
    }));
    const good = res.filter(r => r.ok && !r.carried);
    for (const r of good) mix(utf8(r.name), r.bytes);
    const prev = state.quantum || {};
    state.quantum = { tried, at: good.length ? Date.now() : prev.at || null,
      sources: res.map(r => r.carried ? { name: r.name, ok: r.ok, at: r.at || null } : { name: r.name, ok: r.ok, at: r.ok ? Date.now() : null }) };
    emit();
    return good.length > 0;
  })().finally(() => { qBusy = null; });
  return qBusy;
}

// A random source for one draw: the quantum pool, fresh randomness from the phone and the
// occasion are hashed into a key, and the pool moves forward so no key is ever reused.
export function randomFor(occasion) {
  const key = sha256(cat(pool(), local(32), utf8(`${occasion}|${Date.now()}`)));
  mix(utf8('next'), local(16)); save();
  let ctr = 0, buf = new Uint8Array(0), i = 0;
  const next32 = () => {
    if (i + 4 > buf.length) { buf = sha256(cat(key, Uint8Array.of(ctr >>> 24, ctr >>> 16 & 255, ctr >>> 8 & 255, ctr & 255))); ctr++; i = 0; }
    const v = ((buf[i] << 24) | (buf[i + 1] << 16) | (buf[i + 2] << 8) | buf[i + 3]) >>> 0; i += 4; return v;
  };
  // Uniform whole number below n, without the slight bias of a plain remainder.
  const int = n => { const lim = 4294967296 - (4294967296 % n); let v; do v = next32(); while (v >= lim); return v % n; };
  return { int, coin: () => (next32() & 1) === 1, quantum: !!state.quantum?.at };
}

// Start both checks when the app opens and whenever it comes back to the screen.
export function start() {
  const go = () => { if (!enabled() || !navigator.onLine) return; if (!state.time || Date.now() - state.time.at > 3 * 3600e3) syncTime(); refreshQuantum({ maxAge: 10 * 60e3 }); };
  go();
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') go(); });
  window.addEventListener('online', go);
}
