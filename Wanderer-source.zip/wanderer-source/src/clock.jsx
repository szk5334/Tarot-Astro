import React from 'react';
import { GLYPH, SIGN_GLYPH, norm, localFields } from './engine.js';

// The sky clock: a 24-hour dial (midnight at the bottom, noon at the top, so the Sun rises on the
// left just as it does in the chart) ringed by today's planetary hours, with the sky right now
// inside it, Ascendant on the left.
const VS = '︎';
const C = 500, R = { band0: 432, band1: 496, z0: 364, z1: 426, pl: 318, tick: 352, disc: 214 };
const DEG = Math.PI / 180;
const pt = (a, r) => [C + r * Math.cos(a * DEG), C + r * Math.sin(a * DEG)];
const arc = (a0, a1, r0, r1) => {
  while (a1 < a0) a1 += 360;
  const big = a1 - a0 > 180 ? 1 : 0, [x0, y0] = pt(a0, r1), [x1, y1] = pt(a1, r1), [x2, y2] = pt(a1, r0), [x3, y3] = pt(a0, r0);
  return `M${x0},${y0} A${r1},${r1} 0 ${big} 1 ${x1},${y1} L${x2},${y2} A${r0},${r0} 0 ${big} 0 ${x3},${y3} Z`;
};
const COLOR = { Sun: 'sun', Moon: 'moon', Mercury: 'mercury', Venus: 'venus', Mars: 'mars', Jupiter: 'jupiter', Saturn: 'saturn' };
const PTS = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'];

function spread(items, gap) {
  const it = items.map(x => ({ ...x, d: x.a })).sort((p, q) => p.a - q.a);
  for (let k = 0; k < 40; k++) {
    let moved = false;
    for (let i = 0; i < it.length; i++) {
      const p = it[i], q = it[(i + 1) % it.length], d = norm(q.d - p.d);
      if (it.length > 1 && d < gap) { p.d -= (gap - d) / 2; q.d += (gap - d) / 2; moved = true; }
    }
    if (!moved) break;
  }
  return it;
}

export function SkyClock({ sky, pday, now, tz }) {
  const clockAng = ms => { const f = localFields(ms, tz); return 90 + (f.h + f.mi / 60 + f.s / 3600) * 15; };
  const asc = sky.points.Asc.lon;
  const zAng = lon => 180 - (lon - asc);
  const handA = clockAng(now);
  const planets = spread(PTS.map(n => ({ n, a: zAng(sky.points[n].lon) })), 11);
  const f = localFields(now, tz);
  const hh = ((f.h + 11) % 12) + 1, ampm = f.h < 12 ? 'AM' : 'PM';
  const cur = pday?.hour;
  return (
    <svg className="dial" viewBox="0 0 1000 1000" role="img" aria-label={`Sky clock: ${hh}:${String(f.mi).padStart(2, '0')} ${ampm}${cur ? `, hour of ${cur.ruler}` : ''}`}>
      <circle cx={C} cy={C} r={R.band1} className="ck-night" />
      {pday ? pday.hours.map((h, i) => {
        const a0 = clockAng(h.start), a1 = clockAng(h.end), on = i === pday.current;
        let mid = a0 + (((a1 - a0) % 360) + 360) % 360 / 2;
        const [x, y] = pt(mid, (R.band0 + R.band1) / 2);
        return <g key={i}>
          <path d={arc(a0, a1, R.band0, R.band1)} className={h.day ? 'ck-day' : 'ck-night'} />
          <path d={arc(a0, a1, R.band0, R.band1)} className={`ck-tint c-${COLOR[h.ruler]}`} style={{ fillOpacity: on ? 0.5 : 0.13 }} />
          <text x={x} y={y} className={`ck-hg c-${COLOR[h.ruler]}`} textAnchor="middle" dominantBaseline="central" style={{ fontSize: on ? 38 : 27, opacity: on ? 1 : 0.8 }}>{GLYPH[h.ruler] + VS}</text>
        </g>;
      }) : null}
      {Array.from({ length: 24 }, (_, i) => { const a = 90 + i * 15, [x0, y0] = pt(a, R.band1 - (i % 6 ? 6 : 14)), [x1, y1] = pt(a, R.band1); return <line key={'t' + i} x1={x0} y1={y0} x2={x1} y2={y1} className="ck-tick" />; })}
      {Array.from({ length: 12 }, (_, s) => {
        const a0 = zAng(s * 30 + 30), a1 = zAng(s * 30), [gx, gy] = pt(zAng(s * 30 + 15), (R.z0 + R.z1) / 2);
        return <g key={'z' + s}>
          <path d={arc(a0, a1, R.z0, R.z1)} className={`ck-z el-${s % 4}`} />
          <text x={gx} y={gy} className={`ck-zg elg-${s % 4}`} textAnchor="middle" dominantBaseline="central">{SIGN_GLYPH[s] + VS}</text>
        </g>;
      })}
      <circle cx={C} cy={C} r={R.z0} className="ck-inner" />
      {[[asc, 'AC'], [sky.points.MC.lon, 'MC']].map(([l, t]) => { const a = zAng(l), [x0, y0] = pt(a, R.disc), [x1, y1] = pt(a + 180, R.disc), [x2, y2] = pt(a, R.z0), [x3, y3] = pt(a + 180, R.z0); return <g key={t}><line x1={x0} y1={y0} x2={x2} y2={y2} className="ck-axis" /><line x1={x1} y1={y1} x2={x3} y2={y3} className="ck-axis faint" /></g>; })}
      {planets.map(p => {
        const [x0, y0] = pt(p.a, R.tick), [x1, y1] = pt(p.a, R.z0), [x, y] = pt(p.d, R.pl);
        return <g key={p.n}><line x1={x0} y1={y0} x2={x1} y2={y1} className="ck-ptick" /><text x={x} y={y} className={`ck-pg c-${COLOR[p.n] || 'outer'}`} textAnchor="middle" dominantBaseline="central">{GLYPH[p.n] + VS}{sky.points[p.n].retro ? <tspan className="ck-r" dy="10">r</tspan> : null}</text></g>;
      })}
      <circle cx={C} cy={C} r={R.disc} className="ck-disc" />
      {(() => { const [x0, y0] = pt(handA, R.disc), [x1, y1] = pt(handA, R.band1 + 2); return <g className="ck-hand"><line x1={x0} y1={y0} x2={x1} y2={y1} /><circle cx={x1} cy={y1} r="9" /></g>; })()}
      <text x={C} y={C - 18} className="ck-time" textAnchor="middle" dominantBaseline="central">{hh}:{String(f.mi).padStart(2, '0')}<tspan className="ck-ampm" dx="8">{ampm}</tspan></text>
      {cur && <text x={C} y={C + 62} className="ck-hourtxt" textAnchor="middle" dominantBaseline="central">hour of <tspan className={`c-${COLOR[cur.ruler]}`}>{GLYPH[cur.ruler] + VS}</tspan> {cur.ruler}</text>}
    </svg>
  );
}
