// Plain-language interpretation library. Every term carries its own gloss so a reader who knows
// no astrology can follow (deep guide parts 2, 5, 7, 10).
import { SIGNS, signOf, elementOf, modalityOf, TRAD_RULER, fmtLon } from './engine.js';

export const PLANET = {
  Sun: { role: 'your core self and vitality', short: 'identity', gloss: 'The Sun is your core self: what lights you up, where you want to shine, the energy you run on.', verb: 'shine', color: 'sun' },
  Moon: { role: 'your needs, moods and sense of safety', short: 'feelings', gloss: 'The Moon is your inner weather: what you need to feel safe, your moods, habits and body.', verb: 'feel', color: 'moon' },
  Mercury: { role: 'how you think, talk and learn', short: 'mind', gloss: 'Mercury is the mind in motion: thinking, talking, writing, learning, errands and deals.', verb: 'think', color: 'mercury' },
  Venus: { role: 'love, pleasure and what you value', short: 'love', gloss: 'Venus is what you love and how you love: attraction, beauty, pleasure, money and making peace.', verb: 'love', color: 'venus' },
  Mars: { role: 'drive, courage and anger', short: 'drive', gloss: 'Mars is your drive: how you go after things, compete, defend yourself and get angry.', verb: 'act', color: 'mars' },
  Jupiter: { role: 'growth, faith and generosity', short: 'growth', gloss: 'Jupiter is growth: luck, generosity, faith, teachers and the urge to expand (sometimes too far).', verb: 'grow', color: 'jupiter' },
  Saturn: { role: 'structure, limits and endurance', short: 'structure', gloss: 'Saturn is structure: limits, time, responsibility and the slow mastery that only comes from practice.', verb: 'build', color: 'saturn' },
  Uranus: { role: 'freedom, disruption and invention', short: 'change', gloss: 'Uranus is sudden change: freedom, rebellion, invention, the part of you that refuses to fit.', verb: 'break free', color: 'outer' },
  Neptune: { role: 'dreams, longing and dissolving', short: 'dreams', gloss: 'Neptune dissolves edges: imagination, spirituality, compassion, and also confusion and escape.', verb: 'dream', color: 'outer' },
  Pluto: { role: 'depth, power and transformation', short: 'depth', gloss: 'Pluto is depth: power, obsession, what is hidden, and change that strips things back to the core.', verb: 'transform', color: 'outer' },
  Chiron: { role: 'the old wound and the healer it makes you', short: 'healing', gloss: 'Chiron is a small body linked to the wound you carry and the wisdom you gain tending it.', verb: 'heal', color: 'outer' },
  'North Node': { role: 'your growth edge', short: 'direction', gloss: 'The North Node is where the Moon\'s path crosses the Sun\'s; it points toward the unfamiliar direction you grow by.', verb: 'grow', color: 'outer' },
  'South Node': { role: 'your comfort zone', short: 'the familiar', gloss: 'The South Node is the opposite point: what comes easily and what you fall back on.', verb: 'rest', color: 'outer' },
  Lilith: { role: 'what is raw and unapologetic', short: 'the untamed', gloss: 'Lilith (the Black Moon) is a calculated point tied to what is raw, refused or untamed in you.', verb: 'refuse', color: 'outer' },
  Asc: { role: 'how you meet the world', short: 'approach', gloss: 'The Ascendant (rising sign) was rising on the eastern horizon when you were born: your approach to life, your body and first impressions.', verb: 'appear', color: 'ink' },
  MC: { role: 'your public direction and career', short: 'calling', gloss: 'The Midheaven (MC) is the top of the chart: career, reputation and what you are known for.', verb: 'aim', color: 'ink' },
  Fortune: { role: 'luck and circumstances', short: 'fortune', gloss: 'The Lot of Fortune is a calculated point for the body, luck and what happens to you.', verb: 'receive', color: 'ink' },
};
export const SIGN = [
  { style: 'bold, direct and quick to start', gloss: 'Aries is cardinal fire, the first sign: it starts things, acts first and asks later.' },
  { style: 'steady, sensual and patient', gloss: 'Taurus is fixed earth: it builds slowly, savors the body and holds onto what it values.' },
  { style: 'curious, quick and talkative', gloss: 'Gemini is mutable air: it collects ideas, connects people and needs variety.' },
  { style: 'protective, tender and moody', gloss: 'Cancer is cardinal water: it cares, remembers and builds a shell around what it loves.' },
  { style: 'warm, proud and expressive', gloss: 'Leo is fixed fire: it creates, performs and wants its heart to be seen.' },
  { style: 'precise, useful and discerning', gloss: 'Virgo is mutable earth: it refines, fixes, serves and notices every detail.' },
  { style: 'graceful, fair and relational', gloss: 'Libra is cardinal air: it seeks balance, beauty and a good partner to think with.' },
  { style: 'intense, private and probing', gloss: 'Scorpio is fixed water: it goes deep, keeps secrets and does not do anything halfway.' },
  { style: 'expansive, candid and restless', gloss: 'Sagittarius is mutable fire: it wanders, believes, teaches and aims far.' },
  { style: 'disciplined, ambitious and dry', gloss: 'Capricorn is cardinal earth: it climbs, plans for the long run and earns its authority.' },
  { style: 'independent, inventive and detached', gloss: 'Aquarius is fixed air: it thinks for the group, questions rules and values its freedom.' },
  { style: 'dreamy, porous and compassionate', gloss: 'Pisces is mutable water, the last sign: it dissolves boundaries, imagines and feels everything.' },
];
export const HOUSE = [
  ['self and body', 'The 1st house is you: your body, your presence, how life meets you first.'],
  ['money and self-worth', 'The 2nd house is resources: money, possessions, talents and what you feel you are worth.'],
  ['daily talk, siblings and learning', 'The 3rd house is your near world: siblings, neighbors, short trips, messages and study.'],
  ['home, family and roots', 'The 4th house is the foundation: home, family, parents, privacy and endings.'],
  ['creativity, romance and play', 'The 5th house is joy: children, art, romance, games and what you make for the love of it.'],
  ['work routines and health', 'The 6th house is the daily grind: routines, chores, health habits, service and pets.'],
  ['partners and one-to-one bonds', 'The 7th house is the other: marriage, partners, close collaborators and open rivals.'],
  ['shared resources and intimacy', 'The 8th house is what is shared and deep: other people\'s money, debt, intimacy, fear and loss.'],
  ['travel, belief and higher learning', 'The 9th house is the far horizon: travel, philosophy, faith, publishing and higher study.'],
  ['career and reputation', 'The 10th house is the public peak: career, status, achievement and what you are known for.'],
  ['friends, groups and hopes', 'The 11th house is community: friends, allies, groups and the future you hope for.'],
  ['solitude, rest and the hidden', 'The 12th house is behind the curtain: retreat, rest, secrets, dreams and self-undoing.'],
];
export const ASPECT = {
  conjunction: { rel: 'fused with', tone: 'fusion', gloss: 'A conjunction (0°) means the two sit together and act as one; their natures blend.' },
  sextile: { rel: 'in friendly contact with', tone: 'opportunity', gloss: 'A sextile (60°) is an opening: easy cooperation that pays off if you make a small effort.' },
  square: { rel: 'pushing against', tone: 'friction', gloss: 'A square (90°) is friction: two needs that rub, forcing action and growth.' },
  trine: { rel: 'flowing with', tone: 'flow', gloss: 'A trine (120°) is flow: a natural talent or ease, easy to take for granted.' },
  opposition: { rel: 'facing', tone: 'tug-of-war', gloss: 'An opposition (180°) is a tug-of-war or mirror, often felt through other people.' },
  quincunx: { rel: 'out of step with', tone: 'mismatch', gloss: 'A quincunx (150°) is a mismatch that needs constant small adjustments.' },
};
export const nm = n => ({ Asc: 'Ascendant', MC: 'Midheaven' })[n] || n;
const ord = n => n + (n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th');
export const ordinal = ord;
export const hard = a => ['square', 'opposition'].includes(a);
export const soft = a => ['trine', 'sextile'].includes(a);

export function placement(name, p, natal) {
  const s = signOf(p.lon), P = PLANET[name], S = SIGN[s];
  let t = `**${name} in ${SIGNS[s]}${p.house && natal.timeKnown ? `, ${ord(p.house)} house` : ''}.** ${P.gloss} In ${SIGNS[s]} it works in a ${S.style} way. ${S.gloss}`;
  if (p.house && natal.timeKnown) t += ` It lives in your ${ord(p.house)} house, so it shows up most in ${HOUSE[p.house - 1][0]}.`;
  if (p.dignity === 'domicile') t += ` ${name} is at home in ${SIGNS[s]} (its own sign), so it is well resourced and fully itself.`;
  if (p.dignity === 'exaltation') t += ` ${name} is exalted in ${SIGNS[s]}, an honored guest working at its best.`;
  if (p.dignity === 'detriment') t += ` ${SIGNS[s]} is opposite ${name}'s home sign, so it works against the grain and develops unusual strengths.`;
  if (p.dignity === 'fall') t += ` ${name} is in its fall in ${SIGNS[s]}: undervalued here, it has to work for its results.`;
  if (p.retro) t += ` It was retrograde (appearing to move backward from Earth) when you were born, which turns its energy inward and reflective.`;
  return t;
}
export function bigThree(natal) {
  const P = natal.points, out = [];
  out.push({ key: 'Sun', title: `☉ Sun in ${SIGNS[signOf(P.Sun.lon)]}`, text: `What lights you up. ${SIGN[signOf(P.Sun.lon)].gloss}` });
  out.push({ key: 'Moon', title: `☽ Moon in ${SIGNS[signOf(P.Moon.lon)]}`, text: `What you need to feel safe. ${SIGN[signOf(P.Moon.lon)].gloss}` });
  if (natal.timeKnown) out.push({ key: 'Asc', title: `AC ${SIGNS[signOf(P.Asc.lon)]} rising`, text: `How you meet the world. ${SIGN[signOf(P.Asc.lon)].gloss} Your chart ruler, the planet that owns your rising sign, is ${natal.ruler}.` });
  return out;
}
export function aspectText(x, whoA = 'your', whoB = 'your') {
  return `${whoA === whoB ? 'Your' : whoA} ${x.a} (${PLANET[x.a]?.short}) is ${ASPECT[x.aspect].rel} ${whoB} ${x.b} (${PLANET[x.b]?.short}), within ${x.orb.toFixed(1)}°. ${ASPECT[x.aspect].gloss}`;
}

// ---------------------------------------------------------------- transits & the daily horoscope
const TRANSIT_ACT = {
  Moon: ['stirs', 'soothes', 'tugs at', 'lights up'], Sun: ['spotlights', 'warms', 'challenges', 'spotlights'],
  Mercury: ['gets talking about', 'clarifies', 'complicates', 'opens a conversation about'],
  Venus: ['sweetens', 'sweetens', 'tests what you want from', 'brings pleasure to'],
  Mars: ['fires up', 'energizes', 'provokes', 'ignites'], Jupiter: ['expands', 'blesses', 'overinflates', 'opens doors for'],
  Saturn: ['tests', 'steadies', 'presses on', 'rebuilds'], Uranus: ['shakes loose', 'refreshes', 'disrupts', 'reinvents'],
  Neptune: ['softens', 'inspires', 'blurs', 'dissolves'], Pluto: ['deepens', 'empowers', 'confronts', 'transforms'],
  Chiron: ['touches the old wound in', 'heals', 'reopens', 'tends'], 'North Node': ['points the way for', 'points the way for', 'points the way for', 'points the way for'],
};
const TARGET = {
  Sun: 'who you are', Moon: 'how you feel', Mercury: 'your thinking', Venus: 'your love life and pleasures', Mars: 'your drive',
  Jupiter: 'your hopes', Saturn: 'your commitments', Uranus: 'your need for freedom', Neptune: 'your dreams', Pluto: 'your power',
  Chiron: 'an old hurt', 'North Node': 'your direction', Asc: 'how you come across', MC: 'your work and standing',
};
const DURATION = { Moon: 'a few hours', Sun: 'a couple of days', Mercury: 'a day or two', Venus: 'a few days', Mars: 'about a week', Jupiter: 'several weeks', Saturn: 'months', Uranus: 'a year or more', Neptune: 'a year or more', Pluto: 'a year or more', Chiron: 'months', 'North Node': 'months' };
const ASKS = {
  Moon: ['check in with your body before you react', 'let yourself be comforted', 'notice which mood is old and which is new', 'feed what you actually need'],
  Sun: ['act like yourself on purpose', 'let yourself be seen doing what you love', 'pick the fight that matters and drop the rest', 'start the thing'],
  Mercury: ['say the true thing plainly', 'write it down', 'read it twice before sending', 'have the conversation'],
  Venus: ['make room for pleasure', 'say the kind thing out loud', 'ask what you really value here', 'make something beautiful'],
  Mars: ['spend the energy on one clear goal', 'move your body', 'cool down before you strike', 'begin, bravely'],
  Jupiter: ['say yes to the open door', 'be generous', 'watch for too much of a good thing', 'aim higher'],
  Saturn: ['do the slow work and trust it', 'keep one promise', 'accept the limit and build inside it', 'commit'],
  Uranus: ['try the unfamiliar way', 'leave room for surprise', 'change one small thing before change is forced', 'free yourself'],
  Neptune: ['rest and let it be unclear for now', 'make art of it', 'double-check what seems too good', 'trust the quiet signal'],
  Pluto: ['let go of what has finished', 'claim your power without grabbing', 'look at the thing you avoid', 'let it change form'],
  Chiron: ['be gentle with the sore place', 'use what hurt you to help someone', 'notice the old pattern', 'tend it'],
  'North Node': ['take the unfamiliar step', 'take the unfamiliar step', 'take the unfamiliar step', 'take the unfamiliar step'],
};
const idx = a => (a === 'conjunction' ? 3 : soft(a) ? 1 : hard(a) ? 2 : 0);
export function transitHeadline(t) {
  const v = TRANSIT_ACT[t.transit][idx(t.aspect)];
  const s = `${t.transit} ${v} ${TARGET[t.natal]}`;
  return s.charAt(0).toUpperCase() + s.slice(1);
}
export function transitText(t, fmt) {
  const P = PLANET[t.transit], N = PLANET[t.natal], A = ASPECT[t.aspect];
  let s = `Today's ${t.transit} (${P.role}) is ${A.rel} your natal ${nm(t.natal)} (${N.role}). ${A.gloss} `;
  s += `A ${t.transit} transit like this is felt for ${DURATION[t.transit]}, and it is ${t.applying ? 'still building' : 'now easing off'}.`;
  if (t.next?.length) s += ` Exact ${t.next.map(fmt).join(', then ')}.`;
  else if (t.last) s += ` It was exact ${fmt(t.last)}.`;
  if (t.retro && t.next?.length > 1) s += ` Because ${t.transit} is retrograde, it makes more than one exact pass; the later passes revisit and settle what the first one raised.`;
  return s;
}
export const transitAsk = t => { const a = ASKS[t.transit][idx(t.aspect)]; return a.charAt(0).toUpperCase() + a.slice(1) + '.'; };

export const WANDERER_DAY = {
  Sun: { day: 'Sunday', good: 'visibility, vitality, leadership, celebrating', candle: 'gold' },
  Moon: { day: 'Monday', good: 'home, rest, care, dreams, the body', candle: 'silver or white' },
  Mars: { day: 'Tuesday', good: 'courage, exercise, cutting, hard starts', candle: 'red' },
  Mercury: { day: 'Wednesday', good: 'writing, study, messages, errands, trade', candle: 'orange' },
  Jupiter: { day: 'Thursday', good: 'generosity, teaching, planning big, faith', candle: 'blue or purple' },
  Venus: { day: 'Friday', good: 'love, beauty, art, pleasure, making peace', candle: 'green' },
  Saturn: { day: 'Saturday', good: 'finishing, structure, boundaries, solitude', candle: 'black or indigo' },
};
export const PHASE_NOTE = {
  'New Moon': 'Seeding time: begin quietly, set an intention.',
  'Waxing Crescent': 'First growth: take the first small steps.',
  'First Quarter': 'The first push: meet the obstacle and decide.',
  'Waxing Gibbous': 'Refining: adjust and keep building.',
  'Full Moon': 'Culmination: things come to light, feelings run high.',
  'Waning Gibbous': 'Sharing: pass on what you learned.',
  'Last Quarter': 'Review: clear out what no longer fits.',
  'Waning Crescent': 'Rest: let things end before the next beginning.',
};
export const RETRO_NOTE = {
  Mercury: 'a review period for messages, plans, travel and tech: re-check, re-read, re-connect.',
  Venus: 'a review of love, money and values: reassess before buying or committing on a whim.',
  Mars: 'a rerouting of effort: old conflicts resurface, push less and plan more.',
  Jupiter: 'growth turned inward: revisit beliefs and plans.', Saturn: 'a review of structures and commitments: repair the foundations.',
  Uranus: 'inner freedom work: the urge to change goes underground first.', Neptune: 'dreams and illusions come up for review.',
  Pluto: 'deep inner housecleaning.', Chiron: 'old wounds come back for gentler tending.',
};

export function dailyHoroscope(natal, transits, sky, moon) {
  const fast = transits.filter(t => ['Moon', 'Sun', 'Mercury', 'Venus', 'Mars'].includes(t.transit));
  const slow = transits.filter(t => !['Moon', 'Sun', 'Mercury', 'Venus', 'Mars'].includes(t.transit));
  const lead = fast.find(t => t.transit !== 'Moon') || fast[0] || slow[0];
  const moonT = fast.filter(t => t.transit === 'Moon').sort((a, b) => a.orb - b.orb)[0];
  const ms = signOf(sky.points.Moon.lon);
  const moonHouse = natal.timeKnown ? sky.points.Moon.natalHouse : null;
  const headline = lead ? transitHeadline(lead) : `A quiet ${moon.name.toLowerCase()} day`;
  const paras = [];
  paras.push(`The Moon is in ${SIGNS[ms]} today, so the day's mood is ${SIGN[ms].style}.` + (moonHouse ? ` It is moving through your ${ord(moonHouse)} house, putting feelings around ${HOUSE[moonHouse - 1][0]}.` : '') + (moonT ? ` It is ${ASPECT[moonT.aspect].rel} your natal ${nm(moonT.natal)}, so expect ${TARGET[moonT.natal]} to be close to the surface for a few hours.` : ''));
  if (lead && lead.transit !== 'Moon') paras.push(`${transitHeadline(lead)}: ${PLANET[lead.transit].gloss.split(':')[0]}, and right now it is ${ASPECT[lead.aspect].rel} your natal ${nm(lead.natal)}, ${PLANET[lead.natal].role}. ${ASPECT[lead.aspect].gloss}`);
  if (slow[0]) paras.push(`In the background, the longer chapter: ${slow[0].transit} is ${ASPECT[slow[0].aspect].rel} your ${nm(slow[0].natal)}. This kind of transit lasts ${DURATION[slow[0].transit]}, so today is one scene in it.`);
  const asks = [lead && transitAsk(lead), moonT && transitAsk(moonT), slow[0] && transitAsk(slow[0])].filter(Boolean);
  return { headline, paras, asks: [...new Set(asks)] };
}

// ---------------------------------------------------------------- relationships
export const KEY_PAIRS = {
  'Moon|Sun': 'the classic sign of two lives that fit: one\'s core self meets the other\'s needs',
  'Mars|Venus': 'attraction and spark', 'Moon|Moon': 'feeling at home together', 'Sun|Sun': 'how two identities sit side by side',
  'Venus|Venus': 'shared tastes and ways of showing love', 'Mercury|Mercury': 'how you talk and think together', 'Moon|Venus': 'tenderness and ease',
  'Sun|Venus': 'warmth and admiration', 'Saturn|Sun': 'commitment and duty, steadying or heavy', 'Moon|Saturn': 'loyalty and staying power; can feel cool',
  'Saturn|Venus': 'durable love with responsibilities', 'Jupiter|Sun': 'generosity and encouragement', 'Jupiter|Moon': 'emotional generosity',
  'Pluto|Venus': 'intensity and fascination; watch for power struggles', 'Moon|Pluto': 'a deep emotional bond that can turn controlling',
  'Uranus|Venus': 'excitement and a need for freedom', 'Neptune|Venus': 'romance and idealism; see each other clearly',
  'North Node|Sun': 'a feeling of meeting for a reason', 'Moon|North Node': 'a feeling of meeting for a reason', 'Asc|Sun': 'being easily seen by the other',
  'Asc|Moon': 'instant familiarity', 'Asc|Venus': 'finding each other attractive on sight', 'Mars|Mars': 'how your energies and tempers meet', 'Mars|Saturn': 'frustration, or disciplined teamwork',
  'Mercury|Moon': 'feeling understood when you talk',
};
export const keyNote = (a, b) => KEY_PAIRS[[a, b].sort().join('|')];
export const TONE_TEXT = {
  flowing: 'trines and sextiles: ease, natural understanding',
  dynamic: 'squares and oppositions: spark, friction, growth',
  fusing: 'conjunctions: merging, intensity, shared focus',
  adjusting: 'quincunxes: small mismatches that need translating',
};
export const COMPOSITE_HOUSE = ['a bond about who you are together', 'a bond about building security', 'a bond made of conversation', 'a bond about home and family', 'a bond about play, romance and creating', 'a bond about daily life and helping', 'a partnership in the fullest sense', 'a bond of depth and shared resources', 'a bond of adventure and shared beliefs', 'a bond with a public or shared purpose', 'a friendship at heart', 'a private, inward bond'];
export const RULER_OF = s => TRAD_RULER[s];
export { fmtLon };
