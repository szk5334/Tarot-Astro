// Shared, hand-written lines used by every card (see card-questions-foundation.md).
import QUESTIONS from '../assets/questions.json';
export { QUESTIONS };

export const POSITIONS = [
  { n: 1, label: 'Central theme', meaning: 'what the whole spread is about' },
  { n: 2, label: 'Cross / boon', meaning: 'the obstacle or the help; the bridge from what leaves to what comes' },
  { n: 3, label: 'Root', meaning: 'the root of everything in the spread' },
  { n: 4, label: 'Passing away', meaning: 'energy leaving' },
  { n: 5, label: 'Front of mind', meaning: 'what you are thinking about and making real' },
  { n: 6, label: 'Coming in', meaning: 'energy arriving' },
  { n: 7, label: 'Who you are', meaning: 'you, in this' },
  { n: 8, label: 'What surrounds you', meaning: 'people and influences around you' },
  { n: 9, label: 'Hopes / fears', meaning: 'the back of your mind' },
  { n: 10, label: 'Outcome', meaning: 'where the front and back of your mind are leading' },
];
export const SPREADS = {
  one: { label: 'One card', slots: [{ pos: 1, label: 'Today' }] },
  three: { label: 'Three cards', slots: [{ pos: 4, label: 'Past' }, { pos: 1, label: 'Present' }, { pos: 6, label: 'Future' }] },
  celtic: { label: 'Celtic Cross', slots: POSITIONS.map(p => ({ pos: p.n, label: p.label })) },
};

// The day's planet points the question somewhere; the hour's planet sets how to answer.
export const DAY_LINE = {
  Sun: 'Turn it toward what you are seen for and what keeps you lit.',
  Moon: 'Turn it toward home, the body and how you actually feel.',
  Mars: 'Turn it toward courage, anger and what needs cutting.',
  Mercury: 'Turn it toward words, crossings and what you are trading.',
  Jupiter: 'Turn it toward generosity, faith and what wants to grow.',
  Venus: 'Turn it toward love, pleasure and what you value.',
  Saturn: 'Turn it toward time, limits and what you are building to last.',
};
export const DAY_TOWARD = Object.fromEntries(Object.entries(DAY_LINE).map(([k, v]) => [k, v.replace('Turn it toward ', '').replace(/\.$/, '')]));
export const HOUR_LINE = {
  Sun: 'Answer out loud, as if someone you respect were reading over your shoulder.',
  Moon: 'Answer from the body first: what do you feel before you think?',
  Mars: 'Answer bluntly, and stop when it is said.',
  Mercury: 'Answer fast, in plain words; follow where the pen goes.',
  Jupiter: 'Answer generously: the big version, the one with room in it.',
  Venus: 'Answer slowly and with pleasure; savor the words.',
  Saturn: 'Answer honestly and briefly; one true sentence is enough.',
};

// The ladder, for when nothing is coming. Rungs 1 and 2 use each card's own pointer.
export const LADDER = [
  { name: 'Look', text: (c) => `What's going on in this picture, and what do you see that makes you say that? Describe only.${c.notice ? ` Start with ${lower(c.notice)}` : ''}` },
  { name: 'Become', text: (c) => c.become ? `Become ${lower(c.become)} Write it as them, and say what happened just before this moment.` : 'Pick a figure, or the object in the middle of the card. What are they thinking? What happened just before this moment? Write it as them.' },
  { name: 'Lend them your feeling', text: () => "If they were feeling what you're feeling, what would they do next? What would happen after they do that?" },
  { name: 'Bring it home', text: (c) => `Where have you been ${c.essence?.figure || 'this person'} lately?` },
  { name: 'Compare', text: () => "Now read the card's meaning. Where does it agree with the story you wrote, and where does it go somewhere else? If they don't connect at all, that's fine: which feels truer today, and what does your story know that the meaning doesn't?" },
];
const lower = s => s.charAt(0).toLowerCase() + s.slice(1);
export const FLOOR = [
  "Write the date, the day's planet and the card's name at the top of the page.",
  "Copy the card's question underneath, word for word.",
  'Write one word for how today feels.',
  'Close the notebook. You opened it; that counts.',
];

// Lit kinds, in the order shown. Generic lines stand in for cards whose own lines aren't written yet.
export const LIT_KINDS = ['Yours', 'Touching you', 'Its season', "Today's weather", 'The long season', 'Turning'];
export const LIT_SHORT = { Yours: 'yours', 'Touching you': 'touching you', 'Its season': 'its season', "Today's weather": "today's weather", 'The long season': 'the long season', Turning: 'turning' };
export const GENERIC_LIT = {
  Yours: "This card's piece of the sky holds a planet from your birth chart, so its theme is a lifelong thread for you. Answer about the long arc.",
  'Touching you': "This card's planet is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so it is personally involved today. Answer about what it is stirring.",
  'Its season': "The Sun is in this card's stretch of the year, so the season itself is asking this. Answer about what the time of year brings up.",
  "Today's weather": "{planet} {is} passing through this card's degrees, so its question is live today. Answer about something in front of you now.",
  'The long season': "{planet} {is} moving through this card's degrees for months or years, so the whole era is asking this. Answer about what is slowly changing.",
  Turning: "This card's planet is retrograde (seeming to move backward), a time to revisit rather than push. Answer about what you'd return to.",
};
export const PLANET_LINE = {
  Sun: 'the planet of attention and vitality, what you are seen for. It stays about ten days in a decan.',
  Moon: 'the planet of mood, body and home. It crosses a card\'s degrees in under a day.',
  Mercury: 'the planet of words, thinking, errands and deals.',
  Venus: 'the planet of love, pleasure, beauty and what you value.',
  Mars: 'the planet of drive, heat, courage and conflict.',
  Jupiter: 'the planet of growth, generosity and faith, and of too much of a good thing. It lingers for months.',
  Saturn: 'the planet of the long haul, limits and what is built slowly. It lingers for months.',
  Uranus: 'the planet of the sudden, the free and the strange. It lingers for a year or more.',
  Neptune: 'the planet of dreams, longing and blur. It lingers for a year or more.',
  Pluto: 'the planet of depth, power and what has to change form. It lingers for years.',
};

// How the Celtic Cross positions talk to each other. {n} is the card in position n.
export const PAIRS = [
  { title: 'Front and back of mind', a: 5, b: 9, v: [
    'In front of my mind: {5}. At the back of it: {9}. They seem to pull the same way. What are they building together, and what would it take to trust that?',
    "My conscious aim looks stuck: {5}. The back of my mind holds {9}. Is the hope or fear behind my direction what's jamming it?",
    'My conscious direction is clear: {5}. But the back of my mind is uneasy: {9}. What am I not letting myself say out loud?',
    "Both are turned inward. What I'm thinking: {5}. What I'm quietly feeling: {9}. If I wrote the honest version of each, what would they say?"] },
  { title: 'Coming in, and what surrounds you', a: 6, b: 8, v: [
    'Arriving: {6}. The world it lands in: {8}. Who or what around me is ready to welcome it?',
    "What's coming in is delayed or tangled: {6}. Around me: {8}. Is something here holding the door shut?",
    'Arriving: {6}. But what surrounds me is strained: {8}. What do I need to clear, or set a boundary around, to make room for it?',
    "What's coming is tangled: {6}. So is what surrounds me: {8}. What's one thing in my circumstances I can change from my side?"] },
  { title: 'Root, and who you are', a: 3, b: 7, v: [
    'The root of all this: {3}. Who I am in it: {7}. How did that root grow me into this, and what of it do I want to keep feeding?',
    "The root is troubled: {3}. Yet I'm standing as {7}. What did I learn to become in answer to that root?",
    "The root is sound: {3}. But I'm not quite myself: {7}. Where have I drifted from what I grew from?",
    "The root is knotted: {3}. So is how I'm carrying myself: {7}. What's the oldest thread here, and what would loosening it change?"] },
  { title: 'The bridge', a: 2, v: [
    'Leaving: {4}. Arriving: {6}. Standing between them: {2}. How is it helping me cross, and how can I lean on it?',
    'Leaving: {4}. Arriving: {6}. In the doorway between them: {2}. What is it asking me to deal with before I can step through?'] },
  { title: 'The levers', a: 10, v: [
    "Where things are heading: {10}. My conscious direction: {5}. The back of my mind: {9}. If I want to arrive there, what do I keep thinking and feeling? If I don't, which do I change first?",
    'Where things head if nothing changes: {10}. My direction: {5}. My hopes and fears: {9}. Which of the two is easier to change this week, and what would I change it to?'] },
];
export const PAIR_SHAPE = [
  'Front of mind (5) and Hopes / fears (9): the front and the back of your mind.',
  'Coming in (6) and What surrounds you (8): what is arriving, and the world it lands in.',
  'Root (3) and Who you are (7): what you grew from, and who you are because of it.',
  'Cross / boon (2) is the bridge between Passing away (4) and Coming in (6).',
  'Front of mind (5) and Hopes / fears (9) lead to the Outcome (10): change either and the outcome moves.',
];

// What each planet's day and hour ask (content/planets-days-hours.md → assets/planets.json).
import PLANET_TEXT from '../assets/planets.json';
export { PLANET_TEXT };
export const PLANET_CARD = { Sun: 19, Moon: 2, Mercury: 1, Venus: 3, Mars: 16, Jupiter: 10, Saturn: 21 };
export const PLANET_FLOOR = {
  day: ["Write the date and the day's planet at the top of the page.", 'Write one word for how today feels.', 'Close the notebook. You opened it; that counts.'],
  hour: ["Write the time and the hour's planet at the top of the page.", 'Write one word for this hour.', 'Close the notebook. You opened it; that counts.'],
};
