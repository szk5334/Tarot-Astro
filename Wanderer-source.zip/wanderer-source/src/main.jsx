import React from 'react';
import { createRoot } from 'react-dom/client';
import SwissEphModule from './swisseph_factory.js';
import { initEngine } from './engine.js';
import App from './App.jsx';

const A = window.__ASSETS;
const bytes = b64 => fetch('data:application/octet-stream;base64,' + b64).then(r => r.arrayBuffer()).then(b => new Uint8Array(b));
window.__CARD = id => 'data:image/jpeg;base64,' + A.cards[id];

(async () => {
  const el = document.getElementById('root');
  try {
    const [wasm, sepl, semo, seas] = await Promise.all([A.wasm, A.sepl, A.semo, A.seas].map(bytes));
    await initEngine(SwissEphModule, wasm, { 'sepl_18.se1': sepl, 'semo_18.se1': semo, 'seas_18.se1': seas });
    createRoot(el).render(<App />);
  } catch (e) {
    el.innerHTML = '<p class="fatal">Wanderer could not start its ephemeris on this browser: ' + (e && e.message) + '</p>';
  }
})();
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(() => {});
