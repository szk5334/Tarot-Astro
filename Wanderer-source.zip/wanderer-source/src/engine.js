// Astronomy + astrology engine.
// Positions: Swiss Ephemeris (WebAssembly) reading the JPL-derived .se1 files (DE431, 0.001").
// Sunrise/sunset: USNO definition (Sun's centre at -0.8333 deg true altitude = upper limb with
// standard refraction), solved to the second and displayed rounded to the minute.

let M = null, XX, SERR, CUSPS, ASCMC, GEO, XIN, XAZ;
const FLG = 2 | 256; // SWIEPH | SPEED

export async function initEngine(factory, wasmBytes, files) {
  M = await factory({
    instantiateWasm: (imp, recv) => { WebAssembly.instantiate(wasmBytes, imp).then(r => recv(r.instance)); return {}; },
    print: () => {}, printErr: () => {},
  });
  try { M.FS.mkdir('/e'); } catch (e) {}
  for (const [n, b] of Object.entries(files)) M.FS.writeFile('/e/' + n, b);
  const p = M.allocateUTF8('/e'); M._swe_set_ephe_path_wrap(p);
  XX = M._malloc(48); SERR = M._malloc(256); CUSPS = M._malloc(13 * 8); ASCMC = M._malloc(10 * 8);
  GEO = M._malloc(24); XIN = M._malloc(24); XAZ = M._malloc(24);
}
const dbl = (p, i) => M.getValue(p + i * 8, 'double');
const setd = (p, i, v) => M.setValue(p + i * 8, v, 'double');

// ------------------------------------------------------------------ constants
export const SIGNS = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];
export const SIGN_GLYPH = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓'];
export const ELEMENT = ['Fire', 'Earth', 'Air', 'Water'];
export const MODALITY = ['Cardinal', 'Fixed', 'Mutable'];
export const BODIES = [
  ['Sun', 0, '☉'], ['Moon', 1, '☽'], ['Mercury', 2, '☿'], ['Venus', 3, '♀'], ['Mars', 4, '♂'],
  ['Jupiter', 5, '♃'], ['Saturn', 6, '♄'], ['Uranus', 7, '♅'], ['Neptune', 8, '♆'], ['Pluto', 9, '♇'],
  ['North Node', 11, '☊'], ['Chiron', 15, '⚷'], ['Lilith', 12, '⚸'],
];
export const BODY_ID = Object.fromEntries(BODIES.map(b => [b[0], b[1]]));
export const GLYPH = Object.fromEntries(BODIES.map(b => [b[0], b[2]]));
Object.assign(GLYPH, { Asc: 'AC', MC: 'MC', 'South Node': '☋', Fortune: '⊗', Vertex: 'Vx' });
export const WANDERERS = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'];
export const TRAD_RULER = ['Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter'];
const DOMICILE = { Sun: [4], Moon: [3], Mercury: [2, 5], Venus: [1, 6], Mars: [0, 7], Jupiter: [8, 11], Saturn: [9, 10] };
const EXALT = { Sun: 0, Moon: 1, Mercury: 5, Venus: 11, Mars: 9, Jupiter: 3, Saturn: 6 };
export const ASPECTS = [['conjunction', 0, '☌'], ['sextile', 60, '⚹'], ['square', 90, '□'], ['trine', 120, '△'], ['opposition', 180, '☍'], ['quincunx', 150, '⚻']];
export const CHALDEAN = ['Saturn', 'Jupiter', 'Mars', 'Sun', 'Venus', 'Mercury', 'Moon'];
export const DAY_RULER = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn']; // Sun..Sat (JS getDay order)

export const norm = x => ((x % 360) + 360) % 360;
export const wrap = x => norm(x + 180) - 180;
export const signOf = lon => Math.floor(norm(lon) / 30);
export const elementOf = s => ELEMENT[s % 4];
export const modalityOf = s => MODALITY[s % 3];

export function fmtLon(lon, secs = false) {
  lon = norm(lon); let s = signOf(lon);
  let tot = Math.round((lon - s * 30) * (secs ? 3600 : 60));
  const full = 30 * (secs ? 3600 : 60);
  if (tot >= full) { s = (s + 1) % 12; tot = 0; }
  const d = secs ? Math.floor(tot / 3600) : Math.floor(tot / 60);
  const m = secs ? Math.floor((tot % 3600) / 60) : tot % 60;
  const p2 = n => String(n).padStart(2, '0');
  return `${d}°${p2(m)}′${secs ? p2(tot % 60) + '″' : ''} ${SIGNS[s]}`;
}
export const degIn = lon => Math.floor(norm(lon) % 30);

export function dignity(body, lon) {
  if (!DOMICILE[body]) return null;
  const s = signOf(lon);
  if (DOMICILE[body].includes(s)) return 'domicile';
  if (s === EXALT[body]) return 'exaltation';
  if (DOMICILE[body].map(x => (x + 6) % 12).includes(s)) return 'detriment';
  if (s === (EXALT[body] + 6) % 12) return 'fall';
  return null;
}

// ------------------------------------------------------------------ time
export const jdFromMs = ms => ms / 86400000 + 2440587.5;
export const msFromJd = jd => (jd - 2440587.5) * 86400000;
const FMT = {};
function fields(ms, tz) {
  const f = FMT[tz] || (FMT[tz] = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', weekday: 'short' }));
  const o = {}; for (const p of f.formatToParts(new Date(ms))) o[p.type] = p.value;
  return { y: +o.year, mo: +o.month, d: +o.day, h: +o.hour % 24, mi: +o.minute, s: +o.second, wd: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(o.weekday) };
}
export const localFields = fields;
export function tzOffsetMin(ms, tz) {
  const f = fields(ms, tz);
  return Math.round((Date.UTC(f.y, f.mo - 1, f.d, f.h, f.mi, f.s) - Math.floor(ms / 1000) * 1000) / 60000);
}
// Wall-clock date + time in an IANA zone -> UTC ms, with DST gap/overlap notes.
export function localToUtc(dateStr, timeStr, tz) {
  const [y, mo, d] = dateStr.split('-').map(Number); const [h, mi] = timeStr.split(':').map(Number);
  const naive = Date.UTC(y, mo - 1, d, h, mi);
  const offs = [...new Set([tzOffsetMin(naive - 86400000, tz), tzOffsetMin(naive, tz), tzOffsetMin(naive + 86400000, tz)])];
  const ok = [];
  for (const off of offs) {
    const u = naive - off * 60000; const f = fields(u, tz);
    if (f.y === y && f.mo === mo && f.d === d && f.h === h && f.mi === mi) ok.push(u);
  }
  const notes = [];
  if (!ok.length) { notes.push('That clock time did not exist (daylight-saving jump); used the hour after.'); return { ms: naive - offs[0] * 60000, notes }; }
  if (ok.length > 1) notes.push('That clock time happened twice (daylight-saving fall back); used the first.');
  return { ms: Math.min(...ok), notes };
}
export function fmtLocal(ms, tz, opts) { return new Intl.DateTimeFormat('en-US', { timeZone: tz, ...opts }).format(new Date(Math.round(ms / 60000) * 60000)); }
export const fmtTime = (ms, tz) => fmtLocal(ms, tz, { hour: 'numeric', minute: '2-digit' });
export const fmtDate = (ms, tz) => fmtLocal(ms, tz, { weekday: 'short', month: 'short', day: 'numeric' });
export const fmtDateTime = (ms, tz) => fmtLocal(ms, tz, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
export function localMidnight(ms, tz) { const f = fields(ms, tz); return localToUtc(`${f.y}-${f.mo}-${f.d}`, '00:00', tz).ms; }
export const localDateKey = (ms, tz) => { const f = fields(ms, tz); return `${f.y}-${String(f.mo).padStart(2, '0')}-${String(f.d).padStart(2, '0')}`; };

// ------------------------------------------------------------------ raw ephemeris
export function calc(jd, id, flags = FLG) {
  const r = M._swe_calc_ut_wrap(jd, id, flags, XX, SERR);
  if (r < 0) throw new Error(M.UTF8ToString(SERR));
  return [dbl(XX, 0), dbl(XX, 1), dbl(XX, 2), dbl(XX, 3)];
}
export const lonOf = (body, jd) => calc(jd, BODY_ID[body])[0];
export const speedOf = (body, jd) => calc(jd, BODY_ID[body])[3];
export function houses(jd, lat, lon, hsys = 'P') {
  M._swe_houses_wrap(jd, lat, lon, hsys.charCodeAt(0), CUSPS, ASCMC);
  const c = []; for (let i = 1; i <= 12; i++) c.push(dbl(CUSPS, i));
  return { cusps: c, asc: dbl(ASCMC, 0), mc: dbl(ASCMC, 1), vertex: dbl(ASCMC, 3) };
}
export function sunAltitude(jd, lat, lon) {
  const [l, b, d] = calc(jd, 0, 2);
  setd(GEO, 0, lon); setd(GEO, 1, lat); setd(GEO, 2, 0);
  setd(XIN, 0, l); setd(XIN, 1, b); setd(XIN, 2, d);
  M._swe_azalt_wrap(jd, 0, GEO, 0, 10, XIN, XAZ);
  return dbl(XAZ, 1); // true (unrefracted) altitude of the centre
}
const H0 = -50 / 60; // USNO: -0.8333 deg
function bisect(f, a, b, it = 40) { let fa = f(a); for (let i = 0; i < it; i++) { const m = (a + b) / 2, fm = f(m); if ((fm < 0) === (fa < 0)) { a = m; fa = fm; } else b = m; } return (a + b) / 2; }
// next sunrise (rise=true) or sunset after jd, searching up to `span` days; null in polar day/night
export function sunEvent(jd, lat, lon, rise = true, span = 1.5) {
  const f = j => sunAltitude(j, lat, lon) - H0;
  const step = 1 / 96; let a = jd, fa = f(a);
  for (let t = jd + step; t <= jd + span; t += step) {
    const ft = f(t);
    if (rise ? fa < 0 && ft >= 0 : fa >= 0 && ft < 0) return bisect(f, a, t, 30);
    a = t; fa = ft;
  }
  return null;
}

// ------------------------------------------------------------------ chart
export function houseOf(lon, cusps) {
  for (let i = 0; i < 12; i++) { const a = cusps[i], b = cusps[(i + 1) % 12]; if (norm(lon - a) < norm(b - a)) return i + 1; }
  return 12;
}
export function balance(pts, f) {
  const out = {};
  for (const n of ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'Asc', 'MC'])
    if (pts[n]) { const k = f(signOf(pts[n].lon)); out[k] = (out[k] || 0) + (['Sun', 'Moon', 'Asc'].includes(n) ? 2 : 1); }
  return out;
}
export function computeChart(jd, lat, lon, hsys = 'P') {
  const pts = {};
  for (const [name, id] of BODIES) {
    const [lo, la, , sp] = calc(jd, id);
    pts[name] = { lon: lo, lat: la, speed: sp, retro: sp < 0 && !['North Node', 'Lilith'].includes(name) };
  }
  pts['South Node'] = { lon: norm(pts['North Node'].lon + 180), speed: pts['North Node'].speed, retro: false };
  const notes = [];
  if (hsys === 'P' && Math.abs(lat) > 66) { hsys = 'W'; notes.push('Placidus houses are undefined this far north or south; using Whole Sign houses.'); }
  const H = houses(jd, lat, lon, hsys);
  pts.Asc = { lon: H.asc, speed: 0 }; pts.MC = { lon: H.mc, speed: 0 }; pts.Vertex = { lon: H.vertex, speed: 0 };
  for (const [n, p] of Object.entries(pts)) {
    if (!['Asc', 'MC'].includes(n)) p.house = houseOf(p.lon, H.cusps);
    p.wsHouse = ((signOf(p.lon) - signOf(H.asc)) + 12) % 12 + 1;
  }
  const day = pts.Sun.house >= 7;
  const fort = day ? norm(H.asc + pts.Moon.lon - pts.Sun.lon) : norm(H.asc + pts.Sun.lon - pts.Moon.lon);
  pts.Fortune = { lon: fort, speed: 0, house: houseOf(fort, H.cusps) };
  for (const [n, p] of Object.entries(pts)) { p.sign = signOf(p.lon); p.dignity = dignity(n, p.lon); }
  return {
    jd, lat, lon, points: pts, cusps: H.cusps, hsys, sect: day ? 'day' : 'night',
    ruler: TRAD_RULER[signOf(H.asc)], notes,
    elements: balance(pts, s => ELEMENT[s % 4]), modalities: balance(pts, s => MODALITY[s % 3]),
  };
}

// Natal chart for a saved person. Unknown time -> sunrise chart.
export function natalFor(p, hsys = 'P') {
  const known = !!p.time;
  let ms, notes = [];
  if (known) { const r = localToUtc(p.date, p.time, p.tz); ms = r.ms; notes = r.notes; }
  else {
    const mid = localToUtc(p.date, '00:00', p.tz).ms;
    const sr = sunEvent(jdFromMs(mid), p.lat, p.lon, true, 1);
    ms = sr ? msFromJd(sr) : localToUtc(p.date, '12:00', p.tz).ms;
    notes.push(`Birth time unknown, so this is a sunrise chart (${fmtTime(ms, p.tz)}). Planet signs and planet-to-planet aspects are reliable; the rising sign, houses and the Moon's exact degree are symbolic.`);
  }
  const ch = computeChart(jdFromMs(ms), p.lat, p.lon, hsys);
  ch.notes = [...notes, ...ch.notes]; ch.timeKnown = known; ch.birthMs = ms; ch.person = p;
  return ch;
}

// ------------------------------------------------------------------ aspects
export const NATAL_ORB = { conjunction: 8, opposition: 8, square: 7, trine: 7, sextile: 5, quincunx: 2.5 };
export const TRANSIT_ORB = { Moon: 4, Sun: 2, Mercury: 1.5, Venus: 1.5, Mars: 2, Jupiter: 2.5, Saturn: 2.5, Uranus: 2, Neptune: 2, Pluto: 2, Chiron: 1.5, 'North Node': 1.5 };
const CONJ_ONLY = new Set(['North Node', 'South Node', 'Lilith', 'Fortune', 'Vertex']);
const WEIGHT = { Pluto: 5, Neptune: 5, Uranus: 5, Saturn: 5, Jupiter: 4, Chiron: 3, 'North Node': 3, Mars: 2, Sun: 2, Venus: 1, Mercury: 1, Moon: 0.5 };
export function findAspect(a, b, allowed, orbFn) {
  const sep = Math.abs(wrap(a - b)); let best = null;
  for (const [name, ang, glyph] of ASPECTS) {
    if (!allowed.includes(name)) continue;
    const o = Math.abs(sep - ang);
    if (o <= orbFn(name) && (!best || o < best.orb)) best = { aspect: name, orb: o, glyph, angle: ang };
  }
  return best;
}
const NATAL_SET = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'Chiron', 'North Node', 'Asc', 'MC'];
export function natalAspects(ch) {
  const names = NATAL_SET.filter(n => ch.points[n] && (ch.timeKnown !== false || !['Asc', 'MC'].includes(n)));
  const out = [];
  names.forEach((a, i) => names.slice(i + 1).forEach(b => {
    if (a === 'Asc' && b === 'MC') return;
    const lum = ['Sun', 'Moon'].includes(a) || ['Sun', 'Moon'].includes(b);
    const allowed = CONJ_ONLY.has(a) || CONJ_ONLY.has(b) ? ['conjunction'] : ASPECTS.map(x => x[0]);
    const asp = findAspect(ch.points[a].lon, ch.points[b].lon, allowed, n => NATAL_ORB[n] + (lum && n !== 'quincunx' ? 1 : 0));
    if (asp) out.push({ a, b, ...asp });
  }));
  return out.sort((x, y) => x.orb - y.orb);
}
export function exactDates(tbody, nlon, ang, jdNow) {
  const [span, step] = ({ Moon: [1.5, 0.04], Sun: [20, 0.25], Mercury: [40, 0.25], Venus: [40, 0.25], Mars: [60, 0.5] })[tbody] || [420, 2];
  const hits = [];
  for (const sgn of (ang === 0 || ang === 180) ? [1] : [1, -1]) {
    const f = jd => wrap(lonOf(tbody, jd) - nlon - sgn * ang);
    let jd = jdNow - span, prev = f(jd);
    while (jd < jdNow + span) {
      const jd2 = jd + step, cur = f(jd2);
      if (prev === 0 || (prev * cur < 0 && Math.abs(prev - cur) < 90)) hits.push(bisect(f, jd, jd2, 40));
      jd = jd2; prev = cur;
    }
  }
  return hits.sort((a, b) => a - b);
}
export function transitsTo(natal, sky, jdNow, { bodies = Object.keys(TRANSIT_ORB), withDates = true } = {}) {
  const targets = NATAL_SET.filter(n => natal.points[n] && (natal.timeKnown !== false || !['Asc', 'MC'].includes(n)));
  const out = [];
  for (const t of bodies) {
    const tl = sky.points[t].lon;
    for (const n of targets) {
      const allowed = CONJ_ONLY.has(t) || CONJ_ONLY.has(n) ? ['conjunction', 'opposition'] : ['conjunction', 'sextile', 'square', 'trine', 'opposition'];
      const nl = natal.points[n].lon;
      const asp = findAspect(tl, nl, allowed, () => TRANSIT_ORB[t]);
      if (!asp) continue;
      const soon = Math.abs(Math.abs(wrap(lonOf(t, jdNow + 0.05) - nl)) - asp.angle);
      const hits = withDates ? exactDates(t, nl, asp.angle, jdNow) : [];
      out.push({
        transit: t, natal: n, ...asp, applying: soon < asp.orb, retro: sky.points[t].retro,
        last: hits.filter(h => h <= jdNow).pop() ?? null, next: hits.filter(h => h > jdNow).slice(0, 3),
        weight: (WEIGHT[t] || 1) * (['Sun', 'Moon', 'Asc', 'MC'].includes(n) ? 1.5 : 1) * (['conjunction', 'square', 'opposition'].includes(asp.aspect) ? 1.3 : 1),
      });
    }
  }
  return out.sort((a, b) => b.weight - a.weight || a.orb - b.orb);
}

// ------------------------------------------------------------------ the moment
export function moonPhase(jd) {
  const e = norm(lonOf('Moon', jd) - lonOf('Sun', jd));
  const names = ['New Moon', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous', 'Full Moon', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent'];
  const age = (jd - lastLunation(jd, 0));
  return { name: names[Math.floor(((e + 22.5) % 360) / 45)], elong: e, illum: (1 - Math.cos(e * Math.PI / 180)) / 2, age };
}
const phaseAng = jd => norm(lonOf('Moon', jd) - lonOf('Sun', jd));
function lastLunation(jd, ang) {
  const f = j => wrap(phaseAng(j) - ang); let t = jd;
  while (true) { const t2 = t - 0.25; if (f(t2) < 0 && f(t) >= 0) return bisect(f, t2, t); t = t2; }
}
export function nextLunations(jd, n = 4) {
  const out = []; const names = ['New Moon', 'First Quarter', 'Full Moon', 'Last Quarter'];
  let t = jd, pa = phaseAng(t);
  while (out.length < n) {
    const t2 = t + 0.1, pb = phaseAng(t2);
    [0, 90, 180, 270].forEach((ang, q) => {
      const da = wrap(pa - ang), db = wrap(pb - ang);
      if (da < 0 && db >= 0 && db - da < 90) { const tm = bisect(j => wrap(phaseAng(j) - ang), t, t2); out.push({ jd: tm, name: names[q], sign: signOf(lonOf('Moon', tm)), lon: lonOf('Moon', tm) }); }
    });
    t = t2; pa = pb;
  }
  return out.slice(0, n);
}
export function planetaryHour(jd, lat, lon, tz) {
  let sr = sunEvent(jd - 1.05, lat, lon, true, 1.2);
  if (sr == null) return null;
  let nxt = sunEvent(sr + 0.01, lat, lon, true, 1.2);
  while (nxt != null && nxt <= jd) { sr = nxt; nxt = sunEvent(sr + 0.01, lat, lon, true, 1.2); }
  const ss = sunEvent(sr, lat, lon, false, 1);
  if (nxt == null || ss == null) return null;
  const dayRuler = DAY_RULER[fields(msFromJd(sr), tz).wd];
  const isDay = jd < ss;
  const hl = isDay ? (ss - sr) / 12 : (nxt - ss) / 12;
  const idx = Math.min(23, isDay ? Math.floor((jd - sr) / hl) : 12 + Math.floor((jd - ss) / hl));
  const ci = CHALDEAN.indexOf(dayRuler);
  const h0 = (isDay ? sr : ss) + (idx % 12) * hl;
  return {
    dayRuler, ruler: CHALDEAN[(ci + idx) % 7], next: CHALDEAN[(ci + idx + 1) % 7], number: idx % 12 + 1, part: isDay ? 'day' : 'night',
    sunrise: msFromJd(sr), sunset: msFromJd(ss), nextSunrise: msFromJd(nxt), start: msFromJd(h0), end: msFromJd(h0 + hl), minutes: Math.round(hl * 1440),
  };
}
// All 24 planetary hours of the current planetary day (sunrise to next sunrise).
export function planetaryDay(jd, lat, lon, tz) {
  let sr = sunEvent(jd - 1.05, lat, lon, true, 1.2);
  if (sr == null) return null;
  let nxt = sunEvent(sr + 0.01, lat, lon, true, 1.2);
  while (nxt != null && nxt <= jd) { sr = nxt; nxt = sunEvent(sr + 0.01, lat, lon, true, 1.2); }
  const ss = sunEvent(sr, lat, lon, false, 1);
  if (nxt == null || ss == null || ss > nxt) return null;
  const dayRuler = DAY_RULER[fields(msFromJd(sr), tz).wd];
  const ci = CHALDEAN.indexOf(dayRuler), dl = (ss - sr) / 12, nl = (nxt - ss) / 12;
  const hours = Array.from({ length: 24 }, (_, i) => {
    const day = i < 12, s0 = day ? sr + i * dl : ss + (i - 12) * nl;
    return { start: msFromJd(s0), end: msFromJd(s0 + (day ? dl : nl)), ruler: CHALDEAN[(ci + i) % 7], day };
  });
  const now = msFromJd(jd), cur = hours.findIndex(h => now >= h.start && now < h.end);
  return { dayRuler, hours, current: cur, hour: hours[cur], sunrise: msFromJd(sr), sunset: msFromJd(ss), nextSunrise: msFromJd(nxt) };
}

// The Moon's void-of-course window that ends at its next sign change.
const VOC_ANG = [0, 60, 90, 120, 180, 240, 270, 300];
export function voidOfCourse(jd) {
  const s0 = signOf(lonOf('Moon', jd));
  let t = jd; while (signOf(lonOf('Moon', t + 0.125)) === s0) t += 0.125;
  const exit = bisect(j => (signOf(lonOf('Moon', j)) === s0 ? -1 : 1), t, t + 0.125);
  let e = jd; while (signOf(lonOf('Moon', e - 0.125)) === s0) e -= 0.125;
  const entry = e - 0.125;
  const rel = (p, x) => norm(lonOf('Moon', x) - lonOf(p, x));
  let tb = exit;
  while (tb > entry) {
    const ta = Math.max(entry, tb - 2 / 24); let best = null;
    for (const p of ['Sun', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'])
      for (const ang of VOC_ANG) {
        const da = wrap(rel(p, ta) - ang), db = wrap(rel(p, tb) - ang);
        if (da < 0 && db >= 0 && db - da < 60) { const tm = bisect(x => wrap(rel(p, x) - ang), ta, tb); if (!best || tm > best.jd) best = { jd: tm, planet: p, ang }; }
      }
    if (best) return { start: best.jd, end: exit, last: best, nextSign: (s0 + 1) % 12 };
    tb = ta;
  }
  return { start: entry, end: exit, last: null, nextSign: (s0 + 1) % 12 };
}
export function retrogrades(jd) {
  const out = [];
  for (const b of ['Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'Chiron']) {
    if (speedOf(b, jd) >= 0) continue;
    let a = jd; while (speedOf(b, a - 1) < 0) a -= 1;
    let z = jd; while (speedOf(b, z + 1) < 0) z += 1;
    out.push({ body: b, from: bisect(x => (speedOf(b, x) >= 0 ? -1 : 1), a - 1, a), to: bisect(x => (speedOf(b, x) < 0 ? -1 : 1), z, z + 1) });
  }
  return out;
}
// Ingresses and stations between two moments.
export function skyEvents(j0, j1) {
  const out = [];
  for (const b of ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto']) {
    const step = b === 'Moon' ? 1 / 24 : 1 / 6;
    let t = j0, s0 = signOf(lonOf(b, t)), v0 = speedOf(b, t);
    while (t < j1) {
      const t2 = Math.min(j1, t + step), s1 = signOf(lonOf(b, t2));
      if (s1 !== s0) out.push({ jd: bisect(x => (signOf(lonOf(b, x)) === s0 ? -1 : 1), t, t2), kind: 'ingress', body: b, sign: s1 });
      if (!['Sun', 'Moon'].includes(b)) {
        const v1 = speedOf(b, t2);
        if ((v0 < 0) !== (v1 < 0)) { const tm = bisect(x => ((speedOf(b, x) < 0) === (v0 < 0) ? -1 : 1), t, t2); out.push({ jd: tm, kind: 'station', body: b, dir: v1 < 0 ? 'retrograde' : 'direct', lon: lonOf(b, tm) }); }
        v0 = v1;
      }
      s0 = s1; t = t2;
    }
  }
  return out.sort((a, b) => a.jd - b.jd);
}
export function profection(birthMs, nowMs, natal, tz) {
  const b = fields(birthMs, tz), n = fields(nowMs, tz);
  const age = n.y - b.y - ((n.mo < b.mo || (n.mo === b.mo && n.d < b.d)) ? 1 : 0);
  const s = (signOf(natal.points.Asc.lon) + age) % 12;
  return { age, house: age % 12 + 1, sign: s, lord: TRAD_RULER[s] };
}

// ------------------------------------------------------------------ relationships
const SYN = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'Chiron', 'North Node', 'Asc', 'MC'];
const SYN_ORB = { conjunction: 7, opposition: 7, square: 6, trine: 6, sextile: 4, quincunx: 2 };
const PERSONAL = new Set(['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Asc']);
export function synastry(A, B) {
  const ok = (ch, n) => ch.points[n] && (ch.timeKnown || !['Asc', 'MC'].includes(n));
  const out = [];
  for (const a of SYN) { if (!ok(A, a)) continue;
    for (const b of SYN) { if (!ok(B, b)) continue;
      const node = a === 'North Node' || b === 'North Node';
      const pers = PERSONAL.has(a) || PERSONAL.has(b);
      const asp = findAspect(A.points[a].lon, B.points[b].lon, node ? ['conjunction', 'opposition'] : Object.keys(SYN_ORB),
        n => SYN_ORB[n] - (!pers && !['conjunction', 'opposition'].includes(n) ? 2 : 0) - (pers ? 0 : 1));
      if (!asp) continue;
      let w = (PERSONAL.has(a) ? 3 : 1) * (PERSONAL.has(b) ? 3 : 1);
      if (['Sun', 'Moon', 'Asc'].includes(a) || ['Sun', 'Moon', 'Asc'].includes(b)) w *= 1.5;
      if (['conjunction', 'opposition', 'square'].includes(asp.aspect)) w *= 1.3;
      w /= 1 + asp.orb;
      out.push({ a, b, ...asp, weight: w, tone: ['trine', 'sextile'].includes(asp.aspect) ? 'flowing' : ['square', 'opposition'].includes(asp.aspect) ? 'dynamic' : asp.aspect === 'quincunx' ? 'adjusting' : 'fusing' });
    }
  }
  return out.sort((x, y) => y.weight - x.weight);
}
export function overlays(host, guest) {
  if (!host.timeKnown) return [];
  return ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'].map(p => ({ planet: p, house: houseOf(guest.points[p].lon, host.cusps) }));
}
const midpoint = (a, b) => norm(a + wrap(b - a) / 2);
export function composite(A, B) {
  const pts = {};
  for (const n of [...SYN, 'Vertex']) if (A.points[n] && B.points[n]) pts[n] = { lon: midpoint(A.points[n].lon, B.points[n].lon) };
  const both = A.timeKnown && B.timeKnown;
  const cusps = Array.from({ length: 12 }, (_, i) => norm(pts.Asc.lon + 30 * i));
  for (const [n, p] of Object.entries(pts)) { p.sign = signOf(p.lon); if (both && n !== 'Asc' && n !== 'MC') p.house = houseOf(p.lon, cusps); }
  return { points: pts, cusps, timeKnown: both, elements: balance(pts, s => ELEMENT[s % 4]) };
}
export function davison(A, B) {
  const jd = (A.jd + B.jd) / 2, lat = (A.lat + B.lat) / 2;
  let lon = midpoint(norm(A.lon), norm(B.lon)); if (lon > 180) lon -= 360;
  const ch = computeChart(jd, lat, lon, 'P'); ch.timeKnown = A.timeKnown && B.timeKnown; return ch;
}

// ------------------------------------------------------------------ USNO self-test
export const USNO_CHECKS = [
  ['Sunrise, London, 21 Mar 2025', '2025-03-21T06:00Z', () => sunEvent(jdFromMs(Date.UTC(2025, 2, 21)), 51.48, 0, true)],
  ['Sunset, London, 21 Mar 2025', '2025-03-21T18:15Z', () => sunEvent(jdFromMs(Date.UTC(2025, 2, 21)), 51.48, 0, false)],
  ['Last Quarter Moon, Mar 2025', '2025-03-22T11:29Z', () => nextLunations(jdFromMs(Date.UTC(2025, 2, 21)), 1)[0].jd],
  ['March equinox 2026', '2026-03-20T14:46Z', () => sunCross(0, 2026)],
  ['June solstice 2026', '2026-06-21T08:24Z', () => sunCross(90, 2026)],
  ['September equinox 2026', '2026-09-23T00:05Z', () => sunCross(180, 2026)],
  ['December solstice 2026', '2026-12-21T20:50Z', () => sunCross(270, 2026)],
];
function sunCross(L, year) {
  let t = jdFromMs(Date.UTC(year, 0, 1));
  for (; ; t += 1) { const a = wrap(lonOf('Sun', t) - L), b = wrap(lonOf('Sun', t + 1) - L); if (a < 0 && b >= 0) return bisect(j => wrap(lonOf('Sun', j) - L), t, t + 1); }
}
export function runChecks() {
  return USNO_CHECKS.map(([label, ref, fn]) => { const ms = msFromJd(fn()); const diff = (ms - Date.parse(ref)) / 1000; return { label, ref, ms, diff, ok: Math.abs(diff) < 60 }; });
}
