import React, { useState, useEffect, useRef } from 'react';
import { GLYPH, SIGN_GLYPH, norm, signOf, degIn, wrap } from './engine.js';
import CITIES from '../assets/cities.json';

const VS = '\uFE0E'; // text presentation, so Android doesn't turn ♈ into an emoji
const COLOR = { Sun: 'sun', Moon: 'moon', Mercury: 'mercury', Venus: 'venus', Mars: 'mars', Jupiter: 'jupiter', Saturn: 'saturn' };
export function G({ p, sign, children }) {
  if (sign !== undefined) return <span className="glyph">{SIGN_GLYPH[sign] + VS}</span>;
  const g = GLYPH[p] || p;
  return <span className={`glyph c-${COLOR[p] || 'outer'}`} aria-hidden="true">{(g.length === 1 ? g + VS : g)}{children}</span>;
}
export const md = s => s.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g).map((x, i) =>
  x.startsWith('**') ? <strong key={i}>{x.slice(2, -2)}</strong> : x.startsWith('*') && x.length > 2 ? <em key={i}>{x.slice(1, -1)}</em> : x);

export function Expand({ head, children, open: o = false, className = '' }) {
  const [open, setOpen] = useState(o);
  return (
    <div className={`expand ${open ? 'open' : ''} ${className}`}>
      <button className="expand-head" aria-expanded={open} onClick={() => setOpen(!open)}>{head}<span className="chev" aria-hidden="true">{open ? '−' : '+'}</span></button>
      {open && <div className="expand-body">{children}</div>}
    </div>
  );
}

// The Moon as it looks tonight: lit limb plus an elliptical terminator.
export function MoonDisc({ elong, size = 132 }) {
  const r = size / 2 - 4, c = size / 2, e = norm(elong) * Math.PI / 180;
  const waxing = norm(elong) < 180;
  const rx = Math.abs(Math.cos(e)) * r;
  const gibbous = Math.cos(e) < 0;
  // lit limb: right half when waxing, left half when waning (northern-hemisphere view)
  const limbSweep = waxing ? 1 : 0;
  const termSweep = waxing ? (gibbous ? 1 : 0) : (gibbous ? 0 : 1);
  const d = `M ${c} ${c - r} A ${r} ${r} 0 0 ${limbSweep} ${c} ${c + r} A ${rx} ${r} 0 0 ${termSweep} ${c} ${c - r} Z`;
  return (
    <svg className="moon" width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Tonight's Moon">
      <defs><radialGradient id="mg" cx="40%" cy="38%"><stop offset="0%" stopColor="var(--moonlit-hi)" /><stop offset="100%" stopColor="var(--moonlit)" /></radialGradient></defs>
      <circle cx={c} cy={c} r={r} fill="var(--moondark)" />
      <path d={d} fill="url(#mg)" />
      <circle cx={c} cy={c} r={r} fill="none" stroke="var(--rule)" strokeWidth="1" />
    </svg>
  );
}

const WHEEL_PTS = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'North Node', 'Chiron'];
function spread(lons, gap = 8) {
  const items = Object.entries(lons).sort((a, b) => a[1] - b[1]);
  const disp = Object.fromEntries(items);
  for (let k = 0; k < 40; k++) {
    let moved = false;
    for (let i = 0; i < items.length; i++) {
      const [n1] = items[i], [n2] = items[(i + 1) % items.length];
      const d = norm(disp[n2] - disp[n1]);
      if (items.length > 1 && d < gap) { disp[n1] = norm(disp[n1] - (gap - d) / 2); disp[n2] = norm(disp[n2] + (gap - d) / 2); moved = true; }
    }
    if (!moved) break;
  }
  return disp;
}
const ASP_COLOR = { conjunction: 'var(--gilt)', sextile: 'var(--flow)', trine: 'var(--flow)', square: 'var(--friction)', opposition: 'var(--friction)', quincunx: 'var(--muted)' };
export function Wheel({ natal, outer, lines = [], size = 340 }) {
  const asc = natal.timeKnown ? natal.points.Asc.lon : natal.points.Sun.lon;
  const C = size / 2, R = size / 2 - 6;
  const xy = (lon, r) => { const a = Math.PI * (180 + (lon - asc)) / 180; return [C + r * Math.cos(a), C - r * Math.sin(a)]; };
  const ring = (pts, r, cls) => {
    const lons = Object.fromEntries(WHEEL_PTS.filter(n => pts[n]).map(n => [n, pts[n].lon]));
    const disp = spread(lons, size < 300 ? 10 : 8);
    return WHEEL_PTS.filter(n => pts[n]).map(n => {
      const [x0, y0] = xy(pts[n].lon, r.tick[0]), [x1, y1] = xy(pts[n].lon, r.tick[1]);
      const [gx, gy] = xy(disp[n], r.glyph), [dx, dy] = xy(disp[n], r.deg);
      return (
        <g key={cls + n} className={cls}>
          <line x1={x0} y1={y0} x2={x1} y2={y1} className="tick" />
          <text x={gx} y={gy} className={`wglyph c-${COLOR[n] || 'outer'}`} textAnchor="middle" dominantBaseline="central">{GLYPH[n] + VS}</text>
          <text x={dx} y={dy} className="wdeg" textAnchor="middle" dominantBaseline="central">{degIn(pts[n].lon)}{pts[n].retro ? 'r' : ''}</text>
        </g>
      );
    });
  };
  const rz = [R, R * 0.86], rIn = outer ? R * 0.52 : R * 0.42;
  return (
    <svg className="wheel" viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Chart wheel">
      <circle cx={C} cy={C} r={rz[0]} className="wring" /><circle cx={C} cy={C} r={rz[1]} className="wring" />
      <circle cx={C} cy={C} r={rIn} className="wring faint" />
      {outer && <circle cx={C} cy={C} r={R * 0.70} className="wring faint" />}
      {Array.from({ length: 12 }, (_, s) => {
        const [x0, y0] = xy(s * 30, rz[1]), [x1, y1] = xy(s * 30, rz[0]), [gx, gy] = xy(s * 30 + 15, (rz[0] + rz[1]) / 2);
        return <g key={s}><line x1={x0} y1={y0} x2={x1} y2={y1} className="tick" /><text x={gx} y={gy} className={`zglyph el-${s % 4}`} textAnchor="middle" dominantBaseline="central">{SIGN_GLYPH[s] + VS}</text></g>;
      })}
      {natal.timeKnown && natal.cusps.map((c, i) => {
        const ang = i % 3 === 0, [x0, y0] = xy(c, rIn), [x1, y1] = xy(c, ang ? rz[1] : (outer ? R * 0.70 : rz[1]));
        const mid = c + norm(natal.cusps[(i + 1) % 12] - c) / 2, [hx, hy] = xy(mid, rIn + 9);
        return <g key={'c' + i}><line x1={x0} y1={y0} x2={x1} y2={y1} className={ang ? 'cusp angle' : 'cusp'} /><text x={hx} y={hy} className="hnum" textAnchor="middle" dominantBaseline="central">{i + 1}</text></g>;
      })}
      {lines.map((l, i) => { const [x0, y0] = xy(l.a, rIn), [x1, y1] = xy(l.b, rIn); return <line key={'l' + i} x1={x0} y1={y0} x2={x1} y2={y1} stroke={ASP_COLOR[l.aspect]} strokeWidth={Math.max(0.6, 2 - l.orb * 0.4)} opacity="0.8" />; })}
      {ring(natal.points, outer ? { glyph: R * 0.61, deg: R * 0.555, tick: [rIn, rIn + 4] } : { glyph: R * 0.72, deg: R * 0.62, tick: [rz[1] - 5, rz[1]] }, 'natal')}
      {outer && ring(outer.points, { glyph: R * 0.79, deg: R * 0.735, tick: [rz[1] - 5, rz[1]] }, 'transit')}
      {natal.timeKnown && [['AC', natal.points.Asc.lon], ['MC', natal.points.MC.lon]].map(([t, l]) => { const [x, y] = xy(l, R + 0.5); return <text key={t} x={x} y={y} className="angle-label" textAnchor="middle" dominantBaseline="central">{t}</text>; })}
    </svg>
  );
}

// Birthplace search: offline list of ~34,000 towns first, then Open-Meteo online.
const REGIONS = CITIES.r, TZS = CITIES.tz;
function searchOffline(q) {
  const [name, ...rest] = q.toLowerCase().split(',').map(s => s.trim());
  const reg = rest.join(' ');
  if (!name) return [];
  const out = [];
  for (const c of CITIES.c) {
    const n = c[0].toLowerCase();
    if (!(n === name || n.startsWith(name))) continue;
    const r = REGIONS[c[1]] || '';
    if (reg && !r.toLowerCase().includes(reg) && !abbrevMatch(reg, r)) continue;
    out.push({ label: `${c[0]}, ${r}`, lat: c[2], lon: c[3], tz: TZS[c[4]], exact: n === name });
    if (out.length > 60) break;
  }
  return out.sort((a, b) => b.exact - a.exact).slice(0, 8);
}
const US = { al: 'alabama', ak: 'alaska', az: 'arizona', ar: 'arkansas', ca: 'california', co: 'colorado', ct: 'connecticut', de: 'delaware', fl: 'florida', ga: 'georgia', hi: 'hawaii', id: 'idaho', il: 'illinois', in: 'indiana', ia: 'iowa', ks: 'kansas', ky: 'kentucky', la: 'louisiana', me: 'maine', md: 'maryland', ma: 'massachusetts', mi: 'michigan', mn: 'minnesota', ms: 'mississippi', mo: 'missouri', mt: 'montana', ne: 'nebraska', nv: 'nevada', nh: 'new hampshire', nj: 'new jersey', nm: 'new mexico', ny: 'new york', nc: 'north carolina', nd: 'north dakota', oh: 'ohio', ok: 'oklahoma', or: 'oregon', pa: 'pennsylvania', ri: 'rhode island', sc: 'south carolina', sd: 'south dakota', tn: 'tennessee', tx: 'texas', ut: 'utah', vt: 'vermont', va: 'virginia', wa: 'washington', wv: 'west virginia', wi: 'wisconsin', wy: 'wyoming', dc: 'district of columbia' };
const abbrevMatch = (q, r) => US[q] && r.toLowerCase().startsWith(US[q]);
async function searchOnline(q) {
  const name = q.split(',')[0].trim();
  const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=10&language=en&format=json`);
  const j = await res.json();
  const rest = q.split(',').slice(1).join(' ').trim().toLowerCase();
  return (j.results || []).map(r => ({ label: [r.name, r.admin1, r.country].filter(Boolean).join(', '), lat: r.latitude, lon: r.longitude, tz: r.timezone }))
    .filter(r => !rest || r.label.toLowerCase().includes(rest) || abbrevMatch(rest, r.label.split(', ')[1] || ''));
}
export function PlaceSearch({ value, onPick, label = 'Birthplace' }) {
  const [q, setQ] = useState(value?.label || '');
  const [res, setRes] = useState([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [manual, setManual] = useState(false);
  const [m, setM] = useState({ lat: '', lon: '', tz: Intl.DateTimeFormat().resolvedOptions().timeZone });
  useEffect(() => { if (q.length >= 2 && q !== value?.label) setRes(searchOffline(q)); else setRes([]); }, [q]);
  const online = async () => {
    setBusy(true); setMsg('');
    try { const r = await searchOnline(q); setRes(r); if (!r.length) setMsg('No towns found online either. Enter the coordinates instead.'); }
    catch { setMsg('Online search needs a connection. Enter the coordinates instead.'); }
    setBusy(false);
  };
  const zones = typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : [m.tz];
  return (
    <div className="place">
      <label className="field"><span>{label}</span>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Town, state or country" autoComplete="off" /></label>
      {value && q === value.label && <p className="hint">{value.lat.toFixed(4)}, {value.lon.toFixed(4)} · {value.tz}</p>}
      {res.length > 0 && <ul className="results">{res.map((r, i) => <li key={i}><button onClick={() => { onPick(r); setQ(r.label); setRes([]); }}>{r.label}</button></li>)}</ul>}
      {q.length >= 2 && q !== value?.label && <div className="row gap"><button className="link" onClick={online} disabled={busy}>{busy ? 'Searching…' : 'Not listed? Search online'}</button><button className="link" onClick={() => setManual(!manual)}>Enter coordinates</button></div>}
      {msg && <p className="hint">{msg}</p>}
      {manual && <div className="manual">
        <label className="field"><span>Latitude (north +)</span><input inputMode="decimal" value={m.lat} onChange={e => setM({ ...m, lat: e.target.value })} /></label>
        <label className="field"><span>Longitude (east +, west −)</span><input inputMode="decimal" value={m.lon} onChange={e => setM({ ...m, lon: e.target.value })} /></label>
        <label className="field"><span>Time zone</span><select value={m.tz} onChange={e => setM({ ...m, tz: e.target.value })}>{zones.map(z => <option key={z}>{z}</option>)}</select></label>
        <button className="btn" onClick={() => { const lat = parseFloat(m.lat), lon = parseFloat(m.lon); if (isFinite(lat) && isFinite(lon)) { const r = { label: q || `${lat}, ${lon}`, lat, lon, tz: m.tz }; onPick(r); setQ(r.label); setManual(false); } }}>Use these coordinates</button>
      </div>}
    </div>
  );
}

export function Bars({ data, order }) {
  const max = Math.max(1, ...Object.values(data));
  return <div className="bars">{order.map(k => <div key={k} className="bar"><span>{k}</span><i style={{ width: `${(100 * (data[k] || 0)) / max}%` }} /><b>{data[k] || 0}</b></div>)}</div>;
}
export const useInterval = (fn, ms) => { const r = useRef(fn); r.current = fn; useEffect(() => { const t = setInterval(() => r.current(), ms); return () => clearInterval(t); }, [ms]); };
