import React, { useState, useMemo } from 'react';
import * as E from './engine.js';
import * as X from './text.js';
import { G, md, Expand, Wheel, PlaceSearch, Bars } from './widgets.jsx';

const { SIGNS, signOf, fmtLon, fmtTime, fmtDate, fmtDateTime, jdFromMs, msFromJd } = E;
const thisYear = new Date().getFullYear();
export const fmtWhen = (ms, tz) => E.fmtLocal(ms, tz, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', ...(new Date(ms).getFullYear() !== thisYear ? { year: 'numeric' } : {}) });
const fmtJd = tz => j => fmtWhen(msFromJd(j), tz);
function TransitRow({ t, f }) {
  return <Expand head={<span className="trow"><span className="tglyphs"><G p={t.transit} /> {X.ASPECT[t.aspect] && <span className="aglyph">{t.glyph}</span>} <G p={t.natal} /></span><span>{X.transitHeadline(t)}<small>{t.next[0] ? `exact ${f(t.next[0])}` : t.applying ? 'building' : 'easing'}</small></span></span>}>
    <p>{X.transitText(t, f)}</p><p className="ask">{X.transitAsk(t)}</p>
  </Expand>;
}

// ------------------------------------------------------------------ CHART
export function ChartView({ person, data, place, settings }) {
  const { natal, sky, aspects, prof } = data;
  const [outer, setOuter] = useState(false);
  const pts = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'Chiron', 'North Node', 'Lilith'];
  const lines = outer ? data.transits.filter(t => t.transit !== 'Moon' && t.aspect !== 'quincunx').map(t => ({ a: sky.points[t.transit].lon, b: natal.points[t.natal].lon, aspect: t.aspect, orb: t.orb }))
    : aspects.filter(a => a.aspect !== 'quincunx' && a.orb < 5).map(a => ({ a: natal.points[a.a].lon, b: natal.points[a.b].lon, aspect: a.aspect, orb: a.orb }));
  const born = E.fmtLocal(natal.birthMs, person.tz, { month: 'long', day: 'numeric', year: 'numeric', ...(natal.timeKnown ? { hour: 'numeric', minute: '2-digit' } : {}) }) + (natal.timeKnown ? '' : ', time unknown');
  return (
    <>
      <section className="block first">
        <h1 className="page">{person.me ? 'Your birth chart' : `${person.name}'s birth chart`}</h1>
        <p className="muted small">{born}, {person.place}</p>
        <Wheel natal={natal} outer={outer ? sky : null} lines={lines} />
        <div className="seg" role="group" aria-label="Wheel view">
          <button className={!outer ? 'on' : ''} onClick={() => setOuter(false)}>Birth chart</button>
          <button className={outer ? 'on' : ''} onClick={() => setOuter(true)}>With today's sky</button>
        </div>
        <p className="gloss">{outer ? 'Inner ring: the planets at birth. Outer ring: where they are today. Lines connect today\'s planets to the birth planets they are aspecting.' : 'A map of the sky at the moment of birth, seen from the birthplace. The left edge is the eastern horizon (AC); the top is the Midheaven (MC). Lines are the main aspects: gold fusion, green flow, red friction.'}</p>
        {natal.notes.map((n, i) => <p key={i} className="note">{n}</p>)}
      </section>
      <section className="block">
        <h2>The big three</h2>
        {X.bigThree(natal).map(b => <div key={b.key} className="big3"><h3>{b.title}</h3><p>{b.text}</p></div>)}
        {natal.timeKnown && <p>This is a <strong>{natal.sect} chart</strong> (born with the Sun {natal.sect === 'day' ? 'above' : 'below'} the horizon). In the old tradition that makes {natal.sect === 'day' ? 'Jupiter your most helpful planet and Mars your hardest' : 'Venus your most helpful planet and Saturn your hardest'}.</p>}
        {prof && <p>This year (age {prof.age}) your chart's {X.ordinal(prof.house)} house, {SIGNS[prof.sign]}, takes the lead, so <G p={prof.lord} /> <strong>{prof.lord}</strong> is the lord of your year. This is the annual profection: each birthday a new house of the chart comes to the front, and its ruling planet guides the year. Watch what {prof.lord} does in the sky; it speaks loudest for you until your next birthday.</p>}
      </section>
      <section className="block">
        <h2>Planets</h2>
        {pts.map(n => { const p = natal.points[n]; return <Expand key={n} head={<span className="prow"><G p={n} /><span>{n}</span><span className="pos">{fmtLon(p.lon)}{p.retro ? ' r' : ''}</span>{natal.timeKnown && <span className="hs">{X.ordinal(p.house)}</span>}</span>}>
          <p>{md(X.placement(n, p, natal))}</p><p className="muted small">Exact position {fmtLon(p.lon, true)}</p></Expand>; })}
        {natal.timeKnown && ['Asc', 'MC'].map(n => <Expand key={n} head={<span className="prow"><G p={n} /><span>{n === 'Asc' ? 'Ascendant' : 'Midheaven'}</span><span className="pos">{fmtLon(natal.points[n].lon)}</span><span className="hs" /></span>}><p>{X.PLANET[n].gloss} Yours is in {SIGNS[signOf(natal.points[n].lon)]}: {X.SIGN[signOf(natal.points[n].lon)].gloss}</p></Expand>)}
      </section>
      <section className="block">
        <h2>Aspects</h2>
        <p className="gloss">Aspects are the angles between planets, the conversations in the chart. The closer to exact (smaller orb), the louder.</p>
        {aspects.slice(0, 16).map((a, i) => <Expand key={i} head={<span className="trow"><span className="tglyphs"><G p={a.a} /> <span className="aglyph">{a.glyph}</span> <G p={a.b} /></span><span>{a.a} {a.aspect} {a.b}<small>{a.orb.toFixed(1)}° orb</small></span></span>}><p>{X.aspectText(a)}</p></Expand>)}
      </section>
      <section className="block">
        <h2>Balance</h2>
        <p className="gloss">Counted from the planets and angles (Sun, Moon and Ascendant count double). What is plentiful comes easily; what is scarce is what you reach for in other people.</p>
        <Bars data={natal.elements} order={['Fire', 'Earth', 'Air', 'Water']} />
        <Bars data={natal.modalities} order={['Cardinal', 'Fixed', 'Mutable']} />
      </section>
    </>
  );
}

// ------------------------------------------------------------------ TOGETHER
export function Together({ person, people, data, place, settings, setTab }) {
  const others = people.filter(p => p.id !== person.id);
  const [bid, setBid] = useState(others[0]?.id);
  const B = people.find(p => p.id === bid);
  const r = useMemo(() => {
    if (!B) return null;
    const a = data.natal, b = E.natalFor(B, settings.hsys);
    const syn = E.synastry(a, b), comp = E.composite(a, b), dav = E.davison(a, b);
    const tone = { flowing: 0, dynamic: 0, fusing: 0, adjusting: 0 }; syn.forEach(s => tone[s.tone] += s.weight);
    const weather = E.transitsTo({ ...comp, timeKnown: comp.timeKnown }, data.sky, data.jd, { bodies: ['Sun', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'] }).slice(0, 6);
    return { a, b, syn, comp, dav, tone, weather, ovAB: E.overlays(a, b), ovBA: E.overlays(b, a) };
  }, [person.id, bid, settings.hsys, data]);
  if (!others.length) return <section className="block first"><h1 className="page">Together</h1><p>Add someone in People to compare charts: a partner, a friend, family. If you don't know their birth time, that's fine; the chart is cast for sunrise.</p><p className="muted">Use “Add a person” below.</p></section>;
  const tot = Object.values(r.tone).reduce((s, v) => s + v, 0) || 1;
  const A = person.me ? 'You' : person.name, Bn = B.name;
  const f = fmtJd(Intl.DateTimeFormat().resolvedOptions().timeZone);
  return (
    <>
      <section className="block first">
        <h1 className="page">{A} and {Bn}</h1>
        <label className="field"><span>Compare with</span><select value={bid} onChange={e => setBid(e.target.value)}>{others.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
        {[[person.name, r.a], [Bn, r.b]].filter(([, c]) => !c.timeKnown).map(([nm]) => <p key={nm} className="note">{nm}'s birth time is unknown, so their chart is cast for sunrise: planet-to-planet contacts are reliable, house overlays and the composite's houses are left out.</p>)}
        <Wheel natal={r.a} outer={r.b} lines={r.syn.filter(s => s.aspect !== 'quincunx' && !['Asc', 'MC'].includes(s.a)).slice(0, 14).map(s => ({ a: r.a.points[s.a].lon, b: r.b.points[s.b].lon, aspect: s.aspect, orb: s.orb }))} />
        <p className="gloss">Inner ring: {A === 'You' ? 'your' : `${A}'s`} chart. Outer ring: {Bn}'s planets laid over it. This is synastry: how two charts touch.</p>
      </section>
      <section className="block">
        <h2>The texture</h2>
        <div className="tone">{Object.entries(r.tone).map(([k, v]) => <div key={k}><span>{k[0].toUpperCase() + k.slice(1)}</span><i style={{ width: `${(100 * v) / tot}%` }} className={`t-${k}`} /></div>)}</div>
        <p className="gloss">{Object.entries(X.TONE_TEXT).map(([k, v]) => `${k[0].toUpperCase() + k.slice(1)} contacts are ${v}`).join('. ')}. Easy contacts make a bond comfortable; hard ones make it alive. Neither is a verdict.</p>
      </section>
      <section className="block">
        <h2>The strongest contacts</h2>
        {r.syn.slice(0, 12).map((s, i) => <Expand key={i} head={<span className="trow"><span className="tglyphs"><G p={s.a} /> <span className="aglyph">{s.glyph}</span> <G p={s.b} /></span><span>{A === 'You' ? 'Your' : `${A}'s`} {s.a} {s.aspect} {Bn}'s {s.b}<small>{X.keyNote(s.a, s.b) || `${s.orb.toFixed(1)}° orb`}</small></span></span>}>
          <p>{A === 'You' ? 'Your' : `${A}'s`} {s.a}, {X.PLANET[s.a].role}, is {X.ASPECT[s.aspect].rel} {Bn}'s {s.b}, {X.PLANET[s.b].role} ({s.orb.toFixed(1)}° from exact). {X.ASPECT[s.aspect].gloss}{X.keyNote(s.a, s.b) ? ` Astrologers read this pairing as ${X.keyNote(s.a, s.b)}.` : ''}</p>
        </Expand>)}
      </section>
      {(r.ovAB.length > 0 || r.ovBA.length > 0) && <section className="block">
        <h2>Where you land in each other's lives</h2>
        <p className="gloss">House overlays: which area of one person's life (house) the other person's planets fall into.</p>
        {r.ovAB.length > 0 && <p>{Bn}'s Sun falls in {A === 'You' ? 'your' : `${A}'s`} {X.ordinal(r.ovAB[0].house)} house ({X.HOUSE[r.ovAB[0].house - 1][0]}), Moon in the {X.ordinal(r.ovAB[1].house)} ({X.HOUSE[r.ovAB[1].house - 1][0]}), Venus in the {X.ordinal(r.ovAB[3].house)} ({X.HOUSE[r.ovAB[3].house - 1][0]}).</p>}
        {r.ovBA.length > 0 && <p>{A === 'You' ? 'Your' : `${A}'s`} Sun falls in {Bn}'s {X.ordinal(r.ovBA[0].house)} house ({X.HOUSE[r.ovBA[0].house - 1][0]}), Moon in the {X.ordinal(r.ovBA[1].house)} ({X.HOUSE[r.ovBA[1].house - 1][0]}), Venus in the {X.ordinal(r.ovBA[3].house)} ({X.HOUSE[r.ovBA[3].house - 1][0]}).</p>}
      </section>}
      <section className="block">
        <h2>The relationship itself</h2>
        <p className="gloss">The composite chart takes the halfway point between each pair of planets and reads the bond as its own being.</p>
        {['Sun', 'Moon', 'Venus', 'Mars', 'Saturn'].map(n => { const p = r.comp.points[n]; return <p key={n}><G p={n} /> <strong>{n} in {SIGNS[p.sign]}</strong>{p.house ? `, ${X.ordinal(p.house)} house` : ''}: the bond's {X.PLANET[n].short} is {X.SIGN[p.sign].style}{n === 'Sun' && p.house ? `; at heart this is ${X.COMPOSITE_HOUSE[p.house - 1]}` : ''}.</p>; })}
        <p className="muted small">Davison chart (a real moment halfway between the two births, {fmtDate(msFromJd(r.dav.jd), 'UTC')}): Sun {fmtLon(r.dav.points.Sun.lon)}, Moon {fmtLon(r.dav.points.Moon.lon)}.</p>
      </section>
      <section className="block">
        <h2>Your weather together</h2>
        <p className="gloss">Today's planets aspecting the composite chart: the season the relationship is in.</p>
        {r.weather.length ? r.weather.map((t, i) => <TransitRow key={i} t={t} f={f} />) : <p>No major transits to the composite right now: a quiet stretch.</p>}
      </section>
    </>
  );
}

export function PersonForm({ init, onSave, onCancel, first }) {
  const [p, setP] = useState(init || { name: '', relation: '', date: '', time: '', place: '' });
  const [unknown, setUnknown] = useState(init ? !init.time : false);
  const ok = p.name && p.date && (unknown || p.time) && p.lat != null;
  return (
    <div className="form">
      <label className="field"><span>Name</span><input value={p.name} onChange={e => setP({ ...p, name: e.target.value })} /></label>
      {!first && <label className="field"><span>Who they are to you</span><input value={p.relation || ''} onChange={e => setP({ ...p, relation: e.target.value })} placeholder="partner, friend, mom…" /></label>}
      <label className="field"><span>Birth date</span><input type="date" value={p.date} onChange={e => setP({ ...p, date: e.target.value })} /></label>
      <label className="field"><span>Birth time (local clock time)</span><input type="time" value={p.time} disabled={unknown} onChange={e => setP({ ...p, time: e.target.value })} /></label>
      <label className="check"><input type="checkbox" checked={unknown} onChange={e => { setUnknown(e.target.checked); if (e.target.checked) setP({ ...p, time: '' }); }} /> I don't know the birth time (the chart will be cast for sunrise)</label>
      <PlaceSearch value={p.lat != null ? { label: p.place, lat: p.lat, lon: p.lon, tz: p.tz } : null} onPick={r => setP({ ...p, place: r.label, lat: r.lat, lon: r.lon, tz: r.tz })} />
      <div className="row gap"><button className="btn primary" disabled={!ok} onClick={() => onSave({ ...p, time: unknown ? '' : p.time })}>Save</button>{onCancel && <button className="btn" onClick={onCancel}>Cancel</button>}</div>
    </div>
  );
}
export function Welcome({ onSave }) {
  return <section className="block first welcome">
    <h1 className="page">A pocket almanac for your chart, today's sky and the cards.</h1>
    <p>Start with your birth details. Everything is calculated on this phone from the same JPL-derived ephemeris professional astrologers use, and nothing leaves the device.</p>
    <PersonForm first onSave={onSave} />
  </section>;
}
