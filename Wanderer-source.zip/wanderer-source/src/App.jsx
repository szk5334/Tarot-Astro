import React, { useState, useMemo, useEffect } from 'react';
import * as E from './engine.js';
import * as T from './tarot.js';
import * as K from './content.js';
import { G, PlaceSearch, useInterval } from './widgets.jsx';
import { SkyClock } from './clock.jsx';
import { CardPanel, CrossLayout, pairPrompts, watchFor, WRITTEN_IDS, DayHour } from './cards.jsx';
import { ChartView, Together, PersonForm, Welcome } from './reference.jsx';
import { PlanetPanel } from './planets.jsx';

const { jdFromMs, fmtTime } = E;
const load = (k, d) => { try { const v = localStorage.getItem('wanderer:' + k); return v ? JSON.parse(v) : d; } catch { return d; } };
const useStored = (k, d) => { const [v, s] = useState(() => load(k, d)); useEffect(() => { try { localStorage.setItem('wanderer:' + k, JSON.stringify(v)); } catch {} }, [k, v]); return [v, s]; };
const uid = () => Math.random().toString(36).slice(2, 10);
const TABS = [['clock', 'Clock', '◎'], ['cards', 'Cards', '▯'], ['people', 'People', '☊']];
const VS = '︎';

export default function App() {
  const [people, setPeople] = useStored('people', []);
  const [activeId, setActiveId] = useStored('active', null);
  const [here, setHere] = useStored('here', null);
  const [settings, setSettings] = useStored('settings', { hsys: 'P', reversals: true, fullDeck: false });
  const [tab, setTab] = useState('clock');
  const [showSettings, setShowSettings] = useState(false);
  const [now, setNow] = useState(Date.now());
  useInterval(() => setNow(Date.now()), 20000);

  const person = people.find(p => p.id === activeId) || people.find(p => p.me) || people[0];
  const place = here || (person && { label: person.place, lat: person.lat, lon: person.lon, tz: person.tz });
  const bucket = Math.floor(now / 600000);
  const data = useMemo(() => person && compute(person, place, settings.hsys, now), [person?.id, person?.date, person?.time, person?.lat, place?.lat, place?.lon, settings.hsys, bucket]);
  const minute = Math.floor(now / 60000);
  const sky = useMemo(() => place && E.computeChart(jdFromMs(now), place.lat, place.lon, 'P'), [place?.lat, place?.lon, minute]);
  const pday = useMemo(() => place && E.planetaryDay(jdFromMs(now), place.lat, place.lon, place.tz), [place?.lat, place?.lon, minute]);

  if (!people.length) return <div className="app"><Header /><main><Welcome onSave={p => { const me = { ...p, id: uid(), me: true }; setPeople([me]); setActiveId(me.id); }} /></main></div>;

  const dayRuler = pday?.dayRuler || E.DAY_RULER[E.localFields(now, place.tz).wd];
  const hourRuler = pday?.hour?.ruler;
  const dayKey = E.localDateKey(pday ? pday.sunrise : now, place.tz);
  const pool = settings.fullDeck ? null : WRITTEN_IDS;
  const ctx = { natal: data.natal, sky: data.sky, transits: data.transits, dayRuler, hourRuler, person, dayKey };
  return (
    <div className={`app tab-${tab}`}>
      <Header right={<>
        <label className="who"><span className="sr">Reading for</span>
          <select value={person.id} onChange={e => setActiveId(e.target.value)} aria-label="Whose reading">
            {people.map(p => <option key={p.id} value={p.id}>{p.name}{p.me ? ' (me)' : ''}</option>)}
          </select></label>
        <button className="icon-btn" aria-label="Settings" onClick={() => setShowSettings(true)}>⚙{VS}</button>
      </>} />
      <main key={tab}>
        {tab === 'clock' && <ClockPage {...{ person, place, sky, pday, now, ctx, settings, pool }} />}
        {tab === 'cards' && <CardsPage {...{ ctx, settings, pool }} />}
        {tab === 'people' && <PeoplePage {...{ people, setPeople, person, setActiveId, data, place, settings }} />}
      </main>
      <nav className="tabs" aria-label="Sections">{TABS.map(([k, l, g]) => <button key={k} className={tab === k ? 'on' : ''} aria-current={tab === k ? 'page' : undefined} onClick={() => { setTab(k); window.scrollTo(0, 0); }}><span className="tg" aria-hidden="true">{g + VS}</span>{l}</button>)}</nav>
      {showSettings && <Settings {...{ settings, setSettings, here, setHere, people, setPeople }} onClose={() => setShowSettings(false)} />}
    </div>
  );
}

function compute(person, place, hsys, now) {
  const natal = E.natalFor(person, hsys);
  const jd = jdFromMs(now);
  const sky = E.computeChart(jd, place.lat, place.lon, hsys);
  for (const [n, p] of Object.entries(sky.points)) if (natal.timeKnown && !['Asc', 'MC', 'Vertex', 'Fortune'].includes(n)) p.natalHouse = E.houseOf(p.lon, natal.cusps);
  return {
    natal, sky, jd, transits: E.transitsTo(natal, sky, jd), aspects: E.natalAspects(natal),
    prof: natal.timeKnown ? E.profection(natal.birthMs, now, natal, person.tz) : null,
  };
}

function Header({ right }) {
  return <header className="top"><div className="mark"><span className="mark-glyph" aria-hidden="true">☿{VS}</span>Wanderer</div><div className="top-right">{right}</div></header>;
}

// The day's card: same person, same planetary day (sunrise to sunrise), same town, same card.
function dailyCard(person, place, dayKey, settings, pool) {
  const seed = T.hashSeed(`${person.name.trim().toLowerCase()}|${dayKey}|${place.lat.toFixed(1)}|${place.lon.toFixed(1)}`);
  return T.draw(1, seed, settings.reversals, pool)[0];
}

// ------------------------------------------------------------------ CLOCK (one screen, no scrolling)
function ClockPage({ person, place, sky, pday, now, ctx, settings, pool }) {
  const [open, setOpen] = useState(null); // 'card' | 'day' | 'hour'
  const c = dailyCard(person, place, ctx.dayKey, settings, pool);
  const card = T.CARDS[c.id];
  const { dayRuler, hourRuler } = ctx;
  const when = E.fmtLocal(now, place.tz, { weekday: 'long', month: 'long', day: 'numeric' });
  const title = open === 'card' ? `${person.me ? 'Your' : `${person.name}'s`} card for ${when}` : open === 'day' ? `${dayRuler}'s day · ${when}` : `${hourRuler}'s hour`;
  return (
    <div className="clock-page">
      <SkyClock sky={sky} pday={pday} now={now} tz={place.tz} />
      <div className="clock-lines">
        <p>
          <button className="tap" onClick={() => setOpen('day')} aria-label={`${dayRuler}'s day: what it asks. Open it.`}><G p={dayRuler} /> <strong>{dayRuler}'s day</strong></button>
          {pday?.hour && <> · <button className="tap" onClick={() => setOpen('hour')} aria-label={`${hourRuler}'s hour: what it asks. Open it.`}>hour of <G p={hourRuler} /> {hourRuler}</button> until {fmtTime(pday.hour.end, place.tz)}</>}
        </p>
        <p className="muted">{K.DAY_LINE[dayRuler].replace('Turn it', 'Today turns things')}</p>
      </div>
      <button className="daycard" onClick={() => setOpen('card')} aria-label={`Today's card: ${card.name}. Open it.`}>
        <img src={window.__CARD(c.id)} alt="" className={c.reversed ? 'rev' : ''} />
        <span>
          <small>{person.me ? 'Your' : `${person.name}'s`} card today</small>
          <strong>{card.name}{c.reversed ? ', reversed' : ''}</strong>
          <em>{watchFor(c.id, c.reversed, dayRuler)}</em>
        </span>
      </button>
      {open && <div className="sheet" role="dialog" aria-modal="true" aria-label={title}>
        <div className="sheet-body">
          <div className="row between"><p className="muted small">{title}</p><button className="btn" onClick={() => setOpen(null)}>Done</button></div>
          {open === 'card' && <CardPanel c={c} slot={{ pos: 1, label: 'Today' }} spreadMode={load('mode:' + ctx.dayKey, null)} ctx={ctx} daily />}
          {open === 'day' && <PlanetPanel kind="day" planet={dayRuler} ctx={ctx} pday={pday} tz={place.tz} />}
          {open === 'hour' && hourRuler && <PlanetPanel kind="hour" planet={hourRuler} ctx={ctx} pday={pday} tz={place.tz} />}
        </div>
      </div>}
    </div>
  );
}

// ------------------------------------------------------------------ CARDS
function CardsPage({ ctx, settings, pool }) {
  const [kind, setKind] = useState('three');
  const [q, setQ] = useState('');
  const [spread, setSpread] = useStored('spread', null);
  const [mode, setModeRaw] = useState(() => load('mode:' + ctx.dayKey, null));
  const setMode = m => { setModeRaw(m); try { localStorage.setItem('wanderer:mode:' + ctx.dayKey, JSON.stringify(m)); } catch {} };
  const S = K.SPREADS[kind];
  const doDraw = () => setSpread({ kind, q, cards: T.draw(S.slots.length, undefined, settings.reversals, pool), at: Date.now() });
  const sp = spread && K.SPREADS[spread.kind];
  return (
    <>
      <section className="block first">
        <h1 className="page">Cards</h1>
        <div className="seg" role="group" aria-label="Spread">{Object.entries(K.SPREADS).map(([k, s]) => <button key={k} className={kind === k ? 'on' : ''} onClick={() => setKind(k)}>{s.label}</button>)}</div>
        <label className="field"><span>What's on your mind? (optional)</span><input value={q} onChange={e => setQ(e.target.value)} placeholder="Leave it blank to read for the day" /></label>
        <button className="btn primary" onClick={doDraw}>{spread ? 'Shuffle and draw again' : 'Shuffle and draw'}</button>
        {!settings.fullDeck && pool.length < T.CARDS.length && <p className="hint">Drawing from the {pool.length} cards whose questions are written so far{pool.length < S.slots.length ? ', topped up with others from the deck' : ''}. Settings can switch to the whole deck.</p>}
      </section>
      {spread && <>
        <section className="block">
          {spread.q && <p className="headline">{spread.q}</p>}
          <p className="muted small">Today, would you rather…</p>
          <div className="mode big" role="group" aria-label="Write or read, for the whole spread">
            <button className={mode === 'write' ? 'on' : ''} aria-pressed={mode === 'write'} onClick={() => setMode(mode === 'write' ? null : 'write')}><b>Write</b><span>a question for the page</span></button>
            <button className={mode === 'read' ? 'on' : ''} aria-pressed={mode === 'read'} onClick={() => setMode(mode === 'read' ? null : 'read')}><b>Read</b><span>the meaning, nothing asked</span></button>
          </div>
          {mode === 'write' && spread.cards.length > 1 && <DayHour ctx={ctx} />}
          {spread.kind === 'celtic' && <CrossLayout cards={spread.cards} />}
        </section>
        <section className="block">
          {spread.cards.map((c, i) => <CardPanel key={spread.at + ':' + i} c={c} slot={sp.slots[i]} spreadMode={mode} ctx={ctx} dayHour={spread.cards.length === 1 || mode !== 'write'} />)}
        </section>
        {spread.kind === 'celtic' && mode === 'write' && <section className="block">
          <h2>How the cards talk to each other</h2>
          {pairPrompts(spread.cards).map(p => <div key={p.title} className="pair"><h3>{p.title}</h3><p className="question small-q">{p.text}</p></div>)}
        </section>}
        {spread.kind === 'celtic' && mode !== 'write' && <section className="block">
          <h2>The shape of the spread</h2>
          {K.PAIR_SHAPE.map((t, i) => <p key={i} className="small">{t}</p>)}
        </section>}
      </>}
    </>
  );
}

// ------------------------------------------------------------------ PEOPLE (charts one tap deep)
function PeoplePage({ people, setPeople, person, setActiveId, data, place, settings }) {
  const [edit, setEdit] = useState(null);
  const [sub, setSub] = useState(null);
  const save = p => { if (edit === 'new') setPeople([...people, { ...p, id: uid() }]); else setPeople(people.map(x => x.id === edit ? { ...x, ...p } : x)); setEdit(null); };
  if (sub) return <>
    <div className="subbar"><button className="link" onClick={() => setSub(null)}>← People</button></div>
    {sub === 'chart' && <ChartView person={person} data={data} place={place} settings={settings} />}
    {sub === 'compare' && <Together person={person} people={people} data={data} place={place} settings={settings} />}
  </>;
  return (
    <section className="block first">
      <h1 className="page">People</h1>
      <p className="gloss">Everyone here gets the same clock, the same card of the day and the same spreads. Pick whose reading it is from the name at the top. Birth charts and comparisons are here for reference.</p>
      <ul className="people">{people.map(p => <li key={p.id} className={p.id === person.id ? 'on' : ''}>
        {edit === p.id ? <PersonForm init={p} onSave={save} onCancel={() => setEdit(null)} /> : <>
          <button className="pname" onClick={() => setActiveId(p.id)}><strong>{p.name}</strong>{p.me ? ' (me)' : p.relation ? `, ${p.relation}` : ''}<span className="muted small">{p.date}, {p.time || 'time unknown'}, {p.place}</span></button>
          <div className="row gap">
            <button className="link" onClick={() => { setActiveId(p.id); setSub('chart'); }}>Birth chart</button>
            {people.length > 1 && <button className="link" onClick={() => { setActiveId(p.id); setSub('compare'); }}>Compare</button>}
            <button className="link" onClick={() => setEdit(p.id)}>Edit</button>
            {!p.me && <button className="link" onClick={() => setPeople(people.map(x => ({ ...x, me: x.id === p.id })))}>This is me</button>}
            {!p.me && <button className="link danger" onClick={() => { if (confirm(`Remove ${p.name}?`)) setPeople(people.filter(x => x.id !== p.id)); }}>Remove</button>}
          </div>
        </>}
      </li>)}</ul>
      {edit === 'new' ? <PersonForm onSave={save} onCancel={() => setEdit(null)} /> : <button className="btn primary" onClick={() => setEdit('new')}>Add a person</button>}
    </section>
  );
}

// ------------------------------------------------------------------ SETTINGS
function Settings({ settings, setSettings, here, setHere, people, setPeople, onClose }) {
  const [checks, setChecks] = useState(null);
  const [geoMsg, setGeoMsg] = useState('');
  const set = (k, v) => setSettings({ ...settings, [k]: v });
  const useDevice = () => {
    setGeoMsg('Asking for your location…');
    navigator.geolocation.getCurrentPosition(pos => { setHere({ label: 'Current location', lat: pos.coords.latitude, lon: pos.coords.longitude, tz: Intl.DateTimeFormat().resolvedOptions().timeZone }); setGeoMsg(''); },
      () => setGeoMsg('Location was not shared. Search for your town instead.'), { enableHighAccuracy: false, timeout: 15000 });
  };
  const exportData = () => { const blob = new Blob([JSON.stringify({ people }, null, 1)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'wanderer-people.json'; a.click(); };
  const importData = e => { const f = e.target.files[0]; if (!f) return; f.text().then(t => { try { const j = JSON.parse(t); if (Array.isArray(j.people)) setPeople(j.people); } catch { alert('That file is not a Wanderer backup.'); } }); };
  return (
    <div className="sheet" role="dialog" aria-modal="true" aria-label="Settings">
      <div className="sheet-body">
        <div className="row between"><h1 className="page">Settings</h1><button className="btn" onClick={onClose}>Done</button></div>
        <h2>Where you are now</h2>
        <p className="gloss">Sets the clock, sunrise, the planetary hours and the day's card. {here ? `Now: ${here.label}.` : 'Not set, so each person\'s birthplace is used.'}</p>
        <div className="row gap"><button className="btn" onClick={useDevice}>Use my location</button>{here && <button className="link" onClick={() => setHere(null)}>Clear</button>}</div>
        {geoMsg && <p className="hint">{geoMsg}</p>}
        <PlaceSearch label="Or search for a town" value={here && here.label !== 'Current location' ? here : null} onPick={r => setHere(r)} />
        <h2>Cards</h2>
        <label className="check"><input type="checkbox" checked={settings.reversals} onChange={e => set('reversals', e.target.checked)} /> Draw reversed cards</label>
        {WRITTEN_IDS.length < T.CARDS.length && <label className="check"><input type="checkbox" checked={!!settings.fullDeck} onChange={e => set('fullDeck', e.target.checked)} /> Draw from the whole deck (some cards' own questions are still being written)</label>}
        <h2>Birth charts</h2>
        <div className="seg" role="group" aria-label="House system">{[['P', 'Placidus houses'], ['W', 'Whole Sign houses']].map(([k, l]) => <button key={k} className={settings.hsys === k ? 'on' : ''} onClick={() => set('hsys', k)}>{l}</button>)}</div>
        <h2>Your data</h2>
        <p className="gloss">Everything stays on this phone. Nothing is sent anywhere, and there is no AI in this app.</p>
        <div className="row gap"><button className="btn" onClick={exportData}>Export people</button><label className="btn">Import<input type="file" accept="application/json" onChange={importData} hidden /></label></div>
        <h2>Accuracy</h2>
        <p className="gloss">Planet positions come from the Swiss Ephemeris reading NASA JPL's DE431 data. Sunrise and sunset follow the U.S. Naval Observatory definition. The check compares this phone's math with published USNO times.</p>
        <button className="btn" onClick={() => setChecks(E.runChecks())}>Check against USNO</button>
        {checks && <p className="small">{checks.every(c => c.ok) ? 'Every event matches the published USNO minute.' : 'Some events are off by a minute or more.'}</p>}
        {checks && <table className="checks"><tbody>{checks.map(c => <tr key={c.label}><td>{c.label}</td><td>{c.ref.slice(11, 16)} UT</td><td>{new Date(c.ms).toISOString().slice(11, 19)}</td><td className={c.ok ? 'ok' : 'off'}>{c.ok ? '✓' : 'off'}</td></tr>)}</tbody></table>}
        <h2>About</h2>
        <p className="small">Wanderer is free software under the GNU AGPL v3. It uses the Swiss Ephemeris by Astrodienst AG (AGPL), card meanings written for the AWOL Almanac, and the 1909 Rider–Waite–Smith deck (public domain). Town search: GeoNames offline, Open-Meteo online.</p>
      </div>
    </div>
  );
}
