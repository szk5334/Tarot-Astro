// Dumps the shared tables and each card's sky signature from the app code, for tools/build_db.py.
import * as T from '../src/tarot.js';
import * as K from '../src/content.js';
import * as X from '../src/text.js';
import * as E from '../src/engine.js';
const cards = T.CARDS.map(c => ({ id: c.id, sig: T.signature(c.id) }));
const ladder = K.LADDER.map(L => ({ name: L.name, text: L.text({ notice: '{notice}', become: '{become}', essence: { figure: '{figure}' } }) }));
const out = {
  cards, ladder, floor: K.FLOOR, positions: K.POSITIONS, spreads: K.SPREADS, pairs: K.PAIRS, pairShape: K.PAIR_SHAPE,
  dayLine: K.DAY_LINE, hourLine: K.HOUR_LINE, litKinds: K.LIT_KINDS, genericLit: K.GENERIC_LIT, planetLine: K.PLANET_LINE,
  planetCard: K.PLANET_CARD, planetFloor: K.PLANET_FLOOR, planetText: K.PLANET_TEXT,
  sign: X.SIGN, planetGloss: X.PLANET, retro: X.RETRO_NOTE, wday: X.WANDERER_DAY,
  signs: E.SIGNS, signGlyph: E.SIGN_GLYPH, tradRuler: E.TRAD_RULER, chaldean: E.CHALDEAN, dayRuler: E.DAY_RULER, glyph: E.GLYPH,
};
process.stdout.write(JSON.stringify(out));
