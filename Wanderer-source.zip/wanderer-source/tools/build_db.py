#!/usr/bin/env python3
"""Run from the source folder:
  npx esbuild tools/dump.mjs --bundle --platform=node --format=esm --loader:.json=json --outfile=tools/dump.bundle.mjs
  node tools/dump.bundle.mjs > tools/app-data.json && python3 tools/build_db.py
Writes dist-export/wanderer-cards.db and dist-export/wanderer-cards.json.

Export all of Wanderer's hand-written card and planet writing, with its tarot and astrology
links, to one SQLite database and one JSON file."""
import json, os, re, sqlite3, glob, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(HERE)  # tools/ sits inside the source folder
OUT = os.path.join(SRC, 'dist-export'); os.makedirs(OUT, exist_ok=True)
VERSION = json.load(open(f'{SRC}/package.json'))['version']

app = json.load(open(f'{HERE}/app-data.json'))
Q = json.load(open(f'{SRC}/assets/questions.json'))
M = json.load(open(f'{SRC}/assets/meanings.json'))
CARDS = M['cards']
SIGNS, TRAD, CHAL, GLYPH = app['signs'], app['tradRuler'], app['chaldean'], app['glyph']
ELEMENTS = ['Fire', 'Earth', 'Air', 'Water']
MODES = ['Cardinal', 'Fixed', 'Mutable']
POS = app['positions']
ORIENT = {'up': 'upright', 'rev': 'reversed'}
PLANETS7 = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn']
WEEKDAY = {p: app['wday'][p]['day'] for p in PLANETS7}

# ---- per-card sky lines and source batch, from the markdown
sky_line, batch_of = {}, {}
md_files = sorted(glob.glob(f'{SRC}/content/batch-*.md')) + [f'{SRC}/content/card-questions-foundation.md']
for f in md_files:
    t = open(f).read()
    if f.endswith('foundation.md'):
        m = re.search(r'## Worked example: (.+?)\n(.*?)(?=\n## )', t, re.S)
        blocks = [(m.group(1), m.group(2))] if m else []
    else:
        blocks = re.findall(r'^## (.+?)\n(.*?)(?=^## |\Z)', t, re.S | re.M)
    for name, body in blocks:
        name = name.strip(); sm = re.search(r'^sky: (.+)$', body, re.M)
        if sm and name not in sky_line:
            sky_line[name] = sm.group(1).strip(); batch_of[name] = os.path.basename(f)

MON = {m: i + 1 for i, m in enumerate(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])}
def season(line):
    m = re.search(r'season: about (\w{3}) (\d+) – (\w{3}) (\d+)', line or '')
    if not m: return None, None, None
    a, b = f'{MON[m.group(1)]:02d}-{int(m.group(2)):02d}', f'{MON[m.group(3)]:02d}-{int(m.group(4)):02d}'
    return f'about {m.group(1)} {m.group(2)} – {m.group(3)} {m.group(4)}', a, b
def lit_by(line):
    m = re.search(r'lit by: (.+)$', line or '')
    return [x.strip() for x in m.group(1).split(',')] if m else []

# ---- foundation tables
found = open(f'{SRC}/content/card-questions-foundation.md').read()
pos_rows = {int(n): (lens.strip(), asks.strip()) for n, _, lens, asks in re.findall(r'^\| (\d+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|$', found, re.M)}
lit_rows = {k: (w.strip(), m.strip()) for k, w, m in re.findall(r'^\| \*\*(.+?)\*\* \| ([^|]+) \| ([^|]+) \|$', found, re.M)}
LIT_APPLIES = {
    'decan': 'Yours, Touching you, Its season, Today\'s weather, The long season, Turning (Turning not for Sun or Moon decans)',
    'sign': 'Yours, Its season, Today\'s weather, The long season',
    'court': 'Yours, Its season, Today\'s weather, The long season',
    'planet': 'Yours, Touching you, Turning (Turning not for the Sun or Moon)',
    'element': 'Yours, Touching you, Turning (through the modern planet)',
    'quadrant': 'Its season only',
}

def sign_name(deg): return SIGNS[int(deg // 30) % 12]
def fmt_deg(deg, end=False):
    if end and deg % 30 == 0: return f'30° {sign_name(deg - 1)}'
    return f'{int(deg % 30)}° {sign_name(deg)}'

# ---- cards
cards = []
for c in CARDS:
    cid, name = c['id'], c['name']
    sig = next(x['sig'] for x in app['cards'] if x['id'] == cid)
    q = Q[str(cid)]
    kind = sig['kind']
    planet = sign = element = modern = None; signs_spanned = []
    rng = sig.get('range')
    if kind == 'planet':
        planet = sig['value']; element = sig.get('also')
    elif kind == 'element':
        element = sig['value']; modern = sig.get('also'); planet = modern
    elif kind == 'sign':
        sign = sig['value']; element = ELEMENTS[SIGNS.index(sign) % 4]; signs_spanned = [sign]
    elif kind == 'decan':
        planet, sign = sig['planet'], sig['sign']; element = ELEMENTS[SIGNS.index(sign) % 4]; signs_spanned = [sign]
    elif kind == 'court':
        element = sig['value']; signs_spanned = [sign_name(rng[0]), sign_name(rng[0] + 10)]
    elif kind == 'quadrant':
        element = sig['value']; signs_spanned = [SIGNS[int(rng[0] // 30) + i] for i in range(3)]
    if kind == 'court':
        label = f'{fmt_deg(rng[0])} to {fmt_deg(rng[1], True)} ({element})'
    else:
        label = sig['label']
    stext, s0, s1 = season(sky_line.get(name))
    cards.append({
        'id': cid, 'name': name, 'arcana': c['arcana'], 'suit': c.get('suit'), 'rank': c.get('rank'), 'number': c.get('number'),
        'image_file': f'{cid:02d}.jpg', 'keywords': c['keywords'], 'meaning': {'upright': c['upright'], 'reversed': c['reversed']},
        'sky': {
            'kind': kind, 'label': label, 'planet': planet, 'modern_planet': modern, 'sign': sign, 'element': element,
            'signs_spanned': signs_spanned, 'sign_ruler': TRAD[SIGNS.index(sign)] if sign else None,
            'degrees': {'start': rng[0], 'end': rng[1], 'start_label': fmt_deg(rng[0]), 'end_label': fmt_deg(rng[1], True)} if rng else None,
            'season': {'text': stext, 'start_mmdd': s0, 'end_mmdd': s1} if stext else None,
            'lit_by': lit_by(sky_line.get(name)), 'source_line': sky_line.get(name),
        },
        'questions': {ORIENT[o]: [{'position': i + 1, 'position_name': POS[i]['label'], 'text': s} for i, s in enumerate(q[o])] for o in ('up', 'rev')},
        'watch_for': {ORIENT[o]: {p: q['watch'][o][p] for p in PLANETS7} for o in ('up', 'rev')},
        'low_tide': {'notice': q['notice'], 'become': q['become']},
        'essence': q['essence'],
        'lit_lines': q['lit'],
        'source_file': batch_of.get(name),
    })

# ---- planets, signs, decans, quadrants, courts
planets = []
for p in PLANETS7:
    pt = app['planetText'][p]
    planets.append({
        'name': p, 'glyph': GLYPH.get(p), 'weekday': WEEKDAY[p], 'chaldean_order': CHAL.index(p) + 1,
        'major_card_id': app['planetCard'][p], 'major_card': CARDS[app['planetCard'][p]]['name'],
        'signs_ruled': [s for s, r in zip(SIGNS, TRAD) if r == p],
        'role': app['planetGloss'][p]['role'], 'gloss': app['planetGloss'][p]['gloss'],
        'planet_line': app['planetLine'].get(p), 'retrograde_note': app['retro'].get(p),
        'day_line': app['dayLine'][p], 'hour_line': app['hourLine'][p], 'good_for_day': app['wday'][p]['good'], 'candle': app['wday'][p]['candle'],
        'day': pt['day'], 'hour': pt['hour'],
    })
for p in ['Uranus', 'Neptune', 'Pluto']:
    planets.append({'name': p, 'glyph': GLYPH.get(p), 'weekday': None, 'chaldean_order': None,
        'major_card_id': {'Uranus': 0, 'Neptune': 12, 'Pluto': 20}[p], 'major_card': CARDS[{'Uranus': 0, 'Neptune': 12, 'Pluto': 20}[p]]['name'],
        'signs_ruled': [], 'role': app['planetGloss'][p]['role'], 'gloss': app['planetGloss'][p]['gloss'],
        'planet_line': app['planetLine'].get(p), 'retrograde_note': app['retro'].get(p),
        'day_line': None, 'hour_line': None, 'good_for_day': None, 'candle': None, 'day': None, 'hour': None})

sign_major = {cd['sky']['sign']: cd['id'] for cd in cards if cd['sky']['kind'] == 'sign'}
signs = []
for i, s in enumerate(SIGNS):
    decs = []
    for d in range(3):
        deg = i * 30 + d * 10
        card = next(cd for cd in cards if cd['sky']['kind'] == 'decan' and cd['sky']['degrees']['start'] == deg)
        decs.append({'n': d + 1, 'deg_start': deg, 'deg_end': deg + 10, 'planet': card['sky']['planet'], 'card_id': card['id'], 'card': card['name'],
                     'season': card['sky']['season']})
    signs.append({'index': i, 'name': s, 'glyph': app['signGlyph'][i], 'element': ELEMENTS[i % 4], 'modality': MODES[i % 3],
                  'ruler': TRAD[i], 'start_deg': i * 30, 'style': app['sign'][i]['style'], 'gloss': app['sign'][i]['gloss'],
                  'major_card_id': sign_major[s], 'major_card': CARDS[sign_major[s]]['name'], 'decans': decs})

# ---- shared lines
positions = [{'n': p['n'], 'name': p['label'], 'short': p['meaning'], 'what_it_is': pos_rows[p['n']][0], 'asks_about': pos_rows[p['n']][1]} for p in POS]
position_relations = [
    {'relation': 'front and back of mind', 'positions': [5, 9], 'description': 'What you think on purpose, and what you think without meaning to.'},
    {'relation': 'arrival and landing', 'positions': [6, 8], 'description': 'What is arriving, and the world it lands in.'},
    {'relation': 'origin and self', 'positions': [3, 7], 'description': 'What you grew from, and who you are because of it.'},
    {'relation': 'the bridge', 'positions': [4, 2, 6], 'description': 'Cross / boon (2) stands between Passing away (4) and Coming in (6), as block or help.'},
    {'relation': 'the levers', 'positions': [5, 9, 10], 'description': 'Front of mind and Hopes / fears lead to the Outcome; change either and the outcome moves. Every Outcome question ends with a lever.'},
]
pair_prompts = []
for p in app['pairs']:
    if p.get('b'):
        conds = [f'{p["a"]} and {p["b"]} upright', f'{p["a"]} reversed', f'{p["b"]} reversed', 'both reversed']
    else:
        conds = [f'{p["a"]} upright', f'{p["a"]} reversed']
    for i, t in enumerate(p['v']):
        pair_prompts.append({'title': p['title'], 'anchor': p['a'], 'other': p.get('b'), 'variant': i, 'when': conds[i], 'template': t})
spreads = [{'spread': k, 'label': v['label'], 'slots': v['slots']} for k, v in app['spreads'].items()]
lit_kinds = [{'kind': k, 'what_happened': lit_rows.get(k, ('', ''))[0], 'what_it_means': lit_rows.get(k, ('', ''))[1], 'generic_line': app['genericLit'].get(k)} for k in app['litKinds'] + ['Quiet']]
card_ladder = [{'step': i + 1, 'name': L['name'], 'text': L['text']} for i, L in enumerate(app['ladder'])]
floors = {'card': app['floor'], 'day': app['planetFloor']['day'], 'hour': app['planetFloor']['hour']}

meta = {
    'title': 'Wanderer: the card questions database',
    'version': VERSION, 'exported': datetime.date.today().isoformat(),
    'about': ('Everything hand-written for Wanderer, a tarot app for notebook practice informed by astrology. '
              'For each of the 78 cards: 20 questions (upright and reversed across the 10 Celtic Cross positions), '
              '14 watch-for cues (upright and reversed across the 7 day planets), a low-tide pointer (Notice / Become), '
              'lit lines (why the sky makes the card matter today), and an essence (a short phrase per orientation and a figure). '
              'Each card is tied to its piece of the sky in the Golden Dawn system: a planet, a sign, a ten-degree slice (decan) '
              'with its ruling planet, a court span across two signs, or a quarter of the year, with the dates the Sun spends there. '
              'Also included: the positions and how they pair, the pair prompts, the low-tide ladder, the lit kinds, and for each '
              'of the seven classical planets its weekday, tarot card, signs ruled, day and hour lines, and the day and hour questions.'),
    'placeholders': {'{planet}': 'in Today\'s weather and The long season lit lines: the planet(s) actually there, e.g. "Mars", "the Moon and Venus"',
                     '{is}': '"is" or "are" to match {planet}', '{n}': 'in pair prompts: the card in Celtic Cross position n, written as "Name (essence phrase)" or "Name reversed (essence phrase)"',
                     '{notice} / {become} / {figure}': 'in the card ladder: the card\'s own low-tide pointer and essence figure'},
    'system': 'Golden Dawn correspondences; decans ruled in Chaldean order (Saturn, Jupiter, Mars, Sun, Venus, Mercury, Moon) starting with Mars at 0° Aries; traditional sign rulers; tropical zodiac. Seasons are approximate Sun dates.',
    'counts': {'cards': len(cards), 'questions': sum(len(c['questions'][o]) for c in cards for o in c['questions']),
               'watch_for_cues': sum(len(c['watch_for'][o]) for c in cards for o in c['watch_for']),
               'lit_lines': sum(len(c['lit_lines']) for c in cards),
               'planet_day_questions': sum(len(p['day']['q']) for p in planets if p['day']), 'planet_hour_questions': sum(len(p['hour']['q']) for p in planets if p['hour'])},
}

data = {'meta': meta, 'cards': cards, 'positions': positions, 'position_relations': position_relations, 'pair_prompts': pair_prompts,
        'spreads': spreads, 'lit_kinds': lit_kinds, 'lit_kinds_by_card_type': LIT_APPLIES, 'card_ladder': card_ladder, 'floors': floors,
        'planets': planets, 'signs': signs}
json.dump(data, open(f'{OUT}/wanderer-cards.json', 'w'), ensure_ascii=False, indent=1)

# ================= SQLite
dbp = f'{OUT}/wanderer-cards.db'
if os.path.exists(dbp): os.remove(dbp)
db = sqlite3.connect(dbp); x = db.execute
x('PRAGMA foreign_keys = OFF')  # loaded in one pass, then checked below
db.executescript('''
CREATE TABLE about (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE planets (name TEXT PRIMARY KEY, glyph TEXT, weekday TEXT, chaldean_order INTEGER, major_card_id INTEGER, role TEXT, gloss TEXT,
  planet_line TEXT, retrograde_note TEXT, day_line TEXT, hour_line TEXT, good_for_day TEXT, candle TEXT);
CREATE TABLE signs (idx INTEGER PRIMARY KEY, name TEXT UNIQUE, glyph TEXT, element TEXT, modality TEXT, ruler TEXT REFERENCES planets(name),
  start_deg INTEGER, style TEXT, gloss TEXT, major_card_id INTEGER);
CREATE TABLE cards (id INTEGER PRIMARY KEY, name TEXT UNIQUE, arcana TEXT, suit TEXT, rank TEXT, number INTEGER, image_file TEXT,
  keywords TEXT, meaning_upright TEXT, meaning_reversed TEXT,
  sky_kind TEXT, sky_label TEXT, sky_planet TEXT REFERENCES planets(name), modern_planet TEXT, sky_sign TEXT REFERENCES signs(name), sky_element TEXT,
  signs_spanned TEXT, deg_start REAL, deg_end REAL, deg_start_label TEXT, deg_end_label TEXT,
  season_text TEXT, season_start_mmdd TEXT, season_end_mmdd TEXT, lit_by TEXT, source_file TEXT);
CREATE TABLE decans (sign TEXT REFERENCES signs(name), n INTEGER, deg_start INTEGER, deg_end INTEGER, planet TEXT REFERENCES planets(name),
  card_id INTEGER REFERENCES cards(id), season_text TEXT, PRIMARY KEY (sign, n));
CREATE TABLE positions (n INTEGER PRIMARY KEY, name TEXT, short TEXT, what_it_is TEXT, asks_about TEXT);
CREATE TABLE position_relations (relation TEXT, position_n INTEGER REFERENCES positions(n), role_order INTEGER, description TEXT);
CREATE TABLE card_questions (card_id INTEGER REFERENCES cards(id), orientation TEXT, position_n INTEGER REFERENCES positions(n), text TEXT,
  PRIMARY KEY (card_id, orientation, position_n));
CREATE TABLE card_watch_for (card_id INTEGER REFERENCES cards(id), orientation TEXT, day_planet TEXT REFERENCES planets(name), text TEXT,
  PRIMARY KEY (card_id, orientation, day_planet));
CREATE TABLE card_low_tide (card_id INTEGER PRIMARY KEY REFERENCES cards(id), notice TEXT, become TEXT);
CREATE TABLE card_essence (card_id INTEGER PRIMARY KEY REFERENCES cards(id), upright TEXT, reversed TEXT, figure TEXT);
CREATE TABLE lit_kinds (kind TEXT PRIMARY KEY, what_happened TEXT, what_it_means TEXT, generic_line TEXT);
CREATE TABLE card_lit_lines (card_id INTEGER REFERENCES cards(id), kind TEXT REFERENCES lit_kinds(kind), text TEXT, PRIMARY KEY (card_id, kind));
CREATE TABLE lit_kinds_by_card_type (sky_kind TEXT PRIMARY KEY, kinds TEXT);
CREATE TABLE pair_prompts (title TEXT, anchor_position INTEGER, other_position INTEGER, variant INTEGER, applies_when TEXT, template TEXT);
CREATE TABLE spreads (spread TEXT, label TEXT, slot INTEGER, position_n INTEGER REFERENCES positions(n), slot_label TEXT);
CREATE TABLE card_ladder (step INTEGER PRIMARY KEY, name TEXT, text TEXT);
CREATE TABLE floors (kind TEXT, n INTEGER, text TEXT);
CREATE TABLE planet_questions (planet TEXT REFERENCES planets(name), kind TEXT, n INTEGER, text TEXT);
CREATE TABLE planet_ladder (planet TEXT REFERENCES planets(name), kind TEXT, step INTEGER, name TEXT, text TEXT);
CREATE TABLE planet_read (planet TEXT REFERENCES planets(name), kind TEXT, field TEXT, text TEXT);
CREATE TABLE card_links (card_id INTEGER REFERENCES cards(id), link TEXT, target TEXT, note TEXT);
''')
for k, v in meta.items(): x('INSERT INTO about VALUES (?,?)', (k, v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)))
for p in planets:
    x('INSERT INTO planets VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', (p['name'], p['glyph'], p['weekday'], p['chaldean_order'], p['major_card_id'], p['role'], p['gloss'],
      p['planet_line'], p['retrograde_note'], p['day_line'], p['hour_line'], p['good_for_day'], p['candle']))
for s in signs:
    x('INSERT INTO signs VALUES (?,?,?,?,?,?,?,?,?,?)', (s['index'], s['name'], s['glyph'], s['element'], s['modality'], s['ruler'], s['start_deg'], s['style'], s['gloss'], s['major_card_id']))
for c in cards:
    sk = c['sky']; dg = sk['degrees'] or {}; se = sk['season'] or {}
    x('INSERT INTO cards VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (c['id'], c['name'], c['arcana'], c['suit'], c['rank'], c['number'], c['image_file'],
      json.dumps(c['keywords']), c['meaning']['upright'], c['meaning']['reversed'], sk['kind'], sk['label'], sk['planet'], sk['modern_planet'], sk['sign'], sk['element'],
      json.dumps(sk['signs_spanned']), dg.get('start'), dg.get('end'), dg.get('start_label'), dg.get('end_label'), se.get('text'), se.get('start_mmdd'), se.get('end_mmdd'),
      json.dumps(sk['lit_by']), c['source_file']))
    for o in ('upright', 'reversed'):
        for qq in c['questions'][o]: x('INSERT INTO card_questions VALUES (?,?,?,?)', (c['id'], o, qq['position'], qq['text']))
        for p, t in c['watch_for'][o].items(): x('INSERT INTO card_watch_for VALUES (?,?,?,?)', (c['id'], o, p, t))
    x('INSERT INTO card_low_tide VALUES (?,?,?)', (c['id'], c['low_tide']['notice'], c['low_tide']['become']))
    e = c['essence']; x('INSERT INTO card_essence VALUES (?,?,?,?)', (c['id'], e['up'], e['rev'], e['figure']))
    # links: the card's ties to the sky, so they can be queried from either side
    if sk['planet']: x('INSERT INTO card_links VALUES (?,?,?,?)', (c['id'], 'planet', sk['planet'], 'decan ruler' if sk['kind'] == 'decan' else ('modern planet of its element' if sk['kind'] == 'element' else 'the card\'s planet')))
    for s in sk['signs_spanned']: x('INSERT INTO card_links VALUES (?,?,?,?)', (c['id'], 'sign', s, sk['kind']))
    if sk['sign']: x('INSERT INTO card_links VALUES (?,?,?,?)', (c['id'], 'sign ruler', sk['sign_ruler'], f'traditional ruler of {sk["sign"]}'))
    if sk['element']: x('INSERT INTO card_links VALUES (?,?,?,?)', (c['id'], 'element', sk['element'].split(' of ')[-1], sk['element']))
    if c['suit']: x('INSERT INTO card_links VALUES (?,?,?,?)', (c['id'], 'suit', c['suit'], None))
    for p in planets:
        if p['major_card_id'] == c['id'] and p['weekday']: x('INSERT INTO card_links VALUES (?,?,?,?)', (c['id'], 'weekday', p['weekday'], f'{p["name"]}\'s day'))
for lk in lit_kinds: x('INSERT INTO lit_kinds VALUES (?,?,?,?)', (lk['kind'], lk['what_happened'], lk['what_it_means'], lk['generic_line']))
for c in cards:
    for k, t in c['lit_lines'].items(): x('INSERT INTO card_lit_lines VALUES (?,?,?)', (c['id'], k, t))
for k, v in LIT_APPLIES.items(): x('INSERT INTO lit_kinds_by_card_type VALUES (?,?)', (k, v))
for s in signs:
    for d in s['decans']: x('INSERT INTO decans VALUES (?,?,?,?,?,?,?)', (s['name'], d['n'], d['deg_start'], d['deg_end'], d['planet'], d['card_id'], (d['season'] or {}).get('text')))
for p in positions: x('INSERT INTO positions VALUES (?,?,?,?,?)', (p['n'], p['name'], p['short'], p['what_it_is'], p['asks_about']))
for r in position_relations:
    for i, n in enumerate(r['positions']): x('INSERT INTO position_relations VALUES (?,?,?,?)', (r['relation'], n, i + 1, r['description']))
for pp in pair_prompts: x('INSERT INTO pair_prompts VALUES (?,?,?,?,?,?)', (pp['title'], pp['anchor'], pp['other'], pp['variant'], pp['when'], pp['template']))
for sp in spreads:
    for i, sl in enumerate(sp['slots']): x('INSERT INTO spreads VALUES (?,?,?,?,?)', (sp['spread'], sp['label'], i + 1, sl['pos'], sl['label']))
for L in card_ladder: x('INSERT INTO card_ladder VALUES (?,?,?)', (L['step'], L['name'], L['text']))
for k, lines in floors.items():
    for i, t in enumerate(lines): x('INSERT INTO floors VALUES (?,?,?)', (k, i + 1, t))
for p in planets:
    for kind in ('day', 'hour'):
        if not p[kind]: continue
        for i, t in enumerate(p[kind]['q']): x('INSERT INTO planet_questions VALUES (?,?,?,?)', (p['name'], kind, i + 1, t))
        for i, L in enumerate(p[kind]['ladder']): x('INSERT INTO planet_ladder VALUES (?,?,?,?,?)', (p['name'], kind, i + 1, L['name'], L['text']))
        for f, t in p[kind]['read'].items(): x('INSERT INTO planet_read VALUES (?,?,?,?)', (p['name'], kind, f, t))

db.executescript('''
CREATE VIEW v_card_sky AS
  SELECT c.id, c.name, c.sky_kind, c.sky_label, c.sky_planet, c.sky_sign, s.ruler AS sign_ruler, c.sky_element,
         c.deg_start_label, c.deg_end_label, c.season_text, p.weekday AS planet_weekday, c.lit_by
  FROM cards c LEFT JOIN signs s ON s.name = c.sky_sign LEFT JOIN planets p ON p.name = c.sky_planet;
CREATE VIEW v_questions AS
  SELECT c.name AS card, q.orientation, q.position_n, p.name AS position, q.text
  FROM card_questions q JOIN cards c ON c.id = q.card_id JOIN positions p ON p.n = q.position_n
  ORDER BY q.card_id, q.orientation DESC, q.position_n;
CREATE VIEW v_watch_for AS
  SELECT c.name AS card, w.orientation, w.day_planet, pl.weekday, w.text
  FROM card_watch_for w JOIN cards c ON c.id = w.card_id JOIN planets pl ON pl.name = w.day_planet;
CREATE VIEW v_cards_by_planet AS
  SELECT l.target AS planet, l.link, c.name AS card, c.sky_label FROM card_links l JOIN cards c ON c.id = l.card_id
  WHERE l.link IN ('planet', 'sign ruler') ORDER BY l.target, c.id;
CREATE VIEW v_card_full AS
  SELECT c.id, c.name, c.sky_label, c.season_text, e.upright AS essence_upright, e.reversed AS essence_reversed, e.figure,
         t.notice, t.become, c.keywords, c.meaning_upright, c.meaning_reversed
  FROM cards c JOIN card_essence e ON e.card_id = c.id JOIN card_low_tide t ON t.card_id = c.id;
''')
db.commit()
bad = db.execute('PRAGMA foreign_key_check').fetchall()
print('foreign key problems:', bad[:5] or 'none')
for t in ('cards', 'card_questions', 'card_watch_for', 'card_lit_lines', 'card_links', 'planet_questions', 'pair_prompts', 'decans'):
    print(t, db.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0])
db.close()
print(json.dumps(meta['counts']))
