"""dist/index.html -> dist-single/index.html: manifest, icons, README and license inlined."""
import base64, json, os
os.makedirs('dist-single', exist_ok=True)
html = open('dist/index.html').read()
b = lambda p: base64.b64encode(open(p, 'rb').read()).decode()
i192, i512, imask = (f'data:image/png;base64,{b("dist/" + f)}' for f in ('icon-192.png', 'icon-512.png', 'icon-maskable-512.png'))
man = json.load(open('dist/manifest.webmanifest'))
man['icons'] = [{'src': i192, 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'},
                {'src': i512, 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'},
                {'src': imask, 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'}]
boot = """<script>(function(){var u=location.href.split('#')[0].split('?')[0],b=u.replace(/[^\\/]*$/,'');
var m=%s;m.start_url=u;m.scope=b;m.id=u;
var l=document.createElement('link');l.rel='manifest';l.href='data:application/manifest+json;charset=utf-8,'+encodeURIComponent(JSON.stringify(m));document.head.appendChild(l);})();</script>""" % json.dumps(man, separators=(',', ':'))
assert '<link rel="manifest" href="manifest.webmanifest">\n' in html
html = html.replace('<link rel="manifest" href="manifest.webmanifest">\n', boot + '\n')
html = html.replace('<link rel="icon" href="icon-192.png">', f'<link rel="icon" href="{i192}">')
html = html.replace('<link rel="apple-touch-icon" href="icon-192.png">', f'<link rel="apple-touch-icon" href="{i192}">')
lic = open('dist/LICENSE').read().replace('--', '- -')
readme = open('README.md').read().replace('--', '- -')
html = html.replace('</html>', f'<!--\n{readme}\n\n{lic}\n-->\n</html>')
open('dist-single/index.html', 'w').write(html)
for f in ('sw.js',):
    open(f'dist-single/{f}', 'w').write(open(f'dist/{f}').read())
print('single file:', len(html))
