#!/usr/bin/env python3
"""Builds the Wanderer PWA into dist/: index.html (everything inlined), sw.js, manifest, icons."""
import base64, io, json, os, shutil, subprocess, sys
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(ROOT, 'dist')
EPHE = os.environ.get('EPHE', '../astro-tarot/ephe')   # sepl_18, semo_18, seas_18 .se1 from astro.com
CARDS = os.environ.get('CARDS', '../astro-tarot/cards')  # 00.jpg..77.jpg, Rider-Waite-Smith 1909
VERSION = sys.argv[1] if len(sys.argv) > 1 else '1.0.0'
b64 = lambda p: base64.b64encode(open(p, 'rb').read()).decode()

shutil.rmtree(DIST, ignore_errors=True); os.makedirs(DIST)
r = subprocess.run([os.path.join(ROOT, 'node_modules/.bin/esbuild'), 'src/main.jsx', '--bundle', '--minify', '--format=iife',
                    '--jsx=automatic', '--loader:.json=json', '--target=es2020', '--legal-comments=none',
                    '--define:process.env.NODE_ENV="production"', '--outfile=build/app.js'], cwd=ROOT, capture_output=True, text=True)
if r.returncode:
    sys.exit(r.stderr)
print(r.stderr.strip()[-300:])

cards = []
for i in range(78):
    im = Image.open(f'{CARDS}/{i:02d}.jpg').convert('RGB')
    im = im.resize((200, round(200 * im.height / im.width)), Image.LANCZOS)
    buf = io.BytesIO(); im.save(buf, 'JPEG', quality=72, optimize=True, progressive=True)
    cards.append(base64.b64encode(buf.getvalue()).decode())
assets = {'wasm': b64('assets/swisseph.wasm'), 'sepl': b64(f'{EPHE}/sepl_18.se1'), 'semo': b64(f'{EPHE}/semo_18.se1'),
          'seas': b64(f'{EPHE}/seas_18.se1'), 'cards': cards}

css = open('src/styles.css').read()
for k, f in {'__EB_R__': 'eb-Regular', '__EB_I__': 'eb-Italic', '__EB_S__': 'eb-SemiBold', '__GLYPHS__': 'glyphs'}.items():
    css = css.replace(k, b64(f'build/{f}.woff2'))
js = open('build/app.js').read().replace('</script', '<\\/script')

html = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Wanderer</title>
<meta name="description" content="A pocket almanac: your birth chart, today's sky, tarot, and the people you love.">
<meta name="theme-color" content="#ECE9F2" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#16142B" media="(prefers-color-scheme: dark)">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icon-192.png">
<link rel="apple-touch-icon" href="icon-192.png">
<!-- Wanderer {VERSION}. Free software, GNU AGPL v3. Source and license: see README.md and LICENSE. -->
<style>{css}</style>
</head>
<body>
<div id="root"><p style="padding:40vh 20px 0;text-align:center;font:italic 18px Georgia,serif;opacity:.6">Casting the sky…</p></div>
<script>window.__ASSETS={json.dumps(assets, separators=(',', ':'))};</script>
<script>{js}</script>
</body>
</html>'''
open(f'{DIST}/index.html', 'w').write(html)

manifest = {
    'name': 'Wanderer', 'short_name': 'Wanderer', 'description': 'Birth charts, daily astrology, tarot and compatibility.',
    'start_url': './', 'scope': './', 'display': 'standalone', 'orientation': 'portrait',
    'background_color': '#16142B', 'theme_color': '#16142B',
    'icons': [{'src': 'icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'},
              {'src': 'icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'},
              {'src': 'icon-maskable-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'}],
}
json.dump(manifest, open(f'{DIST}/manifest.webmanifest', 'w'), indent=1)

sw = f"""// Wanderer service worker: keeps the app working offline.
const CACHE = 'wanderer-{VERSION}';
const FILES = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './icon-maskable-512.png'];
self.addEventListener('install', e => {{ e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); }});
self.addEventListener('activate', e => {{ e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); }});
self.addEventListener('fetch', e => {{
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;   // geocoding and Claude go straight to the network
  e.respondWith(caches.match(e.request, {{ ignoreSearch: true }}).then(hit => hit || fetch(e.request).then(res => {{
    const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); return res; }})));
}});
"""
open(f'{DIST}/sw.js', 'w').write(sw)


def icon(size, maskable=False):
    S = size * 4
    im = Image.new('RGB', (S, S), (22, 20, 43)); d = ImageDraw.Draw(im)
    k = 0.30 if maskable else 0.36          # moon radius as a share of the icon
    r, cx, cy = S * k, S / 2, S / 2
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(230, 218, 186))
    off = r * 0.52                            # carve the crescent
    d.ellipse([cx - r + off, cy - r - r * 0.12, cx + r + off, cy + r - r * 0.12], fill=(22, 20, 43))
    s = r * 0.13; sx, sy = cx + r * 0.62, cy - r * 0.52
    d.polygon([(sx, sy - s * 2.2), (sx + s * 0.55, sy - s * 0.55), (sx + s * 2.2, sy), (sx + s * 0.55, sy + s * 0.55),
               (sx, sy + s * 2.2), (sx - s * 0.55, sy + s * 0.55), (sx - s * 2.2, sy), (sx - s * 0.55, sy - s * 0.55)], fill=(216, 177, 99))
    return im.resize((size, size), Image.LANCZOS)


icon(192).save(f'{DIST}/icon-192.png'); icon(512).save(f'{DIST}/icon-512.png'); icon(512, True).save(f'{DIST}/icon-maskable-512.png')
shutil.copy('assets/LICENSE-AGPL', f'{DIST}/LICENSE')
shutil.copy('README.md', f'{DIST}/README.md')
print({f: os.path.getsize(f'{DIST}/{f}') for f in os.listdir(DIST)})
