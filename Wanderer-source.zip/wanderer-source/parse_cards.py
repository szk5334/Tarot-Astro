#!/usr/bin/env python3
"""Turns the hand-written card batches (markdown) into assets/questions.json for the app.

Reads content/*.md plus the worked template in the foundation file. Each card block:
  ## Card Name / sky: ... / ### Upright (1-10) / ### Reversed (1-10) / ### Watch for / ### Low tide / ### Lit / ### Essence
"""
import glob, json, os, re, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
NAMES = {c['name']: c['id'] for c in json.load(open(os.path.join(ROOT, 'assets/meanings.json')))['cards']}
PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn']
KINDS = ['Yours', 'Touching you', 'Its season', "Today's weather", 'The long season', 'Turning']


def sources():
    for f in sorted(glob.glob(os.path.join(ROOT, 'content', 'batch-*.md'))):
        yield f, open(f).read()
    found = os.path.join(ROOT, 'content', 'card-questions-foundation.md')
    if os.path.exists(found):
        t = open(found).read()
        m = re.search(r'## Worked example: (.+?)\n(.*?)(?=\n## )', t, re.S)
        if m:
            yield found, f'## {m.group(1)}\n{m.group(2)}'


def parse_card(name, body, where):
    if name not in NAMES:
        sys.exit(f'{where}: unknown card "{name}"')
    secs = dict(re.findall(r'### (.+?)\n(.*?)(?=\n### |\Z)', body, re.S))
    card = {}
    for key, sec in (('up', 'Upright'), ('rev', 'Reversed')):
        qs = re.findall(r'^\s*(\d+)\. [^:]+: (.+)$', secs.get(sec, ''), re.M)
        if [int(n) for n, _ in qs] != list(range(1, 11)):
            sys.exit(f'{where}: {name} {sec} needs questions 1-10, got {[n for n, _ in qs]}')
        card[key] = [q.strip() for _, q in qs]
    w = secs.get('Watch for', '')
    parts = re.split(r'^(Upright|Reversed)\s*$', w, flags=re.M)
    watch = {}
    for i in range(1, len(parts), 2):
        cues = dict(re.findall(r'^- (\w+): (.+)$', parts[i + 1], re.M))
        missing = [p for p in PLANETS if p not in cues]
        if missing:
            sys.exit(f'{where}: {name} watch-for {parts[i]} missing {missing}')
        watch['up' if parts[i] == 'Upright' else 'rev'] = cues
    if set(watch) != {'up', 'rev'}:
        sys.exit(f'{where}: {name} needs upright and reversed watch-for cues')
    card['watch'] = watch
    lt = dict(re.findall(r'^- (Notice|Become): (.+)$', secs.get('Low tide', ''), re.M))
    if set(lt) != {'Notice', 'Become'}:
        sys.exit(f'{where}: {name} low tide needs Notice and Become')
    card['notice'], card['become'] = lt['Notice'], lt['Become']
    lit = dict(re.findall(r"^- ([A-Za-z' ]+?): (.+)$", secs.get('Lit', ''), re.M))
    bad = [k for k in lit if k not in KINDS]
    if bad:
        sys.exit(f'{where}: {name} has unknown lit kinds {bad}')
    for k in ("Today's weather", 'The long season'):
        if k in lit and '{planet}' not in lit[k]:
            sys.exit(f'{where}: {name} lit "{k}" must name the planet with {{planet}} {{is}}')
    card['lit'] = lit
    es = dict(re.findall(r'^- (Upright|Reversed|Figure): (.+)$', secs.get('Essence', ''), re.M))
    if set(es) != {'Upright', 'Reversed', 'Figure'}:
        sys.exit(f'{where}: {name} essence needs Upright, Reversed and Figure')
    card['essence'] = {'up': es['Upright'].strip(), 'rev': es['Reversed'].strip(), 'figure': es['Figure'].strip()}
    return NAMES[name], card


DAY_RUNGS = ['Look', 'Catch', 'Feel', 'Lean', 'Do']
HOUR_RUNGS = ['Look', 'One word', 'One line', 'Do']


def parse_planets():
    f = os.path.join(ROOT, 'content', 'planets-days-hours.md')
    if not os.path.exists(f):
        return
    text, out = open(f).read(), {}
    for name, body in re.findall(r'^## (.+?)\n(.*?)(?=^## |\Z)', text, re.S | re.M):
        name = name.strip()
        if name not in PLANETS:
            continue
        secs = dict(re.findall(r'### (.+?)\n(.*?)(?=\n### |\Z)', body, re.S))
        qs = lambda k, n: [q.strip() for q in re.findall(r'^\s*\d+\. (.+)$', secs.get(k, ''), re.M)] or sys.exit(f'planets: {name} missing {k}')
        kv = lambda k: dict((a, b.strip()) for a, b in re.findall(r'^- ([A-Za-z ]+?): (.+)$', secs.get(k, ''), re.M))
        dl, hl, dr, hr = kv('Day ladder'), kv('Hour ladder'), kv('Day read'), kv('Hour read')
        for want, got, k in ((DAY_RUNGS, dl, 'Day ladder'), (HOUR_RUNGS, hl, 'Hour ladder')):
            if [x for x in want if x not in got]:
                sys.exit(f'planets: {name} {k} needs {want}')
        for k in ('Meaning', 'Qualities', 'Watch for', 'Too much', 'Too little'):
            if k not in dr:
                sys.exit(f'planets: {name} Day read needs {k}')
        if 'Good for' not in hr:
            sys.exit(f'planets: {name} Hour read needs Good for')
        out[name] = {
            'day': {'q': qs('Day questions', 4), 'ladder': [{'name': r, 'text': dl[r]} for r in DAY_RUNGS], 'read': dr},
            'hour': {'q': qs('Hour questions', 3), 'ladder': [{'name': r, 'text': hl[r]} for r in HOUR_RUNGS], 'read': hr},
        }
    missing = [p for p in PLANETS if p not in out]
    if missing:
        sys.exit(f'planets: missing {missing}')
    json.dump(out, open(os.path.join(ROOT, 'assets/planets.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
    print(f'7 planets written: {sum(len(v["day"]["q"]) + len(v["hour"]["q"]) for v in out.values())} questions')


def main():
    parse_planets()
    out = {}
    for where, text in sources():
        for name, body in re.findall(r'^## (.+?)\n(.*?)(?=^## |\Z)', text, re.S | re.M):
            name = name.strip()
            if name.startswith('Batch') or name not in NAMES:
                continue
            cid, card = parse_card(name, body, os.path.basename(where))
            out[str(cid)] = card
    json.dump(out, open(os.path.join(ROOT, 'assets/questions.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
    n = len(out)
    print(f'{n} cards written: {sum(20 for _ in out)} questions, {n * 14} watch-for cues, '
          f'{sum(len(c["lit"]) for c in out.values())} lit lines')


if __name__ == '__main__':
    main()
