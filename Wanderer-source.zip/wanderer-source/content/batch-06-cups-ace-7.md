# Batch 6: Cups, Ace to Seven

Each card: 20 questions, 14 watch-for cues, a low-tide pointer, its lit lines and its essence.
Written in the card-specific style (no stock openings; see the foundation's style rules).

Cups are the suit of water: feeling, love, friendship, memory and longing. The Ace holds the
water quarter of the year (autumn). The Two, Three and Four each hold ten degrees of Cancer; the
Five, Six and Seven each hold ten degrees of Scorpio.

---

## Ace of Cups
sky: the water quarter of the year, Libra through Sagittarius · season: about Sep 23 – Dec 21 · lit by: Its season

### Upright
1. Central theme: What feeling has been filling me up lately, love, tenderness, being moved, and where did it come from?
2. Cross / boon: Is this open heart the bridge from what's ending to what's beginning, or is it spilling everywhere because I haven't given it a shape?
3. Root: Where did I first learn I could be loved, a person, a place, a moment, and what of it still runs under me?
4. Passing away: What old feeling is draining out of me, and what was it holding while it was full?
5. Front of mind: What am I letting myself feel on purpose right now, and what does feeling it open up?
6. Coming in: What new love, friendship or tenderness is arriving, and how wide am I willing to open the door?
7. Who you are: Where am I overflowing in this, and who gets to drink from it?
8. What surrounds you: Who around me is giving love freely right now, and am I letting myself receive it?
9. Hopes / fears: What do I hope to be filled with, and what am I afraid will spill if I open up?
10. Outcome: If I keep letting myself feel this much, what grows from it, and what would I need to stop guarding to let more in?

### Reversed
1. Central theme: Where is my cup turned over: emptied out, or holding something I won't let anyone see?
2. Cross / boon: Is a closed heart what's in the doorway, or a flood of feeling I haven't found the edges of?
3. Root: When did I learn that showing what I feel was a risk?
4. Passing away: What dried-up feeling am I ready to stop pretending is still there?
5. Front of mind: What feeling do I keep explaining away instead of feeling?
6. Coming in: What tender moment is on its way that will want my cup open, and is part of me already putting the lid on?
7. Who you are: Where am I pouring love into others and leaving none for myself?
8. What surrounds you: Who around me is closed off right now, and how much of their shut door am I taking personally?
9. Hopes / fears: If I let my cup overflow in front of someone, what am I afraid they'd do with it?
10. Outcome: If the cup stays turned over, what goes thirsty, and what one small feeling would I let myself have to start refilling it?

### Watch for
Upright
- Sun: Watch for the thing that makes your eyes sting with gladness, and don't hide your face.
- Moon: Watch for tears, a full chest or a wave of tenderness, and let it come.
- Mars: Watch for the courage it takes to say "I love you," "I'm glad you're here" or "that hurt."
- Mercury: Watch for kind words that land deeper than they were meant to.
- Jupiter: Watch for love you can give away freely, and give it.
- Venus: Watch for beauty that opens you: music, water, a face you love.
- Saturn: Watch for the quiet, steady love that's been there all along.

Reversed
- Sun: Watch for hiding your feelings so you look strong.
- Moon: Watch for numbness, and what you might be too tired to feel.
- Mars: Watch for a feeling that comes out as irritation because it couldn't come out as itself.
- Mercury: Watch for talking about a feeling instead of feeling it.
- Jupiter: Watch for giving affection to fill a hole in yourself.
- Venus: Watch for treats and comforts standing in for being cared for.
- Saturn: Watch for a heart kept closed for reasons that have run out.

### Low tide
- Notice: the five streams spilling over the cup's rim, and the dove coming down from above.
- Become: the dove. What are you carrying down, and who is it for?

### Lit
- Its season: The Sun is in this card's quarter of the year, Libra through Sagittarius, about September 23 to December 21: autumn, the season of water. Answer about what you're feeling as the year turns inward.

### Essence
- Upright: the cup running over
- Reversed: the cup turned over
- Figure: the dove

---

## Two of Cups
sky: Venus in Cancer, 0–10° Cancer · season: about Jun 21 – Jul 1 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: Who am I meeting halfway right now, and what are we offering each other?
2. Cross / boon: Is this partnership the bridge from what's ending to what's beginning, or am I leaning on it so I don't have to cross on my own?
3. Root: Who first met me as an equal, and what did that teach me about what a bond can be?
4. Passing away: What partnership or closeness is changing shape, and what did we give each other?
5. Front of mind: Whose hand am I reaching for on purpose right now, and what do I hope we'll make together?
6. Coming in: What new connection, agreement or reconciliation is arriving, and what do I want to bring to it?
7. Who you are: Where am I a good partner in this, and where do I hold back half my cup?
8. What surrounds you: Who around me is reaching toward me, and have I noticed?
9. Hopes / fears: What do I hope this bond will be, and what am I afraid it will ask me to give up?
10. Outcome: If we keep meeting each other like this, what do we become, and what would I need to say, or stop expecting, to meet them more fully?

### Reversed
1. Central theme: Where is a connection out of balance, one of us giving and the other holding back?
2. Cross / boon: Is a misunderstanding between us what stands in the way, or my reluctance to meet anyone halfway?
3. Root: What early friendship or love ended in a way that still shapes how I bond?
4. Passing away: What partnership am I ready to let change, or end, with kindness?
5. Front of mind: What conversation with someone am I rehearsing instead of having?
6. Coming in: Which crack between two cups is about to need mending, and who reaches across first?
7. Who you are: Where am I keeping score in a relationship?
8. What surrounds you: Who around me feels distant, and is the distance theirs, mine, or both?
9. Hopes / fears: What scares me about meeting someone exactly halfway, with nothing held back on either side?
10. Outcome: If the gap between us stays like this, where does it go, and what's the first small move I could make across it?

### Watch for
Upright
- Sun: Watch for a moment of being seen by someone as an equal.
- Moon: Watch for the comfort of someone who knows you, and tell them.
- Mars: Watch for a chance to stand up for a friend or partner.
- Mercury: Watch for the moment you both say "me too", and stay in it a little longer.
- Jupiter: Watch for an exchange that leaves both of you better off.
- Venus: Watch for a toast, a shared cup, a small gesture of affection.
- Saturn: Watch for a promise between two people, and keep your half.

Reversed
- Sun: Watch for needing to win a disagreement with someone you love.
- Moon: Watch for feeling left out by someone close, and say so gently.
- Mars: Watch for a quarrel over something small standing in for something big.
- Mercury: Watch for mixed signals, and ask instead of guessing.
- Jupiter: Watch for giving more than your share to keep the peace.
- Venus: Watch for affection that has become a habit rather than a choice.
- Saturn: Watch for an old hurt between you that still needs mending.

### Low tide
- Notice: the winged lion's head above them, and the house on the hill behind.
- Become: the woman holding out her cup. What are you offering, and what are you hoping for back?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Cancer), so closeness, partnership and meeting someone halfway are a lifelong thread for you. Answer about the bonds that have shaped you.
- Touching you: Venus, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so love, pleasure or what you value is part of today's question. Answer about the bond that matters most right now.
- Its season: The Sun is in this card's ten days of the year, about June 21 to July 1, the very start of summer. Answer about who you're reaching toward.
- Today's weather: {planet} {is} passing through the first ten degrees of Cancer, this card's slice of the sky, so a bond is in focus today. Answer about the person you're meeting halfway now.
- The long season: {planet} {is} moving through the first ten degrees of Cancer for months or years, an era of new and renewed closeness. Answer about the partnership slowly taking shape in your life.
- Turning: Venus, this card's planet, is retrograde (seeming to move backward), a time when old loves and friendships come back to mind. Answer about a bond you'd like to revisit.

### Essence
- Upright: two cups offered at once
- Reversed: the cup held back
- Figure: the woman holding out her cup

---

## Three of Cups
sky: Mercury in Cancer, 10–20° Cancer · season: about Jul 2 – Jul 11 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: Who are my people right now, and when did we last raise a cup together?
2. Cross / boon: Is friendship what gets me across this, or is the fun keeping me from something I need to face?
3. Root: Which friends first made me feel I belonged, and what of them do I still carry?
4. Passing away: What season with a group of friends is changing, and what was it like at its best?
5. Front of mind: What gathering or community am I deliberately building, and what's it for?
6. Coming in: What reunion, celebration or new friend is arriving, and how do I want to show up?
7. Who you are: Where do I feel most myself among other people?
8. What surrounds you: Who around me would come if I invited them, and why haven't I?
9. Hopes / fears: What do I hope my friendships will hold, and what am I afraid of being left out of?
10. Outcome: If I keep making room for my people like this, what grows between us, and what would I let go of to make more room?

### Reversed
1. Central theme: Where do I feel on the outside of a group, or stuck in a crowd that isn't really mine?
2. Cross / boon: Is a falling-out what stands in the way, or too many parties and too little rest?
3. Root: When did I first feel left out, and does it echo in this?
4. Passing away: What friendship am I ready to let drift, without blame?
5. Front of mind: What gossip or group drama keeps running in my head?
6. Coming in: Which invitation is coming that will make me choose between two circles, or between a circle and my own company?
7. Who you are: Where do I overdo it socially to avoid being alone with something?
8. What surrounds you: Who around me is the odd one out, and could I make room for them?
9. Hopes / fears: If my friends saw me without the party face, who do I think would stay?
10. Outcome: If my social life stays this way, what wears thin, and which one friendship would I tend to change it?

### Watch for
Upright
- Sun: Watch for a moment to celebrate someone else's good news out loud.
- Moon: Watch for the friends who feel like home, and reach out to one.
- Mars: Watch for a chance to back up a friend who needs it.
- Mercury: Watch for group chats, invitations and plans, and say yes to one.
- Jupiter: Watch for a reason to gather, however small.
- Venus: Watch for laughter, dancing, shared food: the joy of company.
- Saturn: Watch for the old friendships that have lasted, and thank one of them.

Reversed
- Sun: Watch for competing with friends instead of celebrating them.
- Moon: Watch for loneliness in a crowd.
- Mars: Watch for friction in a group, and whether it's yours to fix.
- Mercury: Watch for gossip, and step out of it.
- Jupiter: Watch for one more drink, one more night out, one more yes.
- Venus: Watch for spending time with people you don't enjoy, to avoid being left out.
- Saturn: Watch for a friendship that only lives on obligation.

### Low tide
- Notice: the fruit and gourds at their feet, and their three cups raised together.
- Become: one of the three women. What are you celebrating, and who's missing from the circle?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Cancer), so friendship, community and celebrating together are a lifelong thread for you. Answer about the people you've always gathered.
- Touching you: Mercury, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so messages, plans and talk are part of today's question. Answer about who you want to get in touch with.
- Its season: The Sun is in this card's ten days of the year, about July 2 to 11, early summer, the season of cookouts and long evenings. Answer about who you want around you.
- Today's weather: {planet} {is} passing through the middle ten degrees of Cancer, this card's slice of the sky, so friends and plans are in the air today. Answer about the people you want to see now.
- The long season: {planet} {is} moving through the middle ten degrees of Cancer for months or years, an era of finding your people. Answer about the community slowly gathering around you.
- Turning: Mercury, this card's planet, is retrograde (seeming to move backward), a time when old friends get back in touch. Answer about someone you'd like to hear from again.

### Essence
- Upright: the cups raised together
- Reversed: the party gone sour
- Figure: one of the three dancers

---

## Four of Cups
sky: Moon in Cancer, 20–30° Cancer · season: about Jul 12 – Jul 22 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What have I lost my taste for lately, and what am I sitting with instead?
2. Cross / boon: Is this pulling inward what lets me cross into something new, or is it making me miss the cup being offered?
3. Root: When did I first learn to go quiet and wait when nothing satisfied me?
4. Passing away: What dissatisfaction is lifting, and what did sitting with it show me?
5. Front of mind: What am I deliberately turning over in my mind, and what am I hoping it'll show me?
6. Coming in: What offer or chance is being held out to me, and would I see it if I looked up?
7. Who you are: Where am I bored with what I have, and is it the things or me?
8. What surrounds you: Who around me keeps offering something I keep waving away?
9. Hopes / fears: What do I hope is out there that would finally feel like enough, and what am I afraid I'll miss?
10. Outcome: If I keep sitting under this tree, what passes me by, and what would I need to stop expecting to notice what's being offered?

### Reversed
1. Central theme: What am I finally ready to look up from and say yes to?
2. Cross / boon: Is my withdrawal ending, or am I jumping at the next thing just to stop feeling flat?
3. Root: What old disappointment made me stop expecting much?
4. Passing away: What sulk am I ready to get up from?
5. Front of mind: What new interest has started tugging at me?
6. Coming in: What's arriving now that I'm paying attention again?
7. Who you are: Where have I been so far inside my head that I forgot to be in my life?
8. What surrounds you: Who around me has been patient while I was elsewhere?
9. Hopes / fears: If I uncrossed my arms and reached for the fourth cup, what would I be afraid of finding in it?
10. Outcome: If I keep reaching back toward life, where does it take me, and which first offer would I take?

### Watch for
Upright
- Sun: Watch for a chance you'd normally wave away, and look at it twice.
- Moon: Watch for a flat mood, and give it rest and quiet instead of a fix.
- Mars: Watch for the itch to kick something over just to feel a jolt, and what would actually stir you.
- Mercury: Watch for an invitation or message you're tempted to ignore.
- Jupiter: Watch for a generous hand you've been too flat to notice, and take what it's holding.
- Venus: Watch for a small pleasure you've stopped noticing, and taste it again.
- Saturn: Watch for the quiet that's doing you good, and protect it.

Reversed
- Sun: Watch for the moment your interest comes back, and follow it.
- Moon: Watch for energy returning to your body.
- Mars: Watch for an urge to act after a long sulk, and use it well.
- Mercury: Watch for a conversation that wakes you up.
- Jupiter: Watch for a new opportunity you'd have missed a month ago.
- Venus: Watch for something beautiful that gets through to you again.
- Saturn: Watch for a habit of refusing that you're ready to drop.

### Low tide
- Notice: the hand coming out of the cloud with a fourth cup, and his arms crossed.
- Become: the hand holding out the cup. How long have you been waiting for him to look up?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Cancer), so turning inward, contemplation and feeling what's missing are a lifelong thread for you. Answer about what you've always gone quiet to find.
- Touching you: The Moon, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few hours, so your mood is close to the surface. Answer about what you're actually in the mood for.
- Its season: The Sun is in this card's ten days of the year, about July 12 to 22, deep summer, hot and heavy, when everything slows. Answer about what you've stopped noticing.
- Today's weather: {planet} {is} passing through the last ten degrees of Cancer, this card's slice of the sky, so a low or restless mood is close today. Answer about what's being offered that you might be missing.
- The long season: {planet} {is} moving through the last ten degrees of Cancer for months or years, an era of turning inward. Answer about what you're slowly losing interest in, and what's taking its place.

### Essence
- Upright: the cup not yet noticed
- Reversed: looking up again
- Figure: the man under the tree

---

## Five of Cups
sky: Mars in Scorpio, 0–10° Scorpio · season: about Oct 23 – Nov 1 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What have I lost lately, and what's still standing behind me that I haven't turned around to see?
2. Cross / boon: Is grief the bridge I have to walk from the old life to the new one, or have I stopped at the riverbank?
3. Root: What early loss taught me how to grieve, or how not to?
4. Passing away: What sorrow is finally easing, and what did it teach me about what I love?
5. Front of mind: What loss am I deliberately letting myself feel right now, and what does feeling it make room for?
6. Coming in: What will turn my head toward the two cups still standing behind me?
7. Who you are: Where am I still in mourning, and is it something I need to keep doing a while?
8. What surrounds you: Who around me is grieving too, and could we stand together at the river?
9. Hopes / fears: What do I hope is still possible after this, and what am I afraid is gone for good?
10. Outcome: If I keep standing here grieving, what happens, and what would I need to believe about the cups behind me to turn around when I'm ready?

### Reversed
1. Central theme: Where am I starting to turn around after a loss, or refusing to grieve at all?
2. Cross / boon: Is regret what stands in the way, or the fear that moving on means forgetting?
3. Root: What loss did I never get to mourn properly?
4. Passing away: What "I should have" has had its say, and can I thank it and close the door?
5. Front of mind: What "if only" keeps replaying in my head?
6. Coming in: What's coming that will help me cross the bridge?
7. Who you are: Where am I blaming myself for something that wasn't mine to prevent?
8. What surrounds you: Who around me is offering comfort I've been too sad to take?
9. Hopes / fears: If the grief lifted, what am I afraid I'd lose along with it?
10. Outcome: If I keep looking only at what spilled, what does it cost me, and which thing that remains would I pick up first?

### Watch for
Upright
- Sun: Watch for a moment to let someone see you're sad.
- Moon: Watch for grief arriving in the body, tiredness, tightness, tears, and let it.
- Mars: Watch for anger inside the grief, and what it's protecting.
- Mercury: Watch for a conversation where you can say what you lost.
- Jupiter: Watch for what's still here, and name one thing.
- Venus: Watch for something soft to hold sadness in: a blanket, warm tea, a hand.
- Saturn: Watch for the slow work of mourning, and give it time.

Reversed
- Sun: Watch for the first moment you feel like yourself again.
- Moon: Watch for a mood lifting, and let it lift without guilt.
- Mars: Watch for self-blame, and answer it fairly.
- Mercury: Watch for "if only" thoughts, and write one down to look at it.
- Jupiter: Watch for help offered after a loss, and take it.
- Venus: Watch for joy coming back in small things.
- Saturn: Watch for a regret that's ready to become a lesson.

### Low tide
- Notice: the two cups still standing behind the figure, and the bridge over the river toward the house.
- Become: one of the two cups still standing. What do you want to say to the one who won't turn around?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Scorpio), so loss, grief and what stays standing are a lifelong thread for you. Answer about what you've carried through your losses.
- Touching you: Mars, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so heat and friction are part of today's question. Answer about the anger or the ache inside a loss.
- Its season: The Sun is in this card's ten days of the year, about October 23 to November 1, mid-fall, when the leaves come down and many people remember their dead. Answer about what you're mourning.
- Today's weather: {planet} {is} passing through the first ten degrees of Scorpio, this card's slice of the sky, so an old loss is close to the surface today. Answer about what you're grieving now.
- The long season: {planet} {is} moving through the first ten degrees of Scorpio for months or years, an era of loss and slow recovery. Answer about what you've lost, and what has stayed.
- Turning: Mars, this card's planet, is retrograde (seeming to move backward), a time when old feelings circle back. Answer about a grief that's returning to be felt.

### Essence
- Upright: the grief beside the river
- Reversed: turning back toward what remains
- Figure: the cloaked figure

---

## Six of Cups
sky: Sun in Scorpio, 10–20° Scorpio · season: about Nov 2 – Nov 11 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What memory has been visiting me lately, and why now?
2. Cross / boon: Is the past what helps me cross into what's next, or a garden I keep going back to instead?
3. Root: What place or person from childhood gave me a gift I still use?
4. Passing away: What old chapter am I finally ready to remember kindly, and leave behind?
5. Front of mind: What am I deliberately bringing back from the past into my life now?
6. Coming in: Who or what from long ago is coming back around, and how do I want to meet them?
7. Who you are: Where am I still the child in this, and is that a gift or a hiding place?
8. What surrounds you: Who around me knew me when, and what do they remember that I've forgotten?
9. Hopes / fears: What do I hope to feel again from long ago, and what am I afraid I've lost for good?
10. Outcome: If I keep carrying my past this way, what does it give my future, and what would I let stay in the past so I can carry the rest more lightly?

### Reversed
1. Central theme: Where am I stuck in "the way things used to be"?
2. Cross / boon: Is nostalgia what's in the way, or an old memory I've been avoiding?
3. Root: What from childhood still hurts, under the sweet memories?
4. Passing away: What old place or person am I ready to stop going back to?
5. Front of mind: What past version of things am I comparing everything to?
6. Coming in: Which old childhood room is about to ask me to move out, at least a little?
7. Who you are: Where am I trying to be who I was instead of who I am?
8. What surrounds you: Who around me keeps pulling me back into old roles?
9. Hopes / fears: If I stopped visiting the old garden, what would I be afraid of forgetting?
10. Outcome: If I keep looking backward, what do I miss now, and which one memory would I keep while letting the rest go?

### Watch for
Upright
- Sun: Watch for a moment of childlike delight, and let yourself have it.
- Moon: Watch for a smell, a taste or a song that brings back home.
- Mars: Watch for a chance to protect someone smaller or younger than you.
- Mercury: Watch for an old friend's name, a letter, an old photo.
- Jupiter: Watch for a small gift you could give, simply, the way a kid would.
- Venus: Watch for sweetness from the past: a favorite food, an old song.
- Saturn: Watch for what the years have taught you, and what you'd tell your younger self.

Reversed
- Sun: Watch for performing the person you used to be.
- Moon: Watch for homesickness for a home that's gone.
- Mars: Watch for old family roles flaring up.
- Mercury: Watch for retelling the same old story.
- Jupiter: Watch for overindulging in comfort from long ago.
- Venus: Watch for idealizing an old love.
- Saturn: Watch for the past used as a reason not to change.

### Low tide
- Notice: the white star-shaped flowers in the cups, and the guard walking away in the background.
- Become: the little girl being handed the cup of flowers. What do you remember about this day?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Scorpio), so memory, childhood and kindness carried from the past are a lifelong thread for you. Answer about the gifts you've carried forward.
- Touching you: The Sun, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few days, so attention and energy are shining on part of your life. Answer about a memory that wants your attention.
- Its season: The Sun is in this card's ten days of the year, about November 2 to 11, late fall, when evenings grow long and old memories come in with the dark. Answer about what you're remembering.
- Today's weather: {planet} {is} passing through the middle ten degrees of Scorpio, this card's slice of the sky, so a memory is near the surface today. Answer about the one that comes first.
- The long season: {planet} {is} moving through the middle ten degrees of Scorpio for months or years, an era of revisiting the past. Answer about the old story you're slowly rewriting.

### Essence
- Upright: the cup of flowers handed over
- Reversed: the garden you keep going back to
- Figure: the child receiving the flowers

---

## Seven of Cups
sky: Venus in Scorpio, 20–30° Scorpio · season: about Nov 12 – Nov 21 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What possibilities are floating in front of me right now, and which one do I keep coming back to?
2. Cross / boon: Are all these options the doorway from what's ending to what's next, or a fog I can't see the path through?
3. Root: What childhood daydream still shapes what I want?
4. Passing away: What fantasy am I ready to let fade, and what was it giving me?
5. Front of mind: Which dream am I deliberately choosing to make real, and what's its first ordinary step?
6. Coming in: What new choices are about to appear, and how will I tell the real ones from the shiny ones?
7. Who you are: Where am I a dreamer in this, and where does dreaming stand in for doing?
8. What surrounds you: Who around me is selling me a dream, and what do they get if I buy it?
9. Hopes / fears: What do I hope is inside one of these cups, and what am I afraid is in another?
10. Outcome: If I keep choosing from this many options, where do I end up, and what would I need to stop wanting so I can choose one and go?

### Reversed
1. Central theme: Where is the fog lifting, and what do I see clearly now that I didn't before?
2. Cross / boon: Is my indecision what stands in the way, or did I choose too fast?
3. Root: What illusion did I grow up believing about how life would turn out?
4. Passing away: What dream am I ready to admit was never mine?
5. Front of mind: What am I fantasizing about to avoid what's in front of me?
6. Coming in: Which of the seven cups is about to come down out of the clouds and into my hands?
7. Who you are: Where am I telling myself a story that isn't quite true?
8. What surrounds you: Who around me is clear-eyed, and could I borrow their clarity?
9. Hopes / fears: If I picked one cup and let the other six float away, which loss would sting most?
10. Outcome: If I keep the fantasy going, what does it cost me, and what one real thing would I choose instead?

### Watch for
Upright
- Sun: Watch for a dream you'd like people to know you have.
- Moon: Watch for daydreams, and which one your body actually leans toward.
- Mars: Watch for a choice that has waited too long, and make it.
- Mercury: Watch for too many tabs open and too many options, and close a few.
- Jupiter: Watch for a big wish worth writing down plainly.
- Venus: Watch for something lovely that might be a mirage, and look closer.
- Saturn: Watch for the one option that would still hold up a year from now.

Reversed
- Sun: Watch for a moment of clear sight about what you really want.
- Moon: Watch for escape, scrolling, shopping, sleeping, dreaming instead of living.
- Mars: Watch for rushing a choice just to end the uncertainty.
- Mercury: Watch for offers that sound too good, and ask one more question.
- Jupiter: Watch for chasing every option at once.
- Venus: Watch for falling for an idea of someone rather than the person.
- Saturn: Watch for a sober look at what's possible, and let it steady you.

### Low tide
- Notice: what's in the seven cups: a face, a veiled figure, a snake, a castle, jewels, a wreath and a dragon.
- Become: the figure in shadow with their back to us. Which cup do you reach for, and why that one?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Scorpio), so dreams, desire and having many paths to choose from are a lifelong thread for you. Answer about the dreams you've chosen, and the ones you haven't.
- Touching you: Venus, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so love and what you value are part of today's question. Answer about which of your wishes you truly want.
- Its season: The Sun is in this card's ten days of the year, about November 12 to 21, late fall, mist and early dark. Answer about what you're dreaming of.
- Today's weather: {planet} {is} passing through the last ten degrees of Scorpio, this card's slice of the sky, so wishes and choices are shimmering today. Answer about the option you keep coming back to now.
- The long season: {planet} {is} moving through the last ten degrees of Scorpio for months or years, an era of many possibilities. Answer about the dream you're slowly choosing.
- Turning: Venus, this card's planet, is retrograde (seeming to move backward), a time to look again at what you want. Answer about a dream worth reconsidering.

### Essence
- Upright: the seven cups in the clouds
- Reversed: the fog lifting
- Figure: the figure in shadow
