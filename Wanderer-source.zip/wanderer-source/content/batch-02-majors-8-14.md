# Batch 2: Strength to Temperance

Majors 8–14. Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position),
14 watch-for cues (one per day ruler, each orientation), a low-tide pointer, and its lit lines.

---

## Strength
sky: the sign Leo · season: about Jul 23 – Aug 22 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What strong feeling or instinct is moving in me right now, and what would it look like to hold it gently instead of fighting it?
2. Cross / boon: Is patience the gentle hand that gets me through this, or am I being so soft I never actually close my hands?
3. Root: When did I first meet something wild in myself and find it could be calmed, and who showed me how?
4. Passing away: What struggle with myself is quieting down, and what did I learn about my own nature while it lasted?
5. Front of mind: What am I meeting with steady courage on purpose right now, and what is that steadiness making real?
6. Coming in: What's arriving that will ask for soft hands rather than a hard grip, and how can I be ready to offer them?
7. Who you are: Where am I braver than I look, and what am I quietly holding that no one else sees?
8. What surrounds you: Who around me is all roar right now, and how could I meet them without either taming them or fearing them?
9. Hopes / fears: What do I hope I'm strong enough to face, and what am I afraid my wildness would do if I let it out?
10. Outcome: If I keep meeting things this gently and steadily, where does it lead, and what would I need to believe about myself to trust that strength?

### Reversed
1. Central theme: Where am I clenching to stay in control of a feeling, or letting it run me because holding it feels like too much?
2. Cross / boon: Is self-doubt what stands in the doorway, or a temper I keep having to wrestle back down?
3. Root: Whose big feelings frightened me when I was small, and do I still hold my own down because of it?
4. Passing away: What way of forcing myself through things am I ready to stop using?
5. Front of mind: What am I telling myself I'm too weak or too tired to face, and is that true today?
6. Coming in: What's arriving that will test my patience, and what would help me stay soft with it?
7. Who you are: When did I last feel my own courage, and where has it gone since?
8. What surrounds you: Who around me pokes at the lion in me, and what do they get when it roars?
9. Hopes / fears: If I unclenched, what am I afraid the lion would do?
10. Outcome: If I keep either gripping or giving way, where does that leave me, and where could I try a gentle, steady hand instead?

### Watch for
Upright
- Sun: Watch for a moment when you can be warm and strong at once, and let both show.
- Moon: Watch for the animal in you, hunger, tiredness, the need to stretch, and answer it kindly.
- Mars: Watch for anger rising, and see how long you can hold it in open hands before deciding what it's for.
- Mercury: Watch for a hard conversation you can have calmly, and say the true thing softly.
- Jupiter: Watch for someone who needs encouragement more than advice.
- Venus: Watch for desire, and enjoy it without handing it the reins.
- Saturn: Watch for the quiet endurance that got you through this week, and give it credit.

Reversed
- Sun: Watch for pride that's covering a wobble in confidence.
- Moon: Watch for feelings you've sat on so hard that your body is holding them instead.
- Mars: Watch for a short fuse, and what it's actually protecting.
- Mercury: Watch for the voice in your head that says you can't, and ask where it learned that.
- Jupiter: Watch for overdoing it to prove you're fine.
- Venus: Watch for an appetite you're either denying or feeding to quiet something else.
- Saturn: Watch for grim self-control that leaves no room for gentleness.

### Low tide
- Notice: the loop of infinity above her head, and the chain of flowers running from her waist to the lion.
- Become: the lion. Why are you letting her close your mouth?

### Lit
- Yours: You were born with a planet in Leo, this card's sign, so courage, warmth and what you do with big feelings are a lifelong thread for you. Answer about the strength you've grown into.
- Its season: The Sun is in Leo, about July 23 to August 22, the height of summer. Answer about what in you wants to be brave and warm right now.
- Today's weather: {planet} {is} passing through Leo, Strength's sign, so a feeling with some heat in it is near the surface today. Answer about the nerve or the temper you're meeting now.
- The long season: {planet} {is} moving through Leo for months or years, slowly growing your courage and the way you show yourself. Answer about the confidence changing in you.

### Essence
- Upright: the lion held gently
- Reversed: the grip that won't relax
- Figure: the lion

---

## The Hermit
sky: the sign Virgo · season: about Aug 23 – Sep 22 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What question am I carrying that I can only answer alone, and what would I see if I gave it a quiet hour?
2. Cross / boon: Is stepping back the path up the mountain, or has the mountain become a place to hide from the next step?
3. Root: When did I first find something true on my own, away from everyone, and where was I standing?
4. Passing away: What season of withdrawal or study is ending, and what am I bringing back down the mountain?
5. Front of mind: What am I searching for on purpose right now, and what is my lantern lighting one step ahead?
6. Coming in: What stretch of quiet, or what teacher, is on its way, and how do I want to meet it?
7. Who you are: Where am I the one who has already walked this path, and whose way could I light?
8. What surrounds you: Who around me needs space right now, and who is quietly waiting for me to come back?
9. Hopes / fears: What do I hope I'll finally understand if I'm left alone long enough, and what am I afraid I'll find by lantern light?
10. Outcome: If I keep following my own small light, where does the path lead, and who would I want to walk part of it with?

### Reversed
1. Central theme: Where has time alone turned into isolation, or where am I so surrounded that I can't hear myself think?
2. Cross / boon: Is it my hiding that keeps me stuck, or the crowd I won't step away from?
3. Root: When did working things out alone start to feel safer than asking, and who wasn't there to ask?
4. Passing away: What hiding place have I outgrown, and am I ready to come down from it?
5. Front of mind: What am I studying and studying so I never have to act on it?
6. Coming in: Is the path ahead leading me back down the mountain to people, or further up to be alone?
7. Who you are: Where am I lonely and calling it independence?
8. What surrounds you: Who around me has gone quiet, and do they want to be found?
9. Hopes / fears: What would people think if I disappeared for a while to be alone, and does it matter?
10. Outcome: If I keep climbing away from everyone, or never climb away at all, where does that leave me, and when would I set the lantern down and come back?

### Watch for
Upright
- Sun: Watch for a moment when what you quietly know helps someone, without your needing credit for it.
- Moon: Watch for a stretch of the day that's just yours, and keep it that way.
- Mars: Watch for an urge to fix things for others that would be better spent on your own question.
- Mercury: Watch for a book, a sentence or an old note that answers something you've been asking.
- Jupiter: Watch for a teacher in plain clothes: someone further along, saying very little.
- Venus: Watch for the pleasure of your own company: a walk, a meal alone, a small light at night.
- Saturn: Watch for the patience of a slow, careful search, and let it take as long as it takes.

Reversed
- Sun: Watch for hiding your light because being seen feels like too much.
- Moon: Watch for withdrawing when what you actually need is comfort.
- Mars: Watch for irritation with people that's really a need for a break.
- Mercury: Watch for over-researching, rereading, collecting more notes instead of deciding.
- Jupiter: Watch for advice you hand out but don't take.
- Venus: Watch for turning down warmth because accepting it feels like owing something.
- Saturn: Watch for loneliness you've grown so used to that it feels like a rule.

### Low tide
- Notice: the six-pointed star inside his lantern, and the snow under his feet.
- Become: the Hermit. Who are you holding the lantern up for: yourself, or someone climbing behind you?

### Lit
- Yours: You were born with a planet in Virgo, this card's sign, so careful thought, solitude and getting to the heart of things are a lifelong thread for you. Answer about the wisdom you've found on your own.
- Its season: The Sun is in Virgo, about August 23 to September 22, the turn from summer toward fall, when the harvest gets sorted. Answer about what you need to step back and look at.
- Today's weather: {planet} {is} passing through Virgo, the Hermit's sign, so something needs sorting out quietly today. Answer about what you need an hour alone to think through.
- The long season: {planet} {is} moving through Virgo for months or years, a long stretch of inner work and careful sorting. Answer about what you're slowly learning on your own.

### Essence
- Upright: the lantern carried alone
- Reversed: solitude turned to hiding
- Figure: the Hermit

---

## Wheel of Fortune
sky: Jupiter · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What is turning in my life right now, and what part of the change can I already point to?
2. Cross / boon: Is this turn of the wheel lifting me into what's next, or am I waiting for it to do what my own hands should?
3. Root: What earlier turn, up or down, set all of this in motion, and how does it look from here?
4. Passing away: What chapter is rolling out of view, and what did I learn about riding its ups and downs?
5. Front of mind: What change am I watching for on purpose, and what am I making more likely by watching for it?
6. Coming in: What new chapter is turning toward me, and how can I meet it with curiosity instead of bracing?
7. Who you are: Where am I steady at the hub while things spin, and where am I clinging to the rim?
8. What surrounds you: What around me is changing that I didn't choose, and who is going through it with me?
9. Hopes / fears: What lucky break am I quietly counting on, and what reversal do I brace for every time things go well?
10. Outcome: If the wheel keeps turning the way it's turning, where do I come up, and how would I want to be standing when I get there?

### Reversed
1. Central theme: Where do I feel stuck at the bottom of a turn, or keep circling the same pattern?
2. Cross / boon: Am I stuck because I'm bracing against the turn, or because I'm waiting for luck that needs a push from me?
3. Root: Which change, long ago, took something from me, and do I still brace every time the wheel moves?
4. Passing away: What pattern that keeps repeating am I finally ready to see the end of?
5. Front of mind: What bad turn am I rehearsing in my head before it's happened?
6. Coming in: As the wheel comes round again, what part of how things were will it carry away?
7. Who you are: Where am I blaming luck for something I have a hand in, or blaming myself for something I don't?
8. What surrounds you: What's shifting around me that I keep pretending isn't?
9. Hopes / fears: Which scares me more right now: the wheel stopping where it is, or the wheel turning again?
10. Outcome: If I keep going around this same circle, where does it bring me back to, and where on the rim could I step off?

### Watch for
Upright
- Sun: Watch for a change that puts you in a better light, and step into it.
- Moon: Watch for the rhythm of the day: what keeps coming back around at home, in your body, in your mood.
- Mars: Watch for an opening that won't stay open long, and move while it's there.
- Mercury: Watch for a coincidence, a chance meeting or a message that arrives at exactly the right time.
- Jupiter: Watch for good luck, small or large, and say thank you out loud.
- Venus: Watch for a turn in a relationship, a taste or a mood, and enjoy where it's going.
- Saturn: Watch for the long pattern under today: what this moment has in common with the same season years ago.

Reversed
- Sun: Watch for feeling passed over, and whether the moment is really over.
- Moon: Watch for a familiar low mood coming around, and greet it as a visitor, not a verdict.
- Mars: Watch for trying to force a turn that isn't ready.
- Mercury: Watch for delays, crossed wires and missed timing, and let them slow you down.
- Jupiter: Watch for betting on luck instead of doing the work.
- Venus: Watch for an old relationship pattern repeating, and notice the moment it starts.
- Saturn: Watch for the habit that keeps bringing you back to the same place.

### Low tide
- Notice: the four winged creatures reading in the corners, and the snake sliding down one side of the wheel while the jackal-headed figure rises up the other.
- Become: the sphinx sitting on top of the wheel. What do you see from up there, and how long do you expect to stay?

### Lit
- Yours: Jupiter, this card's planet, holds a strong place in your birth chart, so luck, growth and timing are a lifelong thread for you. Answer about the turns that have shaped your life.
- Touching you: Jupiter, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so something in your life is ready to grow or open. Answer about where the wheel is turning your way.
- Turning: Jupiter, this card's planet, is retrograde (seeming to move backward), a time when growth turns inward. Answer about what you'd grow in yourself before reaching for more.

### Essence
- Upright: the wheel turning
- Reversed: the same circle again
- Figure: the sphinx on the wheel

---

## Justice
sky: the sign Libra · season: about Sep 23 – Oct 22 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What am I weighing right now, and if I set every fact down plainly, which way does it lean?
2. Cross / boon: Is honesty the solid ground that gets me across, or am I weighing and reweighing so I never have to step?
3. Root: What choice, mine or one made for me, set all of this in motion, and can I look at it straight?
4. Passing away: What old account is being settled, and what did it teach me about fairness?
5. Front of mind: What decision am I deliberately making as fairly as I can, and what does making it fairly make real?
6. Coming in: What answer, agreement or consequence is on its way, and how do I want to receive it?
7. Who you are: Where am I the fair one in this, and am I being as fair to myself as to everyone else?
8. What surrounds you: Who around me is keeping score, and is the score accurate?
9. Hopes / fears: What do I hope the truth will show when it all comes out, and what am I afraid it will show about me?
10. Outcome: If I keep acting on what I see clearly, where does it lead, and what would I still need to look at straight?

### Reversed
1. Central theme: Where am I avoiding an honest look at my part in this, or carrying more of it than is mine?
2. Cross / boon: Is something unfair standing in the way, and is it mine to set right or mine to let go?
3. Root: Who taught me that being fair meant being hardest on myself?
4. Passing away: What grudge or old score am I ready to stop keeping?
5. Front of mind: What am I justifying in my head that I wouldn't need to justify if it sat right?
6. Coming in: What consequence is on its way to my door, and how can I meet it squarely without punishing myself?
7. Who you are: Where am I judging someone, maybe me, by a rule I don't apply to anyone else?
8. What surrounds you: Who around me is being treated unfairly, and is there something small I could do about it?
9. Hopes / fears: What would happen if I put the whole truth on the scales, my part included?
10. Outcome: If the scales stay tipped this way, what keeps happening, and what weight would I move first?

### Watch for
Upright
- Sun: Watch for a moment to stand openly by a decision you've made.
- Moon: Watch for how fairly the work of home is shared, and say something if it isn't.
- Mars: Watch for a wrong worth naming, and name it without cruelty.
- Mercury: Watch for a contract, a form or a promise in writing, and read it all the way through.
- Jupiter: Watch for a chance to judge generously, giving someone the benefit of the doubt.
- Venus: Watch for the balance of giving and receiving in a relationship.
- Saturn: Watch for a consequence arriving on time, and meet it squarely.

Reversed
- Sun: Watch for needing to be right more than needing to be fair.
- Moon: Watch for old hurt making decisions for you.
- Mars: Watch for wanting payback, and what it would really fix.
- Mercury: Watch for stories that leave out your own part, or leave out everyone else's.
- Jupiter: Watch for excusing something because the person is likable.
- Venus: Watch for keeping the peace at the cost of the truth.
- Saturn: Watch for self-blame out of proportion to what happened.

### Low tide
- Notice: the white shoe stepping out from under her robe, and that the sword points straight up.
- Become: Justice. What's sitting on each side of your scales right now, and which way are they leaning?

### Lit
- Yours: You were born with a planet in Libra, this card's sign, so fairness, balance and weighing both sides are a lifelong thread for you. Answer about how you've learned to make a fair decision.
- Its season: The Sun is in Libra, about September 23 to October 22, the first month of fall, when day and night start out nearly even. Answer about what you're weighing.
- Today's weather: {planet} {is} passing through Libra, Justice's sign, so a decision or a question of fairness is live today. Answer about what's on the scales now.
- The long season: {planet} {is} moving through Libra for months or years, slowly rebalancing your agreements and what you owe. Answer about the terms being rewritten in your life.

### Essence
- Upright: the honest weighing
- Reversed: the scales tipped
- Figure: Justice

---

## The Hanged Man
sky: Neptune (the element of Water) · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What am I waiting on right now, and what would I notice if I stopped struggling and looked at it upside down?
2. Cross / boon: Is this suspended time the doorway to something new, or has the waiting become the thing I'm stuck in?
3. Root: When did giving something up first turn my view upside down in a good way?
4. Passing away: What sacrifice am I finishing, and what did giving it up make room for?
5. Front of mind: What am I deliberately looking at from a new angle, and what is that angle showing me?
6. Coming in: What pause or change of perspective is on its way, and how can I let it arrive without rushing it?
7. Who you are: Where do I see this differently from everyone else, and am I at peace with that?
8. What surrounds you: Who around me thinks I'm stuck, and what do I know about this pause that they don't?
9. Hopes / fears: What do I hope would come if I stopped struggling, and what am I afraid I'd have to give up?
10. Outcome: If I let this hang a while longer, what comes clear, and what would I need to stop needing to know first?

### Reversed
1. Central theme: Where am I stalling and calling it patience, or giving up more than this asks?
2. Cross / boon: Is my refusal to stop what's keeping this stuck, or a wait that should have ended a while ago?
3. Root: Who taught me that sacrificing for others is what makes a person good, and do I still believe it?
4. Passing away: What sacrifice have I been making that no one asked for, and can I stop?
5. Front of mind: What am I turning over and over in my head when what it needs is to be turned around?
6. Coming in: Which forced pause is on its way, an illness, a delay, a closed door, and am I already kicking against it?
7. Who you are: Where am I playing the martyr, even a little?
8. What surrounds you: Who around me is waiting on me to decide, and how long have they been waiting?
9. Hopes / fears: What do I picture falling apart if I stopped keeping everything moving, even for a day?
10. Outcome: If I keep hanging here without looking around, or keep refusing to hang at all, what do I miss, and what would I let myself see from upside down?

### Watch for
Upright
- Sun: Watch for a moment when being out of step with everyone turns out to be fine.
- Moon: Watch for rest your body is asking for, and take it without explaining.
- Mars: Watch for the urge to force a result, and see what happens if you wait one more day.
- Mercury: Watch for a sentence that means something different when you read it from the other side.
- Jupiter: Watch for something you give up today that turns out to be a gift.
- Venus: Watch for beauty that only shows from an odd angle: lying down, in a reflection, in a shadow.
- Saturn: Watch for a delay that's doing you a favor.

Reversed
- Sun: Watch for staying stuck because moving would mean being seen to change your mind.
- Moon: Watch for drifting, scrolling or zoning out, and what feeling you're stepping around.
- Mars: Watch for restlessness that wants anything to happen, even something you don't want.
- Mercury: Watch for indecision dressed up as gathering more information.
- Jupiter: Watch for giving more than you can spare, of time, money or patience.
- Venus: Watch for staying in a stuck situation for the sake of someone else's comfort.
- Saturn: Watch for waiting on permission no one is going to give.

### Low tide
- Notice: the calm on his face and the light around his head, and that the wood he hangs from is alive and leafing.
- Become: the Hanged Man. What does the world look like from where you are, and why aren't you trying to get down?

### Lit
- Yours: Neptune, this card's planet, holds a strong place in your birth chart, so dreams, surrender and seeing past the obvious are a lifelong thread for you. Answer about the times letting go has shown you something.
- Touching you: Neptune, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so something solid in your life may be softening or blurring. Answer about what you're being asked to see differently.
- Turning: Neptune, this card's planet, is retrograde (seeming to move backward), as it is for about five months each year, a time when the fog thins a little. Answer about an illusion you're ready to look through.

### Essence
- Upright: the pause that turns the view around
- Reversed: the wait that's become stuck
- Figure: the Hanged Man

---

## Death
sky: the sign Scorpio · season: about Oct 23 – Nov 21 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What in my life is ending right now, and what can I point to that tells me it's already over?
2. Cross / boon: Is this ending the passage to what's next, or am I standing in the doorway holding on to the frame?
3. Root: What ending, long ago, cleared the ground for all of this, and what grew there afterward?
4. Passing away: What am I letting die, and what would I like to say to it before it goes?
5. Front of mind: What am I consciously finishing, and what space does finishing it make real?
6. Coming in: What new form is on its way once this is fully over, and how can I empty my hands for it?
7. Who you are: Who was I before this change began, and who am I becoming because of it?
8. What surrounds you: Who around me is going through an ending too, and how are they meeting it differently from me?
9. Hopes / fears: What do I hope this ending will free me from, and what am I afraid will go with it?
10. Outcome: If I let this end cleanly, what's left standing, and what would I need to say goodbye to first?

### Reversed
1. Central theme: What am I keeping alive that's already over?
2. Cross / boon: Is my grip on what's over the thing in the way, or a change I keep putting off?
3. Root: When did I first learn to see an ending as a failure instead of a turning?
4. Passing away: What has ended that I haven't let myself grieve?
5. Front of mind: What change do I keep thinking about and keep putting off?
6. Coming in: What's coming that I'm already resisting because it means something has to go?
7. Who you are: Which old version of myself am I still trying to be?
8. What surrounds you: Who or what around me is clinging to the way things were, and is it holding me there too?
9. Hopes / fears: What do I picture on the far side of letting this go, and how sure am I that it's true?
10. Outcome: If I keep postponing this ending, what does it cost me, and what would I need to grieve to let it happen?

### Watch for
Upright
- Sun: Watch for a moment when you can let people see you've changed.
- Moon: Watch for something at home ready to be cleared out: a drawer, a shelf, an old routine.
- Mars: Watch for a clean cut you've been avoiding, and make it kindly.
- Mercury: Watch for a conversation that closes a chapter, and let it close.
- Jupiter: Watch for the new growth already showing where something ended.
- Venus: Watch for the beauty in things that are fading: late light, falling leaves, the last of something.
- Saturn: Watch for what has run its full course, and give it a proper ending.

Reversed
- Sun: Watch for clinging to an old role because it's how people know you.
- Moon: Watch for grief showing up as tiredness, irritability or not being hungry.
- Mars: Watch for fighting a change that's already happened.
- Mercury: Watch for reopening a conversation that's already finished.
- Jupiter: Watch for buying, adding or saying yes so you don't notice what's gone.
- Venus: Watch for holding onto a person, a thing or a habit for comfort past its time.
- Saturn: Watch for fear of the unknown dressed up as loyalty to the known.

### Low tide
- Notice: the child holding out flowers, and the sun rising between the two towers in the distance.
- Become: the child. Why aren't you afraid?

### Lit
- Yours: You were born with a planet in Scorpio, this card's sign, so depth, endings and becoming someone new are a lifelong thread for you. Answer about the changes that have remade you.
- Its season: The Sun is in Scorpio, about October 23 to November 21, the middle of fall, when the leaves come down. Answer about what's ready to fall away.
- Today's weather: {planet} {is} passing through Scorpio, Death's sign, so an ending or a deep change is close to the surface today. Answer about what's finishing now.
- The long season: {planet} {is} moving through Scorpio for months or years, a long season of things changing form. Answer about what in your life is slowly becoming something else.

### Essence
- Upright: the ending that makes room
- Reversed: the ending held off
- Figure: the child with the flowers

---

## Temperance
sky: the sign Sagittarius · season: about Nov 22 – Dec 21 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What two things in my life am I mixing right now, and what's the right amount of each today?
2. Cross / boon: Is moderation the steady path across, or is all my careful balancing keeping me from committing to either side?
3. Root: Who first showed me how to stay steady in the middle of things, and what did their calm look like?
4. Passing away: What extreme am I coming back from, and what did it teach me about my own middle?
5. Front of mind: What am I blending on purpose right now, and what is that blend becoming?
6. Coming in: What healing or new combination is on its way, and how can I give it the time it needs to mix?
7. Who you are: Where am I the calm one in this, and does that calm cost me anything?
8. What surrounds you: Who around me is pouring into my life, and who am I pouring into?
9. Hopes / fears: What do I hope will finally come into balance, and what am I afraid I'll have to pour out to get there?
10. Outcome: If I keep mixing my life this way, what does it become, and which ingredient would I add more of, or less?

### Reversed
1. Central theme: Where am I running too hot or too cold, all or nothing, with no middle?
2. Cross / boon: Is it too much of something that's tipping this over, or too little?
3. Root: Who did I learn all-or-nothing from, and what did their extremes look like?
4. Passing away: What excess am I ready to let go of, and what was it standing in for?
5. Front of mind: What am I pushing so hard to fix that it can't settle?
6. Coming in: What's coming that will pull me toward an extreme, and what would help me stay level?
7. Who you are: Where in my life am I out of proportion: too much work, too little rest, too much of one person?
8. What surrounds you: Who or what around me pulls me off balance, and what's the pull?
9. Hopes / fears: What do I imagine would happen if I stopped swinging and stayed in the middle for a while?
10. Outcome: If the mixture stays this lopsided, what spills over, and where would I steady my hand first?

### Watch for
Upright
- Sun: Watch for the moment you're at your best because you're neither rushing nor holding back.
- Moon: Watch for the balance of the day, food and rest, company and quiet, and adjust one of them.
- Mars: Watch for heat you can cool by one degree before you act.
- Mercury: Watch for two ideas or two people you could bring together.
- Jupiter: Watch for a chance to share a big view patiently, letting others come to it in their own time.
- Venus: Watch for a good blend: a recipe, a scent, a pairing of colors, two friends who get on.
- Saturn: Watch for the steadiness of doing a little each day, and let that be enough.

Reversed
- Sun: Watch for going all out to be noticed, and what a quieter version would look like.
- Moon: Watch for swinging between too much and too little: food, sleep, screens, people.
- Mars: Watch for impatience that wants everything settled today.
- Mercury: Watch for saying too much or too little, and the moment you could adjust.
- Jupiter: Watch for one more coffee, one more yes, one more thing.
- Venus: Watch for pleasure that has tipped into excess, or been denied too long.
- Saturn: Watch for rigid rules that leave no room to adjust.

### Low tide
- Notice: one foot in the water and one on the land, and the path behind leading up to a light between two mountains.
- Become: the angel. What are you mixing in those two cups, and how will you know when it's right?

### Lit
- Yours: You were born with a planet in Sagittarius, this card's sign, so seeking, meaning and finding the middle path are a lifelong thread for you. Answer about how you've learned to balance big hopes with daily life.
- Its season: The Sun is in Sagittarius, about November 22 to December 21, the last month of fall, heading toward the longest night. Answer about what needs patience to come together.
- Today's weather: {planet} {is} passing through Sagittarius, Temperance's sign, so the pull toward too much or too little is live today. Answer about the balance you're trying to strike now.
- The long season: {planet} {is} moving through Sagittarius for months or years, slowly blending what you believe with how you live. Answer about the mixture changing in this era.

### Essence
- Upright: the right mixture
- Reversed: all or nothing
- Figure: the angel pouring
