# Batch 4: Wands, Ace to Seven

Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position), 14 watch-for
cues (one per day ruler, each orientation), a low-tide pointer, and its lit lines.

Wands are the suit of fire: drive, desire, spark and what you want to do. The Ace holds the
fire quarter of the year (summer). The Twos to Sevens each hold ten degrees of a fire sign,
about ten days of the Sun's year.

---

## Ace of Wands
sky: the fire quarter of the year, Cancer through Virgo · season: about Jun 21 – Sep 22 · lit by: Its season

### Upright
1. Central theme: What spark has caught in me lately, an idea, a want, a burst of energy, and what would I do with it today if I trusted it?
2. Cross / boon: Is this new spark the fire that lights the way into what's next, or a flare I keep mistaking for a direction?
3. Root: What first lit me up, as a kid or later, and how much of all this still burns on that fire?
4. Passing away: What old enthusiasm has burned down to embers, and what warmth is still in it?
5. Front of mind: What am I deliberately fanning right now, and what is that flame starting to make real?
6. Coming in: What fresh start or burst of inspiration is on its way, and how can I be ready to catch it before it fades?
7. Who you are: Where do I feel most alive in this, and what am I doing when it happens?
8. What surrounds you: Who around me sparks something in me, and what do I feel like making when I'm with them?
9. Hopes / fears: What do I hope this spark could become, and what am I afraid of if it goes out?
10. Outcome: If I keep feeding this spark, what does it grow into, and what would I clear away to give it more air?

### Reversed
1. Central theme: Where has my spark gone out, or where am I full of energy with nowhere to put it?
2. Cross / boon: Is it a lack of drive that's holding me back, or so many sparks that none of them catch?
3. Root: What put out an early fire in me, and does that old smoke still hang over this?
4. Passing away: What idea have I been carrying that's never going to catch, and can I set it down?
5. Front of mind: What am I excited about in my head that hasn't reached my hands?
6. Coming in: What's coming that could relight me, and what's keeping the kindling damp?
7. Who you are: When did I last feel truly eager about something, and what changed?
8. What surrounds you: Who around me dampens my fire, and do they mean to?
9. Hopes / fears: What do I picture happening if I really went for something, all the way?
10. Outcome: If the spark stays this low, where does that leave me, and what's the smallest thing I could try that might relight it?

### Watch for
Upright
- Sun: Watch for the moment an idea lights you up, and let someone see it on your face.
- Moon: Watch for the first flicker of energy in your body today, and follow it for five minutes.
- Mars: Watch for an urge to start something right now, and start it before you plan it.
- Mercury: Watch for an idea in a conversation that makes you sit up, and write it down.
- Jupiter: Watch for an opportunity that feels like an invitation, and say yes to the first step.
- Venus: Watch for desire, for a person, a place or a project, and let it warm you.
- Saturn: Watch for the one small habit that could keep a new fire burning past this week.

Reversed
- Sun: Watch for holding back an idea because you're not sure it's good enough to show.
- Moon: Watch for flat, low energy, and ask your body what it needs before you push.
- Mars: Watch for frustration that's really energy with nowhere to go.
- Mercury: Watch for ideas you keep collecting and never start.
- Jupiter: Watch for starting five things so you don't have to finish one.
- Venus: Watch for chasing a thrill just to feel something.
- Saturn: Watch for "not yet" that has quietly become "never."

### Low tide
- Notice: the new leaves sprouting from the wand, and the castle on the hill far off.
- Become: the wand. Whose hand is holding you, and what do you want to grow into?

### Lit
- Its season: The Sun is in this card's quarter of the year, Cancer through Virgo, about June 21 to September 22: summer, the season of fire. Answer about what you want to start while there's heat and light.

### Essence
- Upright: the first spark
- Reversed: the spark gone out
- Figure: the wand

---

## Two of Wands
sky: Mars in Aries, 0–10° Aries · season: about Mar 20 – Mar 30 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What bigger plan am I holding in my hands right now, and what's the first part of it I can actually see from here?
2. Cross / boon: Is ambition the road out from the old life to the new, or am I standing on the wall looking out instead of leaving?
3. Root: What first made me want more than the place I started from, and where did I think "more" would be?
4. Passing away: What safe, familiar ground am I finishing with, and what did it give me to plan from?
5. Front of mind: What future am I mapping on purpose right now, and what does mapping it make real?
6. Coming in: What wider horizon is opening toward me, and what would I need to decide before I set out?
7. Who you are: Where am I further along than I give myself credit for, and why am I restless anyway?
8. What surrounds you: Who around me is part of my plans, and do they know it?
9. Hopes / fears: What world do I hope to hold in my hand someday, and what am I afraid I'll give up to reach it?
10. Outcome: If I keep planning this way, where do I end up, and what would I need to decide to actually take the first step?

### Reversed
1. Central theme: Where am I playing it safe inside a plan I've outgrown, or making plans I never mean to leave home for?
2. Cross / boon: Is fear of the unknown keeping me on the battlement, or a plan so big I can't find its first step?
3. Root: Who taught me to stay inside the walls, and does that lesson still steer this?
4. Passing away: What plan am I ready to admit isn't going to happen, and what did dreaming it give me?
5. Front of mind: What am I planning over and over in my head instead of choosing?
6. Coming in: Which ship is about to sail, and am I already making excuses to stay on the wall?
7. Who you are: Where have I settled for a small corner of what I wanted?
8. What surrounds you: Who around me would be uneasy if I went further, and how much is that holding me?
9. Hopes / fears: What might I find out about myself if I really left the castle?
10. Outcome: If I keep holding the globe and not moving, what does that cost me, and which direction would I point to if I had to choose today?

### Watch for
Upright
- Sun: Watch for a chance to say your bigger plan out loud to someone.
- Moon: Watch for the comfort of home, and whether it's rest or a reason not to go.
- Mars: Watch for the first bold move in a plan, and make it.
- Mercury: Watch for a map, a route, a timetable, a list: the practical shape of what you want.
- Jupiter: Watch for the horizon widening: an offer, a place, an idea bigger than your usual.
- Venus: Watch for what you'd love your life to look like a year from now, and picture it in detail.
- Saturn: Watch for the one thing you'd have to give up to go further, and weigh it honestly.

Reversed
- Sun: Watch for ambition you hide because it sounds like too much.
- Moon: Watch for restlessness at home that wants a direction, not a distraction.
- Mars: Watch for impatience with your own caution, and what it's right about.
- Mercury: Watch for endless research standing in for a decision.
- Jupiter: Watch for plans so big they've stopped being plans.
- Venus: Watch for staying comfortable at the cost of something you want more.
- Saturn: Watch for fear of losing what you have, dressed up as being responsible.

### Low tide
- Notice: the small globe in his hand, and the second wand fixed to the wall behind him.
- Become: the man on the battlement. What are you looking for out there, and why haven't you gone yet?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Aries), so ambition, daring and the urge to go further are a lifelong thread for you. Answer about the bigger life you've always been planning.
- Touching you: Mars, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so drive and nerve are part of today's question. Answer about the bold step in front of you.
- Its season: The Sun is in this card's ten days of the year, about March 20 to 30, the very start of spring and of the zodiac. Answer about what you're setting out to do.
- Today's weather: {planet} {is} passing through the first ten degrees of Aries, this card's slice of the sky, so a plan wants deciding today. Answer about the step you're facing now.
- The long season: {planet} {is} moving through the first ten degrees of Aries for months or years, an era of going further than where you started. Answer about the bigger life you're slowly reaching for.
- Turning: Mars, this card's planet, is retrograde (seeming to move backward), a time when drive turns inward. Answer about which plan to rethink before you push it.

### Essence
- Upright: the world held in one hand
- Reversed: the plan that never leaves home
- Figure: the man on the battlement

---

## Three of Wands
sky: Sun in Aries, 10–20° Aries · season: about Mar 31 – Apr 9 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What have I already sent out into the world, a message, an application, an effort, and what am I watching for now?
2. Cross / boon: Is patient looking-ahead the way across, or am I watching the horizon so hard I miss the shore?
3. Root: What early venture, the first time I really put myself out there, set all of this in motion?
4. Passing away: What waiting is ending, and what did I learn about trust while I waited?
5. Front of mind: What am I deliberately looking ahead to, and what does that steady gaze make real?
6. Coming in: What returns are on their way, results, replies, ships coming in, and how will I meet them?
7. Who you are: Where am I the one standing on the cliff, seeing further than the people around me?
8. What surrounds you: Who around me is out on the water, working with me from a distance?
9. Hopes / fears: What do I hope comes sailing back to me, and what am I afraid is lost at sea?
10. Outcome: If I keep looking ahead like this, what arrives, and what would help me see further out?

### Reversed
1. Central theme: Where am I waiting on results that aren't coming, or stuck looking back at the harbor?
2. Cross / boon: Is a delay keeping the ships in port, or my reluctance to send anything out at all?
3. Root: What venture of mine never came back, and how much does it make me hesitate here?
4. Passing away: What expectation am I ready to stop waiting on?
5. Front of mind: What am I picturing so far ahead that I've lost sight of the next step?
6. Coming in: What's coming slower than I want, and what can I do while I wait?
7. Who you are: Where am I thinking too small for what I can actually see?
8. What surrounds you: Who around me isn't pulling their weight in this, and have I said so?
9. Hopes / fears: What do I picture happening if I let my plans reach as far as they want to?
10. Outcome: If I keep waiting at the harbor, where does that leave me, and what's the next ship I could send out this week?

### Watch for
Upright
- Sun: Watch for signs that your effort is reaching further than you thought.
- Moon: Watch for the calm of waiting well: a cup of something, a long look out a window.
- Mars: Watch for the next thing to send out, and send it.
- Mercury: Watch for replies, deliveries and news from far away.
- Jupiter: Watch for a chance to expand: a new market, a new place, a wider circle.
- Venus: Watch for the simple pleasure of looking forward to something.
- Saturn: Watch for the long view, what this looks like in a year, and let it steady you.

Reversed
- Sun: Watch for impatience to be recognized before the work has landed.
- Moon: Watch for anxious checking: the phone, the inbox, the tracking number.
- Mars: Watch for wanting to quit because the results are slow.
- Mercury: Watch for a message you haven't sent because of what the answer might be.
- Jupiter: Watch for reaching into more than you can follow up on.
- Venus: Watch for missing what's near because you're longing for what's far.
- Saturn: Watch for a delay that's asking you to plan better, not to give up.

### Low tide
- Notice: the ships out on the water, and that we only ever see his back.
- Become: the man on the cliff. Which of those ships is yours, and what's on it?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Aries), so foresight, venturing out and waiting for things to come back are a lifelong thread for you. Answer about what you've always sent out into the world.
- Touching you: The Sun, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so attention and energy are part of today's question. Answer about what you're sending out and where you want it seen.
- Its season: The Sun is in this card's ten days of the year, about March 31 to April 9, early spring, when the first things planted start to show. Answer about what you've already set in motion.
- Today's weather: {planet} {is} passing through the middle ten degrees of Aries, this card's slice of the sky, so something you sent out is in motion today. Answer about what you're waiting to hear back on.
- The long season: {planet} {is} moving through the middle ten degrees of Aries for months or years, an era of reaching further out. Answer about the venture slowly taking shape.

### Essence
- Upright: the ships sent out
- Reversed: the wait at the harbor
- Figure: the man on the cliff

---

## Four of Wands
sky: Venus in Aries, 20–30° Aries · season: about Apr 10 – Apr 19 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What have I reached that deserves celebrating, and have I actually celebrated it?
2. Cross / boon: Is this feeling of welcome the threshold into what's next, or am I lingering at the party when it's time to go on?
3. Root: What home, place or people first made me feel welcome, and how much of all this rests on that?
4. Passing away: What stage is complete, and how do I want to mark it before the next begins?
5. Front of mind: What am I building a sense of home around on purpose right now, and what is it making real?
6. Coming in: What gathering, homecoming or good news is on its way, and who do I want there?
7. Who you are: Where do I feel I belong in this, and what makes it feel that way?
8. What surrounds you: Who around me is part of this celebration, and what do I want to say to them?
9. Hopes / fears: What do I hope home will feel like once it's settled, and what am I afraid won't last?
10. Outcome: If I keep making room for joy like this, what does my life become, and who else would I open the gate to?

### Reversed
1. Central theme: Where am I missing a sense of belonging, or skipping the celebration because there's always more to do?
2. Cross / boon: Is tension at home what's in the way, or a milestone I won't let myself mark?
3. Root: What happened to the welcome I once felt, and does its absence shape this?
4. Passing away: What gathering or tradition has run its course, and can I let it end?
5. Front of mind: What am I postponing joy until, and is that day ever coming?
6. Coming in: What gathering is coming that will go better if I mend something at home before it?
7. Who you are: Where do I feel like a guest in my own life?
8. What surrounds you: Who around me feels left out, and could I open the gate?
9. Hopes / fears: What do I brace for if I let myself feel settled and at home?
10. Outcome: If I keep putting celebration off, what does that cost me, and what small thing could I celebrate this week?

### Watch for
Upright
- Sun: Watch for a win worth celebrating out loud, and gather someone to share it.
- Moon: Watch for the moments home feels like home, and stay in one a little longer.
- Mars: Watch for something worth protecting: the people and places that make you feel welcome.
- Mercury: Watch for good news, an invitation or a toast, and add your own words.
- Jupiter: Watch for a chance to host: a meal, a door left open, room made for someone.
- Venus: Watch for flowers, music, small decorations: the beauty of people gathered.
- Saturn: Watch for the foundation under today's ease, and thank whoever helped build it.

Reversed
- Sun: Watch for waiting to celebrate until it's perfect.
- Moon: Watch for unease at home, and what would help everyone settle.
- Mars: Watch for friction at a gathering, and whether it's worth the fight.
- Mercury: Watch for unspoken tension in a household or a group chat.
- Jupiter: Watch for celebrating so hard that it becomes a way to avoid something.
- Venus: Watch for feeling on the outside of a happy scene, and whether you'd be welcome in.
- Saturn: Watch for a milestone you passed without noticing.

### Low tide
- Notice: the garland of flowers and fruit tied between the four wands, and the two figures raising bouquets.
- Become: one of the figures holding up flowers. Who are you welcoming home?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Aries), so celebration, belonging and making a home are a lifelong thread for you. Answer about where you've always felt welcome.
- Touching you: Venus, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so love, pleasure or what you value is part of today's question. Answer about who and what makes you feel at home.
- Its season: The Sun is in this card's ten days of the year, about April 10 to 19, mid-spring, when everything is in blossom. Answer about what's ready to be celebrated.
- Today's weather: {planet} {is} passing through the last ten degrees of Aries, this card's slice of the sky, so home, welcome or a milestone is in play today. Answer about the one in front of you.
- The long season: {planet} {is} moving through the last ten degrees of Aries for months or years, an era of making a home and marking what you've reached. Answer about the place you're slowly making for yourself.
- Turning: Venus, this card's planet, is retrograde (seeming to move backward), a review of love, home and what you value. Answer about a welcome you'd like to give or receive again.

### Essence
- Upright: the welcome home
- Reversed: the celebration put off
- Figure: a figure holding up flowers

---

## Five of Wands
sky: Saturn in Leo, 0–10° Leo · season: about Jul 23 – Aug 1 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: Where am I in the middle of a scuffle right now, and what is everyone actually fighting about?
2. Cross / boon: Is this friction sharpening me for what's next, or am I spending all my energy just holding my place in the crowd?
3. Root: What early rivalry or crowded household taught me how to compete, and did I learn to win or to duck?
4. Passing away: What competition or conflict is winding down, and what did I learn from sparring?
5. Front of mind: What am I deliberately pushing for among everyone else's agendas, and what is that push making real?
6. Coming in: What challenge or lively disagreement is on its way, and how do I want to show up for it?
7. Who you are: Where am I scrapping for room in this, and do I enjoy it more than I admit?
8. What surrounds you: Who around me is pushing against me, and are we really on opposite sides?
9. Hopes / fears: What am I hoping to prove in this scuffle, and what am I afraid I'll lose if I don't?
10. Outcome: If this stays a free-for-all, where does it go, and what would turn five wands waving into one thing we build together?

### Reversed
1. Central theme: Where am I avoiding a disagreement that needs to happen, or stuck in one that should have ended?
2. Cross / boon: Is my dislike of conflict keeping this stuck, or a fight that's become a habit?
3. Root: What old argument still echoes underneath this one?
4. Passing away: What rivalry am I ready to put down?
5. Front of mind: What argument am I having in my head with someone who isn't here?
6. Coming in: Which argument is heading my way where staying quiet would cost more than joining in?
7. Who you are: Where am I keeping the peace at the cost of my own voice?
8. What surrounds you: Who around me thrives on friction, and how much of it lands on me?
9. Hopes / fears: What do I picture happening if I said "I disagree" out loud?
10. Outcome: If I keep dodging, or keep fighting, where does that leave me, and what's the real issue under all the noise?

### Watch for
Upright
- Sun: Watch for a chance to compete openly, and enjoy it.
- Moon: Watch for tension at home, and whether it's play or a real hurt.
- Mars: Watch for a good argument, one that sharpens everyone, and join it fairly.
- Mercury: Watch for crossed talk, everyone speaking and no one listening, and be the one who listens.
- Jupiter: Watch for the bigger goal everyone in the scuffle actually shares.
- Venus: Watch for a way to turn rivalry into play.
- Saturn: Watch for the rules of the game, what's fair and what's not, and say them plainly.

Reversed
- Sun: Watch for the urge to be the last one standing, and what you'd trade to get there.
- Moon: Watch for tension in your body after a disagreement, and let it out somewhere safe.
- Mars: Watch for picking a fight to burn off something else.
- Mercury: Watch for arguments over small things standing in for a big one.
- Jupiter: Watch for taking sides in a fight that isn't yours.
- Venus: Watch for swallowing a disagreement to keep things pleasant.
- Saturn: Watch for an old grudge setting the terms of a new conversation.

### Low tide
- Notice: that the five young men's wands never quite strike anyone, and that each of them is dressed differently.
- Become: one of the five. What are you fighting about, and is anyone winning?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Leo), so competition, finding your place among others and standing up for yourself are a lifelong thread for you. Answer about how you've learned to hold your own.
- Touching you: Saturn, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so effort, limits and the long haul are part of today's question. Answer about what it's taking to keep your place.
- Its season: The Sun is in this card's ten days of the year, about July 23 to August 1, the start of high summer, when the heat makes everyone a little short-tempered. Answer about the friction you're in.
- Today's weather: {planet} {is} passing through the first ten degrees of Leo, this card's slice of the sky, so friction or a contest is live today. Answer about the scuffle you're in now.
- The long season: {planet} {is} moving through the first ten degrees of Leo for months or years, an era of competing for room. Answer about the long contest that's shaping you.
- Turning: Saturn, this card's planet, is retrograde (seeming to move backward), a time to review the rules you're playing by. Answer about a struggle worth rethinking.

### Essence
- Upright: the free-for-all
- Reversed: the fight dodged, or kept going
- Figure: one of the five

---

## Six of Wands
sky: Jupiter in Leo, 10–20° Leo · season: about Aug 2 – Aug 11 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What have I done lately that went well enough to be seen, and how does it feel to be recognized for it?
2. Cross / boon: Is this win carrying me into what's next, or am I so pleased with the parade that I've stopped riding?
3. Root: What was the first win I got to enjoy in front of other people, and who was cheering?
4. Passing away: What victory is behind me now, and what do I want to carry from it into what's next?
5. Front of mind: What success am I deliberately working toward, and what does picturing it make real?
6. Coming in: What recognition or good news is on its way, and how do I want to receive it?
7. Who you are: Where am I the one riding in front, and how do I feel about being looked at?
8. What surrounds you: Who around me helped me win this, and have they been seen too?
9. Hopes / fears: Whose cheering do I most hope to hear, and whose silence am I afraid of?
10. Outcome: If I keep riding this way, where does the road lead, and what would help me wear the laurels lightly?

### Reversed
1. Central theme: Where do I feel unrecognized right now, or where is the need for praise doing the steering?
2. Cross / boon: Is a fear of being seen keeping me off the horse, or the opposite: needing an audience to move at all?
3. Root: What time I wasn't celebrated still stings, and is it shaping this?
4. Passing away: What old win am I still riding on, and is it time to get down?
5. Front of mind: What am I doing for applause rather than because I want to?
6. Coming in: What's coming that will test whether I can succeed quietly, or fall short gracefully?
7. Who you are: Where am I shrinking from praise I actually earned?
8. What surrounds you: Who around me is quick to cheer and quick to turn, and how much do I lean on them?
9. Hopes / fears: What would people think if I fell off the horse in front of them, and would it matter in a year?
10. Outcome: If I keep chasing approval, where does it lead, and what would "well done" mean if only I were judging?

### Watch for
Upright
- Sun: Watch for being recognized today, and say thank you without brushing it off.
- Moon: Watch for the quiet pride in your body after something goes well.
- Mars: Watch for momentum from a recent win, and use it.
- Mercury: Watch for good news traveling, and help spread someone else's.
- Jupiter: Watch for a chance to share the credit generously.
- Venus: Watch for admiration, given or received, and let it be warm.
- Saturn: Watch for the long effort behind today's success, and name it.

Reversed
- Sun: Watch for hungry checking: likes, replies, who noticed.
- Moon: Watch for feeling invisible, and what you'd want to be seen for.
- Mars: Watch for swagger after a small win.
- Mercury: Watch for talking your success up, or talking it down.
- Jupiter: Watch for overpromising to keep people impressed.
- Venus: Watch for liking someone mostly because they like you.
- Saturn: Watch for a setback you're taking as a verdict on your worth.

### Low tide
- Notice: the laurel wreath on his head and the second one tied to his wand, and the people with wands walking beside him.
- Become: one of the people walking beside the horse. How do you feel about the man riding above you?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Leo), so recognition, confidence and succeeding in front of others are a lifelong thread for you. Answer about what you've always wanted to be known for.
- Touching you: Jupiter, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so growth and good fortune are part of today's question. Answer about where you're ready to be seen succeeding.
- Its season: The Sun is in this card's ten days of the year, about August 2 to 11, midsummer at its brightest. Answer about what's going well and deserves notice.
- Today's weather: {planet} {is} passing through the middle ten degrees of Leo, this card's slice of the sky, so being seen is in play today. Answer about a win, or a wish to be noticed, happening now.
- The long season: {planet} {is} moving through the middle ten degrees of Leo for months or years, an era of learning to carry success. Answer about the confidence slowly building in you.
- Turning: Jupiter, this card's planet, is retrograde (seeming to move backward), a time when growth turns inward. Answer about the success that matters to you even when no one is watching.

### Essence
- Upright: the win that gets seen
- Reversed: the hunger for applause
- Figure: a walker beside the horse

---

## Seven of Wands
sky: Mars in Leo, 20–30° Leo · season: about Aug 12 – Aug 22 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What am I standing up for right now, and what's coming at me from below?
2. Cross / boon: Is holding this ground what gets me through, or am I so busy defending that I've stopped moving?
3. Root: When did I first stand up for myself, and what happened next?
4. Passing away: What fight to keep my place is ending, and what did it show me about my nerve?
5. Front of mind: What position am I deliberately defending, and what does defending it make real?
6. Coming in: What challenge to my position is on its way, and what do I want to be sure of before it gets here?
7. Who you are: Where am I holding the high ground in this, and did I earn it or just get there first?
8. What surrounds you: Who around me is pushing up against me, and how many of them are really there?
9. Hopes / fears: What do I hope I can keep hold of up here, and what am I afraid they'll take?
10. Outcome: If I keep standing here like this, how long can I last, and which ground is truly worth holding?

### Reversed
1. Central theme: Where am I tired of defending myself, or giving up ground I don't need to give?
2. Cross / boon: Is exhaustion what's stopping me, or a fight I keep having that no one else is in anymore?
3. Root: When did I decide I'd always have to fight for my place, and is that still true?
4. Passing away: What position am I ready to stop defending?
5. Front of mind: What attack am I bracing for in my head that hasn't come?
6. Coming in: Who is climbing the hill toward me next, and do I have the strength to hold my ground today?
7. Who you are: Where do I back down too quickly?
8. What surrounds you: Who around me makes me feel I'm always on trial?
9. Hopes / fears: What do I picture happening if I stopped swinging and let them come up the hill?
10. Outcome: If I keep fighting on every side, what's left of me, and which one battle would I keep?

### Watch for
Upright
- Sun: Watch for a moment to stand openly by what you believe.
- Moon: Watch for what you protect at home, and how fiercely.
- Mars: Watch for a challenge worth meeting head-on, and meet it.
- Mercury: Watch for pushback you can answer calmly and clearly.
- Jupiter: Watch for a cause bigger than yourself that you'd stand up for.
- Venus: Watch for the people and things you love enough to defend.
- Saturn: Watch for the stamina it takes to hold a line for the long haul.

Reversed
- Sun: Watch for defending your image more than your values.
- Moon: Watch for feeling under attack when you're really just tired.
- Mars: Watch for overreacting to small challenges.
- Mercury: Watch for over-explaining yourself to people who aren't listening.
- Jupiter: Watch for fighting battles that aren't yours.
- Venus: Watch for giving in to keep someone's affection.
- Saturn: Watch for a stubbornness that's outlived its reason.

### Low tide
- Notice: his mismatched shoes, one boot and one shoe, and that we never see who's holding the wands below.
- Become: the man on the hill. What are you defending up here, and how did you end up alone with it?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Leo), so courage under pressure and defending what's yours are a lifelong thread for you. Answer about the ground you've always stood on.
- Touching you: Mars, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so drive, nerve and conflict are part of today's question. Answer about what you're ready to defend.
- Its season: The Sun is in this card's ten days of the year, about August 12 to 22, the last hot stretch of summer. Answer about what you're holding onto.
- Today's weather: {planet} {is} passing through the last ten degrees of Leo, this card's slice of the sky, so something is pushing against your position today. Answer about the challenge in front of you.
- The long season: {planet} {is} moving through the last ten degrees of Leo for months or years, an era of deciding what ground to hold. Answer about the position you're slowly learning to keep, or to give up.
- Turning: Mars, this card's planet, is retrograde (seeming to move backward), a time to revisit old fights. Answer about which ground is still worth holding.

### Essence
- Upright: the high ground held
- Reversed: the defense worn thin
- Figure: the man on the hill
