# Batch 5: Wands, Eight to King

Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position), 14 watch-for
cues (one per day ruler, each orientation), a low-tide pointer, its lit lines, and its essence
(a short phrase per orientation for the pair prompts, and a figure for "Where have you been ___
lately?").

Written in the card-specific style from here on: no stock openings repeated across cards. Each
position still does its job (Cross / boon can block or help, Root talks to Who you are, Hopes /
fears holds both, Outcome ends with a lever), but in the card's own words.

The Eight, Nine and Ten each hold ten degrees of Sagittarius. The Page shares the fire quarter
of the year with the Ace. The Knight, Queen and King each hold a 30° stretch across two signs.

---

## Eight of Wands
sky: Mercury in Sagittarius, 0–10° Sagittarius · season: about Nov 22 – Dec 1 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What started moving fast lately, a plan, a message, a feeling, and where does it look like it's going to land?
2. Cross / boon: This rush of speed: is it the quick passage from what's ending to what's beginning, or is it carrying me past a turn I needed to take?
3. Root: What decision, made a while back, set all these things flying?
4. Passing away: What waiting game is over now that things are moving, and what did the stillness give me?
5. Front of mind: Where am I aiming my energy on purpose right now, and how fast do I want it to arrive?
6. Coming in: What news, message or sudden progress is about to land, and where do I want to be standing when it does?
7. Who you are: Where am I already in motion in this, quicker than I expected to be?
8. What surrounds you: Whose messages, plans or deadlines are flying around me, and which ones are actually mine to catch?
9. Hopes / fears: What do I hope arrives quickly, and what am I afraid will land before I'm ready?
10. Outcome: Where does this momentum set me down, and what would I aim differently now, in my thinking or in my hopes, to change where it lands?

### Reversed
1. Central theme: What's stalled in midair, or racing ahead faster than I can follow?
2. Cross / boon: Is the delay what stands in the doorway right now, or is it my own hurry tripping me?
3. Root: What earlier rush, a decision made too fast, still has things scattering?
4. Passing away: What frantic pace am I ready to let slow down?
5. Front of mind: What message have I written in my head a dozen times and still not sent?
6. Coming in: What's arriving later than I hoped, and what is the delay giving me room to do?
7. Who you are: Where am I scattered across too many things at once?
8. What surrounds you: Who around me keeps changing the plan, and how much of my speed is a reaction to theirs?
9. Hopes / fears: If everything suddenly landed at once, what part of me would rather it stayed up in the air?
10. Outcome: If everything stays up in the air, what happens to it, and what do I need to decide, or stop worrying about, to bring one thing down to earth?

### Watch for
Upright
- Sun: Watch for things moving in your favor faster than you expected, and let yourself enjoy the speed.
- Moon: Watch for a quick change of mood, and let it pass through without chasing it.
- Mars: Watch for the moment to act fast, and act before it's gone.
- Mercury: Watch for messages arriving in a cluster, and answer the one that matters most first.
- Jupiter: Watch for travel plans, news from far away, or an idea that suddenly opens wide.
- Venus: Watch for a message from someone you care about, and reply warmly.
- Saturn: Watch for the one thing in motion that needs a firm place to land.

Reversed
- Sun: Watch for rushing so you look busy.
- Moon: Watch for jittery energy, and give it somewhere to go: a walk, a stretch.
- Mars: Watch for hasty replies sent in heat.
- Mercury: Watch for crossed messages, missed calls and things sent to the wrong place.
- Jupiter: Watch for saying yes to too many things at once.
- Venus: Watch for waiting on someone's reply and reading too much into the silence.
- Saturn: Watch for a delay you can't speed up, and what it's asking you to finish first.

### Low tide
- Notice: that there are no people in this card, only the wands in flight, and the small house on the hill below them.
- Become: one of the wands in the air. Who threw you, and where are you about to land?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Sagittarius), so speed, news and things suddenly moving are a lifelong thread for you. Answer about how things tend to arrive in your life: all at once.
- Touching you: Mercury, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so messages, plans and quick decisions are part of today's question. Answer about what you need to send or say.
- Its season: The Sun is in this card's ten days of the year, about November 22 to December 1, when travel and messages pick up before the year's end. Answer about what's suddenly moving.
- Today's weather: {planet} {is} passing through the first ten degrees of Sagittarius, this card's slice of the sky, so things are moving quickly today. Answer about the message or the change in motion now.
- The long season: {planet} {is} moving through the first ten degrees of Sagittarius for months or years, an era when things move faster than you can plan. Answer about what's been gathering speed in your life.
- Turning: Mercury, this card's planet, is retrograde (seeming to move backward), as it is about three times a year for three weeks, a time when messages cross and plans stall. Answer about what to resend, recheck or let wait.

### Essence
- Upright: everything in flight at once
- Reversed: the message stuck in midair
- Figure: a wand in flight

---

## Nine of Wands
sky: Moon in Sagittarius, 10–20° Sagittarius · season: about Dec 2 – Dec 11 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What have I been through that's left me a bit bandaged, and what am I still standing guard over?
2. Cross / boon: Is my staying power what gets me across, or is my guard so high that nothing new can get past it?
3. Root: What old hurt taught me to watch my back, and how much of who I am in this comes from it?
4. Passing away: What long stretch of holding on is nearly over, and what did I learn about my own endurance?
5. Front of mind: What am I deliberately keeping going, one more day, and what is that persistence building?
6. Coming in: What last test is coming, and what do I have left in me to meet it?
7. Who you are: Where am I tougher than I feel, and where am I simply tired?
8. What surrounds you: Who around me has been through the same fight, and could we lean on each other?
9. Hopes / fears: What do I hope I'll finally be able to set down, and what am I braced for coming over the hill?
10. Outcome: If I hold on like this to the end, what's left standing, and what would I stop expecting, or start trusting, to make the last stretch lighter?

### Reversed
1. Central theme: Where have I been on guard so long I've forgotten what I'm protecting?
2. Cross / boon: Is suspicion what's in the way now, or am I just too worn down to cross?
3. Root: What hurt from long ago makes me expect the next blow before it comes?
4. Passing away: What defense am I ready to lower, now that the danger has passed?
5. Front of mind: What threat am I watching for in my head that isn't really there?
6. Coming in: What's coming that I could meet with an open hand instead of a raised stick?
7. Who you are: Where am I running on empty and calling it strength?
8. What surrounds you: Who around me keeps testing my limits, and have I told them where they are?
9. Hopes / fears: What would it mean to admit I can't keep going like this?
10. Outcome: If I keep bracing for the next attack, what happens to me, and what fear or expectation would I set down first so I can rest?

### Watch for
Upright
- Sun: Watch for a moment to be proud of how far you've come, scars and all.
- Moon: Watch for tiredness, and give your body one real rest today.
- Mars: Watch for one more round you have in you, and whether it's worth spending today.
- Mercury: Watch for a check-in from someone who's been through it too.
- Jupiter: Watch for help offered, and let yourself take it.
- Venus: Watch for the small comforts that make a long haul bearable.
- Saturn: Watch for proof that persistence is working, even slowly.

Reversed
- Sun: Watch for defending your position just to prove you can.
- Moon: Watch for jumping at small things, and what would help you feel safe.
- Mars: Watch for bristling at people who mean no harm.
- Mercury: Watch for reading every message as a criticism.
- Jupiter: Watch for refusing help because accepting it feels like losing.
- Venus: Watch for keeping someone at arm's length out of old habit.
- Saturn: Watch for endurance that has turned into a cage.

### Low tide
- Notice: the bandage around his head, and the eight wands standing behind him like a fence.
- Become: the man leaning on his wand. What happened just before this, and who are you watching for?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Sagittarius), so resilience, guarding what you've won and keeping going are a lifelong thread for you. Answer about what you've come through.
- Touching you: The Moon, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few hours, so your feelings about what you've been through are near the surface. Answer about how tired, or how strong, you really feel.
- Its season: The Sun is in this card's ten days of the year, about December 2 to 11, early winter's dark coming on, with the year's end in sight. Answer about what you're holding on through.
- Today's weather: {planet} {is} passing through the middle ten degrees of Sagittarius, this card's slice of the sky, so your guard is up today. Answer about what you're protecting now.
- The long season: {planet} {is} moving through the middle ten degrees of Sagittarius for months or years, an era of endurance. Answer about what you've been holding on to, and why.

### Essence
- Upright: the last stand, bandaged and upright
- Reversed: the guard that never comes down
- Figure: the man with the bandage

---

## Ten of Wands
sky: Saturn in Sagittarius, 20–30° Sagittarius · season: about Dec 12 – Dec 21 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What am I carrying right now, if I list every piece of it, and which of them did I actually agree to?
2. Cross / boon: This load: is it what gets me from the old place to the new one, or is it the thing that keeps me from seeing where I'm walking?
3. Root: When did I first take on more than my share, and who was I trying to help?
4. Passing away: What responsibility is finally coming off my back, and what did carrying it teach me?
5. Front of mind: What am I deliberately pushing through to finish, and is the finish worth the weight?
6. Coming in: What new bundle is about to be handed to me, and what could I set down first to make room?
7. Who you are: Where am I the one everyone hands things to, and how does that feel tonight?
8. What surrounds you: Who around me keeps adding to the pile, and who would help carry it if I asked?
9. Hopes / fears: What do I hope will happen when I finally set it all down, and what am I afraid I'll be without it?
10. Outcome: If I carry all of this to the end, what does it cost me, and which piece, or which belief about having to carry it, would I put down to arrive with something left?

### Reversed
1. Central theme: What am I still carrying that isn't mine, or what have I dropped that I'm worried about?
2. Cross / boon: Is the weight what's in the doorway, or my refusal to put any of it down?
3. Root: Who taught me that resting means letting people down?
4. Passing away: What burden am I ready to set down for good?
5. Front of mind: What task keeps circling my mind at night without my doing it?
6. Coming in: What's coming that will finally push me to hand something off, or to say no?
7. Who you are: Where have I buckled under too much, and what's the first thing to pick back up, if anything?
8. What surrounds you: Who around me is overloaded, and is some of their load mine?
9. Hopes / fears: What do I dread people will think if I stop carrying it all?
10. Outcome: If nothing comes off the pile, where do I break, and what would I stop believing about my duty to make the load lighter?

### Watch for
Upright
- Sun: Watch for the work you're proud to carry, and the work you're only carrying to be seen.
- Moon: Watch for your shoulders, jaw and back, and what they're holding for you.
- Mars: Watch for the final stretch of something heavy, and finish it.
- Mercury: Watch for a task you could hand off with one message.
- Jupiter: Watch for taking on one more thing out of generosity, and decide whether you can.
- Venus: Watch for a small pleasure along the way, so the walk isn't only weight.
- Saturn: Watch for the duty that matters most, and let the rest wait.

Reversed
- Sun: Watch for making sure everyone sees how much you carry.
- Moon: Watch for exhaustion that's past the point where rest is optional.
- Mars: Watch for snapping under pressure, and what you could put down instead.
- Mercury: Watch for a to-do list that has turned into a scold.
- Jupiter: Watch for promising more than you can deliver.
- Venus: Watch for having no time left for anything you enjoy.
- Saturn: Watch for carrying a duty that someone else is waiting to take back.

### Low tide
- Notice: that his face is hidden behind the bundle, and the house he's walking toward.
- Become: the man with the bundle. How far is it to the house, and why carry them all at once?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Sagittarius), so responsibility, carrying the load and finishing what you started are a lifelong thread for you. Answer about what you've always ended up carrying.
- Touching you: Saturn, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so duty, limits and the long haul are part of today's question. Answer about what you're carrying and whether it's all yours.
- Its season: The Sun is in this card's ten days of the year, about December 12 to 21, the last days before the longest night, when the year's work piles up. Answer about what you're carrying into the end of the year.
- Today's weather: {planet} {is} passing through the last ten degrees of Sagittarius, this card's slice of the sky, so the load feels heavier today. Answer about the one task weighing most right now.
- The long season: {planet} {is} moving through the last ten degrees of Sagittarius for months or years, an era of heavy responsibility. Answer about what you've been carrying for a long time.
- Turning: Saturn, this card's planet, is retrograde (seeming to move backward), as it is for about four and a half months each year, a time to look again at old commitments. Answer about which part of the load to set down.

### Essence
- Upright: the whole load carried home
- Reversed: the load that won't come off
- Figure: the man with the bundle

---

## Page of Wands
sky: the fire quarter of the year, Cancer through Virgo · season: about Jun 21 – Sep 22 · lit by: Its season

### Upright
1. Central theme: What new interest has grabbed me lately, and what first made me curious about it?
2. Cross / boon: Is this beginner's excitement what gets me from the old thing to the new one, or am I trying things on without ever committing?
3. Root: What was the first thing I fell in love with exploring, and how much of me in this still carries it?
4. Passing away: What phase of trying things out is ending, and which one thing do I want to keep?
5. Front of mind: What am I eager to learn on purpose right now, and what's the first thing I'd try?
6. Coming in: What news, invitation or new idea is arriving, and how do I want to answer it?
7. Who you are: Where am I the eager beginner in this, and do I let myself enjoy it?
8. What surrounds you: Who around me is full of fresh energy, and what could I catch from them?
9. Hopes / fears: What do I hope this new passion turns into, and what am I afraid will happen if it fizzles?
10. Outcome: If I follow this curiosity, where does it take me, and what would I need to believe about myself to follow it further?

### Reversed
1. Central theme: Where have I lost my curiosity, or started so many things that none of them stick?
2. Cross / boon: Is restlessness what's in the way, or the fear of looking like a beginner?
3. Root: What early excitement of mine was laughed off or shut down?
4. Passing away: What half-started project am I ready to let go of, without guilt?
5. Front of mind: What idea am I excited about that I keep not starting?
6. Coming in: What's coming that could spark me again, if I let it?
7. Who you are: Where am I acting out, or sulking, because I'm bored?
8. What surrounds you: Who around me is impatient with my enthusiasm, or am I impatient with theirs?
9. Hopes / fears: If I gave this everything and turned out to be ordinary at it, could I still love doing it?
10. Outcome: If I keep flitting, or keep holding back, where does that leave me, and which one idea would I commit to so the spark can catch?

### Watch for
Upright
- Sun: Watch for something that makes you light up like a kid, and let it show.
- Moon: Watch for what your body wants to explore: a new walk, a new food, a new texture.
- Mars: Watch for a dare you'd actually like to take.
- Mercury: Watch for news, a message or an invitation with a spark in it.
- Jupiter: Watch for a subject you'd love to learn more about, and look one thing up.
- Venus: Watch for a crush, on a person, a place or a craft, and enjoy it.
- Saturn: Watch for the small, steady practice that would turn a spark into a skill.

Reversed
- Sun: Watch for showing off to cover not knowing.
- Moon: Watch for boredom that's really tiredness.
- Mars: Watch for impatience with learning curves.
- Mercury: Watch for news you misread because you were rushing.
- Jupiter: Watch for buying the gear before doing the thing.
- Venus: Watch for chasing something new just because it's new.
- Saturn: Watch for "I'm too old to start that," and question it.

### Low tide
- Notice: the salamanders on his tunic, and how intently he looks up at the top of his wand.
- Become: the page. What news are you carrying, and who is it for?

### Lit
- Its season: The Sun is in this card's quarter of the year, Cancer through Virgo, about June 21 to September 22: summer, the season of fire. Answer about something you'd like to explore while the days are long.

### Essence
- Upright: the eager first look
- Reversed: the spark that won't settle
- Figure: the page

---

## Knight of Wands
sky: 20° Scorpio to 20° Sagittarius (the fiery part of Fire) · season: about Nov 12 – Dec 11 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: Where am I charging ahead right now, and what lit the fire under me?
2. Cross / boon: Is this burst of daring what gets me across, or am I riding so fast I'll overshoot the bridge?
3. Root: What first made me want to go, to leave, to move, and how much of all this rides on that?
4. Passing away: What adventure is ending, and what did the ride teach me about my own fire?
5. Front of mind: What am I chasing on purpose right now, and how much of it is the destination and how much the thrill?
6. Coming in: What adventure, move or burst of passion is galloping toward me, and am I ready to get on?
7. Who you are: Where am I the one who acts first and thinks later, and when does that serve me?
8. What surrounds you: Who around me is restless and on the move, and are they pulling me along?
9. Hopes / fears: What do I hope this adventure will prove, and what am I afraid of missing if I stay put?
10. Outcome: If I keep riding at this speed, where do I end up, and what would I slow down, or aim differently, to arrive somewhere I want to be?

### Reversed
1. Central theme: Where am I rushing without a plan, or stuck when I'm aching to move?
2. Cross / boon: Is my impatience what's in the way, or is something holding back the horse?
3. Root: What restlessness has followed me since I was young?
4. Passing away: What reckless habit am I ready to rein in?
5. Front of mind: What am I daydreaming about doing instead of doing?
6. Coming in: What's coming that will tempt me to bolt, and what would I leave behind if I did?
7. Who you are: Where do my temper or my hurry get ahead of me?
8. What surrounds you: Who around me burns hot and fast, and leaves me to clean up?
9. Hopes / fears: What do I dread about sitting still?
10. Outcome: If I keep starting and abandoning, where does it lead, and what would I need to stay with long enough to finish?

### Watch for
Upright
- Sun: Watch for a bold move you can make in full view.
- Moon: Watch for restlessness in your body, and give it a real outlet.
- Mars: Watch for the moment to go, and go.
- Mercury: Watch for a spontaneous plan, a call, a trip, an idea you could act on today.
- Jupiter: Watch for a chance at an adventure, however small.
- Venus: Watch for passion, and where it wants to take you.
- Saturn: Watch for the one bit of planning that would keep the adventure safe.

Reversed
- Sun: Watch for bravado that's covering doubt.
- Moon: Watch for agitation with nowhere to go, and find it a safe place to burn off.
- Mars: Watch for a temper that flares before you've listened.
- Mercury: Watch for plans made and dropped in the same breath.
- Jupiter: Watch for overcommitting in a burst of enthusiasm.
- Venus: Watch for chasing a rush instead of a person.
- Saturn: Watch for frustration with limits that are actually keeping you safe.

### Low tide
- Notice: the horse rearing up, and the pyramids far off in the desert behind them.
- Become: the horse. Where do you want to go, and does the knight agree?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Scorpio to 20° Sagittarius), so daring, restlessness and acting on passion are a lifelong thread for you. Answer about where your fire has carried you.
- Its season: The Sun is in this card's stretch of the year, about November 12 to December 11, late fall, when the year races toward its end. Answer about what you're rushing toward.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Scorpio into Sagittarius, so the urge to act is strong today. Answer about the move you want to make now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Scorpio into Sagittarius, for months or years, an era of restlessness and leaps. Answer about where you've been longing to go.

### Essence
- Upright: the charge forward
- Reversed: the ride with no road
- Figure: the rearing horse

---

## Queen of Wands
sky: 20° Pisces to 20° Aries (the watery part of Fire) · season: about Mar 10 – Apr 9 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: Where am I most sure of myself right now, and what does that confidence let me do?
2. Cross / boon: Is my warmth what gets people, and me, across, or am I holding court when it's time to move?
3. Root: Who first showed me what warm, bold confidence looks like, and what of theirs do I carry?
4. Passing away: What season of shining is giving way to something quieter, and what will I keep from it?
5. Front of mind: What am I deliberately drawing toward me with my energy right now?
6. Coming in: What invitation, attention or chance to lead warmly is arriving, and how do I want to show up?
7. Who you are: Where am I at home in my own power in this?
8. What surrounds you: Who around me is drawn to my warmth, and who needs some of it right now?
9. Hopes / fears: What do I hope people see when they look at me, and what am I afraid they'll find underneath?
10. Outcome: If I keep shining like this, who gathers around me, and what would I need to believe about myself to shine without burning out?

### Reversed
1. Central theme: Where has my confidence dimmed, or turned into needing everyone's attention?
2. Cross / boon: Is jealousy, mine or someone else's, what's in the way?
3. Root: What taught me that being bold would cost me love?
4. Passing away: What role as the bright one am I ready to retire?
5. Front of mind: Who am I comparing myself to in my head, and what does it cost me?
6. Coming in: Where is a room opening up that's waiting for me to walk in and take my seat?
7. Who you are: Where am I demanding, or shrinking, instead of simply being warm?
8. What surrounds you: Who around me is threatened by my light, and do I dim it before they can be?
9. Hopes / fears: If people saw the whole fire, temper and all, what am I afraid they'd stop loving?
10. Outcome: If the fire stays this low, or this wild, where does it lead, and what one thing would I stop doing to get my warmth back?

### Watch for
Upright
- Sun: Watch for a moment to walk into a room like you belong there.
- Moon: Watch for your instincts, the cat at your feet, and trust one today.
- Mars: Watch for a chance to stand up for someone with warmth and fire.
- Mercury: Watch for a conversation you can lead with charm and directness.
- Jupiter: Watch for a chance to encourage someone, generously and out loud.
- Venus: Watch for what makes you feel magnetic: a color, a scent, a way of standing.
- Saturn: Watch for the discipline that lets your warmth last.

Reversed
- Sun: Watch for needing to be the center of every room.
- Moon: Watch for moodiness that wants attention more than help.
- Mars: Watch for a sharp tongue when you feel overlooked.
- Mercury: Watch for gossip or comparison that cools your own fire.
- Jupiter: Watch for spreading yourself thin to keep everyone impressed.
- Venus: Watch for jealousy, and what it says you want.
- Saturn: Watch for hiding your spark to stay out of trouble.

### Low tide
- Notice: the sunflower in her hand, and the black cat sitting at her feet.
- Become: the black cat. What do you know about her that the rest of the court doesn't?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Pisces to 20° Aries), so warmth, confidence and a magnetic presence are a lifelong thread for you. Answer about the way you light up a room.
- Its season: The Sun is in this card's stretch of the year, about March 10 to April 9, the turn from winter into spring. Answer about the confidence coming back with the light.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Pisces into Aries, so your presence counts for something today. Answer about where you want to show up warmly now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Pisces into Aries, for months or years, an era of growing into your own confidence. Answer about the presence you're slowly claiming.

### Essence
- Upright: the warm, sure presence
- Reversed: the fire dimmed, or flaring
- Figure: the black cat

---

## King of Wands
sky: 20° Cancer to 20° Leo (the airy part of Fire) · season: about Jul 12 – Aug 11 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What vision am I leading with right now, and who is following it?
2. Cross / boon: Is my leadership what takes everyone across, or am I so far ahead that no one is crossing with me?
3. Root: What first made me believe I could lead something of my own, and what's still standing from that belief?
4. Passing away: What venture or role I led is finishing, and what kind of leader did it make me?
5. Front of mind: What big picture am I deliberately holding in view, and what am I building toward?
6. Coming in: What chance to lead, or to start something of my own, is arriving, and how do I want to meet it?
7. Who you are: Where am I the one with the vision in this, and do I own it?
8. What surrounds you: Who around me is ready to be inspired, and what would I tell them?
9. Hopes / fears: What do I hope my vision will build, and what am I afraid of failing at in front of everyone?
10. Outcome: If I keep leading this way, what does it grow into, and what would I change in my thinking, or in my hopes for it, to lead more freely?

### Reversed
1. Central theme: Where is my vision running everyone ragged, or where have I stopped believing in it?
2. Cross / boon: Is my impatience with others what's in the way, or my fear of taking the lead?
3. Root: What leader in my past made bold look like bullying?
4. Passing away: What throne have I sat on long enough, and who could take it next?
5. Front of mind: What vision am I holding so tightly that no one else can touch it?
6. Coming in: Whose turn to lead is coming, and can I hand over the scepter without sulking?
7. Who you are: Where am I expecting too much of people, or of myself?
8. What surrounds you: Who around me is waiting for direction I haven't given?
9. Hopes / fears: Who would I be if I weren't the one with the vision, just one of the crew?
10. Outcome: If I keep driving it alone, what burns out, and what would I stop controlling so others can carry the fire too?

### Watch for
Upright
- Sun: Watch for a chance to lead from the front, and do it generously.
- Moon: Watch for what makes your home a place people want to gather.
- Mars: Watch for a bold decision only you can make.
- Mercury: Watch for the words that would make someone believe in the plan.
- Jupiter: Watch for the bigger vision behind today's task, and say it out loud.
- Venus: Watch for someone's talent you can champion.
- Saturn: Watch for the structure your vision needs to last.

Reversed
- Sun: Watch for taking credit that belongs to the team.
- Moon: Watch for irritability when things don't go your way.
- Mars: Watch for steamrolling people who move slower than you.
- Mercury: Watch for big talk with no plan behind it.
- Jupiter: Watch for a vision bigger than the means to reach it.
- Venus: Watch for charm used to get people to go along.
- Saturn: Watch for control dressed up as high standards.

### Low tide
- Notice: the small salamander on the ground at his feet, and the way he leans forward as if about to stand.
- Become: the salamander at his feet. What does he look like from down here, and where is he about to go?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Cancer to 20° Leo), so vision, leadership and starting things of your own are a lifelong thread for you. Answer about what you've always wanted to build and lead.
- Its season: The Sun is in this card's stretch of the year, about July 12 to August 11, high summer, the brightest stretch of the year. Answer about the vision you want to put into action.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Cancer into Leo, so leadership is live today. Answer about a decision only you can make now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Cancer into Leo, for months or years, an era of stepping into leadership. Answer about the vision you're slowly growing into.

### Essence
- Upright: the vision that leads
- Reversed: the vision that runs everyone over
- Figure: the king about to stand
