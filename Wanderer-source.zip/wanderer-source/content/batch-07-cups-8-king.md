# Batch 7: Cups, Eight to King

Each card: 20 questions, 14 watch-for cues, a low-tide pointer, its lit lines and its essence.
Written in the card-specific style (no stock openings; see the foundation's style rules).

The Eight, Nine and Ten each hold ten degrees of Pisces. The Page shares the water quarter of
the year with the Ace. The Knight, Queen and King each hold a 30° stretch across two signs.

---

## Eight of Cups
sky: Saturn in Pisces, 0–10° Pisces · season: about Feb 19 – Feb 28 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What am I walking away from right now, even though it looks fine from the outside?
2. Cross / boon: Is leaving the bridge from the old life to the new, or am I walking off before I've finished what's here?
3. Root: When did I first leave something that looked good on paper, and what did I learn about my own leaving?
4. Passing away: What have I already left behind in my heart, even if I haven't left it yet in my life?
5. Front of mind: What deeper thing am I deliberately going in search of, and how will I know when I've found it?
6. Coming in: What path up the mountain is opening, and what do I need to take with me?
7. Who you are: Where am I the one who knows it's time to go, and do I trust that knowing?
8. What surrounds you: Who around me will notice the gap I leave, and what do I want to say to them?
9. Hopes / fears: What do I hope I'll find up the path, and what am I afraid I'm leaving that I'll miss?
10. Outcome: If I keep walking, where does the path lead, and what would I need to stop needing to be sure of before I take the next step?

### Reversed
1. Central theme: Where am I staying with something I've already outgrown, or drifting from place to place without arriving?
2. Cross / boon: Is fear of leaving what's in the way, or am I running away and calling it a search?
3. Root: Who taught me that you stay, no matter what?
4. Passing away: What leaving am I ready to stop rehearsing, either by going or by deciding to stay?
5. Front of mind: What do I keep imagining walking away from, without moving?
6. Coming in: What moment is coming that will settle it: the path up the mountain, or one more try right here?
7. Who you are: Where do I leave things just as they start to ask something real of me?
8. What surrounds you: Who around me is making it hard to go, and do they know?
9. Hopes / fears: What do I dread finding out if I stay, or if I go?
10. Outcome: If I keep half-leaving, what does it cost both places, and what would I need to admit to finally choose?

### Watch for
Upright
- Sun: Watch for the moment you realize you've outgrown something, and let yourself say so.
- Moon: Watch for a tiredness with something that rest doesn't fix.
- Mars: Watch for the nerve it takes to walk out of a room, a habit or a role.
- Mercury: Watch for a conversation where you can say "I'm done with this," kindly.
- Jupiter: Watch for the bigger meaning you're actually hungry for.
- Venus: Watch for what still feels beautiful, and what has quietly gone flat.
- Saturn: Watch for the thing you've finished with, and say a proper goodbye.

Reversed
- Sun: Watch for staying put to keep up appearances.
- Moon: Watch for restlessness every evening, and what it's asking for.
- Mars: Watch for storming off to avoid a harder conversation.
- Mercury: Watch for "one more week, one more month."
- Jupiter: Watch for chasing the next big thing to escape this one.
- Venus: Watch for staying for comfort when the love has gone.
- Saturn: Watch for duty that keeps you somewhere you've already left.

### Low tide
- Notice: the gap in the top row of cups, and the moon watching from above.
- Become: the figure walking away. Why are you leaving at night, and what's up that path?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Pisces), so leaving what no longer fits and going after deeper meaning are a lifelong thread for you. Answer about the times you've walked away and found something.
- Touching you: Saturn, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so endings and the long haul are part of today's question. Answer about what you've finished with.
- Its season: The Sun is in this card's ten days of the year, about February 19 to 28, the last weeks of winter, when the old year feels used up. Answer about what you're ready to walk away from.
- Today's weather: {planet} {is} passing through the first ten degrees of Pisces, this card's slice of the sky, so the urge to leave something is close today. Answer about what's gone flat for you now.
- The long season: {planet} {is} moving through the first ten degrees of Pisces for months or years, an era of leaving and searching. Answer about what you've been slowly walking away from.
- Turning: Saturn, this card's planet, is retrograde (seeming to move backward), as it is for about four and a half months each year, a time to look back at what you've left. Answer about something you left too soon, or not soon enough.

### Essence
- Upright: the walk away by moonlight
- Reversed: the half-packed bag
- Figure: the walker in the red cloak

---

## Nine of Cups
sky: Jupiter in Pisces, 10–20° Pisces · season: about Mar 1 – Mar 10 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What wish of mine has already come true, and have I let myself enjoy it?
2. Cross / boon: Is being satisfied what frees me to move on to what's next, or a comfortable seat I don't want to get up from?
3. Root: What's the first wish I remember coming true, and how did it shape what I let myself want?
4. Passing away: What want has been filled, and is it time to stop wanting it?
5. Front of mind: What am I wishing for on purpose right now, and how would I know it had come true?
6. Coming in: What good thing is arriving, and how will I let myself enjoy it without waiting for the catch?
7. Who you are: Where am I pleased with myself in this, and is that a good thing to be?
8. What surrounds you: Who around me shares my good fortune, and who would like a seat at the table?
9. Hopes / fears: What do I hope will finally feel like enough, and what am I afraid will still be missing?
10. Outcome: If I keep getting what I wish for, who do I become, and what would I change about my wishes so I'm glad of them later?

### Reversed
1. Central theme: Where did I get what I wanted and find it hollow, or am I still waiting for permission to want?
2. Cross / boon: Is smugness what stands in the way, or a wish I'm too shy to say out loud?
3. Root: Who taught me that wanting things for myself was greedy?
4. Passing away: Which old wish can I finally blow out like a candle, without making a new one in its place?
5. Front of mind: What am I wanting so hard that I can't enjoy what I have?
6. Coming in: What's coming that will show me what I really want, under what I said I wanted?
7. Who you are: Where am I indulging to fill a gap?
8. What surrounds you: Who around me is quietly envious, or am I?
9. Hopes / fears: If every wish on the shelf came true tomorrow, what's the one I'd secretly regret?
10. Outcome: If I keep chasing satisfaction this way, what stays empty, and what simpler want would I trade it for?

### Watch for
Upright
- Sun: Watch for a moment to be openly glad of what you have.
- Moon: Watch for a feeling of being full and content, and stay in it.
- Mars: Watch for something you earned, and enjoy it without apology.
- Mercury: Watch for a chance to say a wish out loud.
- Jupiter: Watch for good fortune you could share.
- Venus: Watch for a pleasure that's exactly right, and savor it.
- Saturn: Watch for "enough," and notice when you reach it.

Reversed
- Sun: Watch for showing off what you have.
- Moon: Watch for comfort-eating, comfort-buying, comfort-scrolling.
- Mars: Watch for frustration that the wish came true and you still feel empty.
- Mercury: Watch for bragging, or for hiding a wish because it embarrasses you.
- Jupiter: Watch for wanting more when you already have plenty.
- Venus: Watch for a pleasure that has lost its taste.
- Saturn: Watch for refusing yourself something good on principle.

### Low tide
- Notice: the blue cloth draped under the row of cups, and his folded arms.
- Become: the man on the bench. What did you wish for, and what's under the cloth?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Pisces), so wishes, contentment and enjoying what you have are a lifelong thread for you. Answer about the wishes that have come true for you.
- Touching you: Jupiter, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so growth and good fortune are part of today's question. Answer about a wish that's ripening.
- Its season: The Sun is in this card's ten days of the year, about March 1 to 10, the very end of winter, with spring almost in reach. Answer about what you're wishing for.
- Today's weather: {planet} {is} passing through the middle ten degrees of Pisces, this card's slice of the sky, so a wish is close to the surface today. Answer about what would make today feel complete.
- The long season: {planet} {is} moving through the middle ten degrees of Pisces for months or years, an era of wishes coming true. Answer about the contentment you're slowly growing into.
- Turning: Jupiter, this card's planet, is retrograde (seeming to move backward), a time when growth turns inward. Answer about a wish you'd revise before it comes true.

### Essence
- Upright: the wish come true
- Reversed: the wish that tastes hollow
- Figure: the man on the bench

---

## Ten of Cups
sky: Mars in Pisces, 20–30° Pisces · season: about Mar 11 – Mar 20 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: Where does my life feel whole right now, and who's in the picture with me?
2. Cross / boon: Is this harmony the bridge to what's next, or a picture I'm trying to keep perfect?
3. Root: What did home look like when I was small, and what of it am I building, or building differently?
4. Passing away: What season of family life is changing, and what do I want to remember about it?
5. Front of mind: What kind of home am I deliberately creating, and who is it for?
6. Coming in: What joy, reunion or new chapter of home is arriving, and how do I want to welcome it?
7. Who you are: Where do I feel I belong in my own family, chosen or given?
8. What surrounds you: Who around me makes home feel like home, and do they know it?
9. Hopes / fears: What do I hope my home will be, and what am I afraid could break it?
10. Outcome: If I keep tending home like this, what grows there, and what would I need to stop expecting of it so it can be real rather than perfect?

### Reversed
1. Central theme: Where is home strained right now, or where am I pretending it isn't?
2. Cross / boon: Is the gap between the picture and the reality what stands in the way?
3. Root: What did my first home teach me about what love looks like, and what do I want to unlearn?
4. Passing away: What picture of the perfect family am I ready to put down?
5. Front of mind: What argument at home keeps replaying in my head?
6. Coming in: What's coming through the front door that will need patching up: a hurt, a habit, a silence?
7. Who you are: Where do I feel like an outsider in my own family?
8. What surrounds you: Who around me is holding a family together on their own?
9. Hopes / fears: If I stopped holding up the rainbow and said home isn't okay, what would I be afraid would break?
10. Outcome: If home stays like this, what wears thin, and which small kindness would I offer first to start mending it?

### Watch for
Upright
- Sun: Watch for a moment of being proud of the people you call home.
- Moon: Watch for the ordinary evening that's quietly perfect.
- Mars: Watch for something at home worth protecting.
- Mercury: Watch for the story your family tells about itself, and whether it still fits.
- Jupiter: Watch for a chance to widen the circle at your table.
- Venus: Watch for rainbows, laughter, shared meals, a hand held.
- Saturn: Watch for the long, steady love that built your home.

Reversed
- Sun: Watch for performing a happy home for other people.
- Moon: Watch for tension that comes home with someone and settles in.
- Mars: Watch for the same old argument at the same old spot at the table.
- Mercury: Watch for what isn't being said at home.
- Jupiter: Watch for overcommitting to family events to keep the peace.
- Venus: Watch for comparing your home to someone else's.
- Saturn: Watch for family duty with no love left in it.

### Low tide
- Notice: the two children dancing, and the rainbow of cups the couple raise their arms to.
- Become: one of the dancing children. What's the song, and who taught you the dance?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Pisces), so home, family and feeling whole are a lifelong thread for you. Answer about the home you've always been making.
- Touching you: Mars, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so energy and friction are part of today's question. Answer about what you'd defend at home.
- Its season: The Sun is in this card's ten days of the year, about March 11 to 20, the very end of winter, just before spring. Answer about what makes home feel whole.
- Today's weather: {planet} {is} passing through the last ten degrees of Pisces, this card's slice of the sky, so home and family are in focus today. Answer about the people you're coming home to now.
- The long season: {planet} {is} moving through the last ten degrees of Pisces for months or years, an era of building home. Answer about the family, given or chosen, slowly forming around you.
- Turning: Mars, this card's planet, is retrograde (seeming to move backward), a time when old patterns come back around. Answer about a family pattern worth revisiting.

### Essence
- Upright: the rainbow over home
- Reversed: the picture-perfect home that isn't
- Figure: a dancing child

---

## Page of Cups
sky: the water quarter of the year, Libra through Sagittarius · season: about Sep 23 – Dec 21 · lit by: Its season

### Upright
1. Central theme: What surprising feeling, idea or message has popped up in me lately?
2. Cross / boon: Is this tender curiosity what gets me to something new, or a daydream I'm letting distract me?
3. Root: What first made me believe in magic as a kid, and how much of it is still in me?
4. Passing away: What childlike way of feeling am I growing out of, and what will I keep?
5. Front of mind: What creative or tender thing am I deliberately letting myself play with?
6. Coming in: What message, invitation or emotional surprise is arriving?
7. Who you are: Where am I soft and open in this, and how does that feel?
8. What surrounds you: Who around me speaks from the heart without worrying how it sounds?
9. Hopes / fears: What do I hope this little surprise is the start of, and what am I afraid will laugh at it?
10. Outcome: If I keep following this tender curiosity, where does it go, and what would I need to stop feeling silly about to let it?

### Reversed
1. Central theme: Where am I sulking, oversensitive, or shutting down an idea before it's had a chance?
2. Cross / boon: Is embarrassment what's in the way, or a fantasy I'm letting run my day?
3. Root: What softness in me was teased when I was young?
4. Passing away: What childhood hurt am I ready to let grow up?
5. Front of mind: What creative idea am I keeping secret because it feels too silly?
6. Coming in: What tender thing is about to wash up at my feet, and will I pick it up?
7. Who you are: Where do I take things too personally?
8. What surrounds you: Who around me is being moody, and is any of it mine to hold?
9. Hopes / fears: If I showed someone the fish in my cup and they shrugged, how would I comfort myself?
10. Outcome: If I keep my softness hidden, what goes unsaid, and what one tender thing would I let out?

### Watch for
Upright
- Sun: Watch for a moment to share something you made, however small.
- Moon: Watch for a hunch or a dream with a message in it.
- Mars: Watch for the nerve to say something tender out loud.
- Mercury: Watch for a surprising message, a sweet note, a kind word out of nowhere.
- Jupiter: Watch for a little bit of wonder, and follow it.
- Venus: Watch for something cute, sweet or delightful, and let it delight you.
- Saturn: Watch for a small creative habit you could start today.

Reversed
- Sun: Watch for hiding something you made because it might be judged.
- Moon: Watch for moodiness, and what small comfort would help.
- Mars: Watch for a hurt feeling that turns into a sharp word.
- Mercury: Watch for a message you're reading too much into.
- Jupiter: Watch for escaping into daydreams instead of the day.
- Venus: Watch for a crush that's mostly in your head.
- Saturn: Watch for "that's childish," and question it.

### Low tide
- Notice: the fish looking up out of the cup, and the waves behind him.
- Become: the fish. What do you want to tell him, now that he's looking?

### Lit
- Its season: The Sun is in this card's quarter of the year, Libra through Sagittarius, about September 23 to December 21: autumn, the season of water. Answer about a tender surprise this season is bringing.

### Essence
- Upright: the fish in the cup
- Reversed: the feeling hidden for fear of looking silly
- Figure: the page with the fish

---

## Knight of Cups
sky: 20° Aquarius to 20° Pisces (the fiery part of Water) · season: about Feb 9 – Mar 10 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What am I following my heart toward right now, and what am I carrying out ahead of me?
2. Cross / boon: Is this romantic streak what gets me across, or am I moving so slowly and dreamily that I'll never arrive?
3. Root: Who first showed me what it looks like to lead with the heart, and what did I take from them?
4. Passing away: What romance, ideal or dream is passing, and what did it give me?
5. Front of mind: What am I deliberately offering to someone or something right now?
6. Coming in: What invitation, proposal or offer of love is on its way to me?
7. Who you are: Where am I the dreamer or the romantic in this, and does it serve me?
8. What surrounds you: Who around me is courting me, a person, a project, a place, and how do I feel about it?
9. Hopes / fears: What do I hope my heart will lead me to, and what am I afraid will disappoint me when I get there?
10. Outcome: If I keep following my heart at this pace, where do I arrive, and what would I need to see clearly to make sure it's somewhere I want to be?

### Reversed
1. Central theme: Where am I in love with an idea more than with what's real?
2. Cross / boon: Is moodiness what's in the way, or promises I can't keep?
3. Root: What early romance taught me that love is mostly longing?
4. Passing away: What fantasy of being rescued am I ready to give up?
5. Front of mind: What grand gesture am I imagining instead of making a small real one?
6. Coming in: What's coming that will test whether my offer is real?
7. Who you are: Where do I charm my way out of being honest?
8. What surrounds you: Who around me makes beautiful promises, and how many have they kept?
9. Hopes / fears: If the romance turned into dishes and bills, what would I be afraid I'd lost?
10. Outcome: If I keep chasing the ideal, what do I miss, and which real thing would I choose over the dream?

### Watch for
Upright
- Sun: Watch for a chance to make a heartfelt gesture openly.
- Moon: Watch for what your heart is drawn to before your head weighs in.
- Mars: Watch for an invitation worth accepting, and accept it.
- Mercury: Watch for a love letter, a compliment or a poem in an ordinary place.
- Jupiter: Watch for an offer that would open your life up.
- Venus: Watch for romance in small things: flowers, a slow walk, candlelight.
- Saturn: Watch for the follow-through that makes a romantic gesture mean something.

Reversed
- Sun: Watch for grand gestures that are mostly for show.
- Moon: Watch for mood swings when reality doesn't match the dream.
- Mars: Watch for jealousy dressed up as passion.
- Mercury: Watch for sweet talk, given or received, and what's underneath it.
- Jupiter: Watch for an offer made in a rush of feeling that tomorrow-you will have to keep.
- Venus: Watch for falling for the feeling of falling.
- Saturn: Watch for disappointment that's really an expectation set too high.

### Low tide
- Notice: the wings on his helmet and heels, and that his horse is walking, not galloping.
- Become: the white horse. Where are you taking him, and why so slowly?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Aquarius to 20° Pisces), so romance, idealism and following your heart are a lifelong thread for you. Answer about where your heart has led you.
- Its season: The Sun is in this card's stretch of the year, about February 9 to March 10, late winter, when longing for spring sets in. Answer about what your heart is reaching for.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Aquarius into Pisces, so the heart is leading today. Answer about the offer or invitation in front of you now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Aquarius into Pisces, for months or years, an era of following your heart. Answer about the dream you're slowly moving toward.

### Essence
- Upright: the cup carried out ahead
- Reversed: in love with the idea
- Figure: the white horse

---

## Queen of Cups
sky: 20° Gemini to 20° Cancer (the watery part of Water) · season: about Jun 11 – Jul 11 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What am I sensing about someone or something right now that I haven't said out loud?
2. Cross / boon: Is my compassion what helps everyone across, or am I so tuned to others that I'm losing track of my own way?
3. Root: Who first held my feelings gently, and what of their care do I give now?
4. Passing away: What season of holding everyone else's feelings is ending, and what did it teach me?
5. Front of mind: What am I deliberately tending in my inner life right now?
6. Coming in: What deep feeling or intuition is rising in me, and how do I want to meet it?
7. Who you are: Where am I the calm, caring presence in this, and who cares for me?
8. What surrounds you: Who around me needs to be listened to, without being fixed?
9. Hopes / fears: What do I hope my sensitivity is for, and what am I afraid it costs me?
10. Outcome: If I keep feeling this deeply, what does it give me, and what boundary would I need so the depth stays a gift?

### Reversed
1. Central theme: Where am I drowning in other people's feelings, or cut off from my own?
2. Cross / boon: Is oversensitivity what's in the way, or a feeling I've closed the lid on?
3. Root: Who taught me that caring for others came before caring for myself?
4. Passing away: What emotional job am I ready to stop doing for other people?
5. Front of mind: What worry about someone am I carrying around in my head?
6. Coming in: Whose feelings are about to land in my lap, and which of them are mine to hold?
7. Who you are: Where am I giving so much compassion out that there's none left inside?
8. What surrounds you: Who around me leans on me for every feeling?
9. Hopes / fears: If I set down everyone else's feelings and let someone hold mine, what am I afraid would happen?
10. Outcome: If I keep absorbing everything, what happens to me, and what would I set down first to come back to myself?

### Watch for
Upright
- Sun: Watch for a moment to let your kindness be seen.
- Moon: Watch for your intuition, and trust one quiet knowing today.
- Mars: Watch for a chance to defend someone's feelings, gently but firmly.
- Mercury: Watch for what someone means under what they say.
- Jupiter: Watch for a chance to be generous with your attention.
- Venus: Watch for water, a bath, a shore, a glass, and let it calm you.
- Saturn: Watch for the boundary that lets you keep caring.

Reversed
- Sun: Watch for caring that's turned into martyrdom.
- Moon: Watch for absorbing a mood that isn't yours.
- Mars: Watch for resentment after too much giving.
- Mercury: Watch for reading too much into someone's tone.
- Jupiter: Watch for rescuing people who didn't ask.
- Venus: Watch for neglecting your own comfort while tending everyone else's.
- Saturn: Watch for shutting feeling down just to cope.

### Low tide
- Notice: the closed, ornate cup she gazes into, and her feet almost at the water's edge.
- Become: the closed cup. What does she think is inside you, and is she right?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Gemini to 20° Cancer), so compassion, intuition and emotional depth are a lifelong thread for you. Answer about what you've always sensed in others.
- Its season: The Sun is in this card's stretch of the year, about June 11 to July 11, the turn from spring into summer. Answer about what you're feeling under the surface.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Gemini into Cancer, so feelings run deep today. Answer about what you're sensing now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Gemini into Cancer, for months or years, an era of emotional depth. Answer about the care you're slowly learning to give, and to receive.

### Essence
- Upright: the cup she gazes into
- Reversed: everyone's feelings but her own
- Figure: the closed cup

---

## King of Cups
sky: 20° Libra to 20° Scorpio (the airy part of Water) · season: about Oct 13 – Nov 11 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: Where am I staying calm while the water around me is rough?
2. Cross / boon: Is my steadiness what gets everyone across, or am I so calm on the surface that no one knows what I feel?
3. Root: Who first showed me how to be steady in a storm, and what did I learn from watching?
4. Passing away: What emotional storm have I come through, and what did I learn about keeping my seat?
5. Front of mind: What am I deliberately keeping balanced right now, and what does that balance let me do?
6. Coming in: What situation is arriving that will need a calm, kind head?
7. Who you are: Where am I the one others come to for steady counsel?
8. What surrounds you: Who around me is in rough water, and how could I be steady for them without going under?
9. Hopes / fears: What do I hope my calm makes possible, and what am I afraid would happen if I let it show how I feel?
10. Outcome: If I keep leading with this steadiness, what grows around me, and what feeling would I need to let out so the calm stays honest?

### Reversed
1. Central theme: Where am I calm on the outside and churning inside?
2. Cross / boon: Is a feeling I've kept down what's in the way, or a mood I'm letting run things?
3. Root: Who taught me that being strong means not showing what I feel?
4. Passing away: What role as the steady one am I ready to put down for a while?
5. Front of mind: What feeling am I managing in my head instead of feeling?
6. Coming in: What's coming that will crack the calm, and what would help me let it?
7. Who you are: Where am I using control to keep people at a distance?
8. What surrounds you: Who around me uses their moods to steer everyone?
9. Hopes / fears: If the sea got under my throne and people saw me rock, what would I be afraid they'd think?
10. Outcome: If I keep holding it all in, where does it go, and what one honest feeling would I let someone see?

### Watch for
Upright
- Sun: Watch for a moment to lead with warmth and a cool head at once.
- Moon: Watch for a strong feeling you can hold without being held by it.
- Mars: Watch for anger you can turn into a calm, clear boundary.
- Mercury: Watch for a chance to give wise, kind counsel.
- Jupiter: Watch for someone who'd benefit from your steadiness.
- Venus: Watch for a way to keep the peace without losing the truth.
- Saturn: Watch for the patience that keeps your seat steady in rough water.

Reversed
- Sun: Watch for coolness that's really pride.
- Moon: Watch for a mood that leaks out sideways.
- Mars: Watch for anger that comes out as a sigh, a silence or a slammed cupboard.
- Mercury: Watch for "I'm fine" said through your teeth.
- Jupiter: Watch for advice given to avoid feeling.
- Venus: Watch for charm used to manage people.
- Saturn: Watch for control that has gone cold.

### Low tide
- Notice: the fish leaping out of the sea on one side and the ship on the other, and his throne floating on the water.
- Become: the leaping fish. What do you see from up in the air that he can't see from his throne?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Libra to 20° Scorpio), so emotional steadiness, wise counsel and calm under pressure are a lifelong thread for you. Answer about how you've learned to stay steady.
- Its season: The Sun is in this card's stretch of the year, about October 13 to November 11, the heart of fall, with the year turning darker. Answer about what you're keeping steady.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Libra into Scorpio, so feelings are strong today. Answer about where you need to stay steady now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Libra into Scorpio, for months or years, an era of learning emotional steadiness. Answer about the calm you're slowly building.

### Essence
- Upright: the calm throne on rough water
- Reversed: the calm that's a lid
- Figure: the king on the sea
