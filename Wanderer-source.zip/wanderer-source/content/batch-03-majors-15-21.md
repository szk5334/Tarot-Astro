# Batch 3: The Devil to The World

Majors 15–21. Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position),
14 watch-for cues (one per day ruler, each orientation), a low-tide pointer, and its lit lines.

---

## The Devil
sky: the sign Capricorn · season: about Dec 22 – Jan 19 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What habit, want or arrangement has a hold on me right now, and what do I get from staying in it?
2. Cross / boon: Is this attachment getting me through to something new, or is it the chain that keeps me standing where I am?
3. Root: What first taught me I needed this, a comfort, a person, a way of coping, and what was it standing in for back then?
4. Passing away: What hold over me is loosening, and what did it give me while it lasted?
5. Front of mind: What am I chasing on purpose right now, and is it feeding me or only keeping me busy wanting?
6. Coming in: What temptation or bargain is on its way, and what would I want to know about its price before I say yes?
7. Who you are: Where am I wearing a chain loose enough to lift off, and what keeps my hands at my sides?
8. What surrounds you: Who or what around me pulls on my appetites, and who benefits when I give in?
9. Hopes / fears: What do I hope this hunger will finally fill, and who am I afraid I'd be without it?
10. Outcome: If I keep this arrangement as it is, where does it take me, and what would I need to see to either choose it freely or lift the chain off?

### Reversed
1. Central theme: What hold on me am I starting to see clearly, and what's the first link I could lift?
2. Cross / boon: Is the fear of letting go what keeps me here, or is breaking free happening faster than I can steady myself?
3. Root: Who taught me that wanting things was dangerous, and what did I learn to want in secret instead?
4. Passing away: What compulsion or bargain am I finally ready to walk away from?
5. Front of mind: What am I telling myself I can quit any time, and when did I last test it?
6. Coming in: What freedom is arriving, and what will I do with my hands once they're empty?
7. Who you are: Where have I swung from giving in to clamping down, and is either one really me?
8. What surrounds you: Who around me is loosening their own chains, and what could I learn from watching them?
9. Hopes / fears: What feeling am I afraid is waiting underneath the habit, once it's gone?
10. Outcome: If I keep loosening this hold, where does it leave me, and what will I need on the days it pulls hardest?

### Watch for
Upright
- Sun: Watch for where you perform being fine while something has hold of you.
- Moon: Watch for a craving at home, food, screens, comfort, and ask what it's standing in for.
- Mars: Watch for the rush you get from a fight, and whether you're picking one for it.
- Mercury: Watch for a deal that sounds better than it is, and read the small print.
- Jupiter: Watch for "just one more," and count how many there have been.
- Venus: Watch for a pleasure you enjoy without guilt, and one you can't stop at.
- Saturn: Watch for a duty that has become a cage, and the key you already hold.

Reversed
- Sun: Watch for a moment when you can let someone see the habit you're leaving.
- Moon: Watch for the restlessness that comes when you skip the usual comfort, and sit with it a minute.
- Mars: Watch for the strength it takes to say no, and use it once today.
- Mercury: Watch for the excuse you reach for automatically, and say it out loud to hear it.
- Jupiter: Watch for the space that opens when you don't fill it.
- Venus: Watch for a pleasure you can enjoy freely, with no hook in it.
- Saturn: Watch for a rule you set yourself that's actually working, and keep it.

### Low tide
- Notice: the chains around the two small figures' necks, and how loose they are.
- Become: one of the chained figures. Have you noticed the chain could lift off, and why are you still standing there?

### Lit
- Yours: You were born with a planet in Capricorn, this card's sign, so ambition, hunger and what you'll trade to get ahead are a lifelong thread for you. Answer about what has always had a pull on you.
- Its season: The Sun is in Capricorn, about December 22 to January 19, the first month of winter, when the year turns on its longest nights. Answer about what you're holding on to and why.
- Today's weather: {planet} {is} passing through Capricorn, the Devil's sign, so a pull, a bargain or an old habit is close today. Answer about the one in front of you.
- The long season: {planet} {is} moving through Capricorn for months or years, slowly testing what binds you and what you'd trade to get ahead. Answer about the hold you're working loose.

### Essence
- Upright: the chain loose enough to lift
- Reversed: the chain coming off
- Figure: a chained figure

---

## The Tower
sky: Mars · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What in my life is cracking or coming down right now, and what can I already see through the gap?
2. Cross / boon: Is this shake-up the way out of the old tower, or am I so busy bracing that I can't step through the gap?
3. Root: What earlier collapse cleared the ground for all of this, and what did I build after it?
4. Passing away: What false front or shaky structure is falling away, and what did it protect me from while it stood?
5. Front of mind: What truth am I deliberately letting hit me right now, and what is it breaking open?
6. Coming in: What sudden change or revelation is on its way, and what would help me land on my feet?
7. Who you are: Where am I the lightning in this, the one saying the thing that brings it down?
8. What surrounds you: What around me has been built on something shaky, and is it mine to hold up?
9. Hopes / fears: What do I secretly hope would finally crack open, and what am I afraid would come down with it?
10. Outcome: If this keeps coming down, what's left on the ground, and what would I build differently from the rubble?

### Reversed
1. Central theme: What collapse am I holding off with both hands, and how long can I keep it up?
2. Cross / boon: Is my fear of upheaval what's keeping this standing, or a slow crumble I keep patching?
3. Root: Which earthquake in my past taught me that change always comes as a disaster?
4. Passing away: What did the last upheaval leave behind that I haven't cleared away yet?
5. Front of mind: What truth do I keep almost saying, and then swallow?
6. Coming in: What's coming that I could let change me gradually instead of all at once?
7. Who you are: Where am I shaking inside while keeping everything outside standing?
8. What surrounds you: Who around me is pretending nothing is cracking, and am I helping them pretend?
9. Hopes / fears: What do I picture losing if I let go of the walls I've been holding up?
10. Outcome: If I keep propping this up, what happens when I get tired, and how could I take it down brick by brick instead?

### Watch for
Upright
- Sun: Watch for a moment of sudden clarity, and don't talk yourself out of what you saw.
- Moon: Watch for a jolt in your body or your mood, and ask what it's reacting to.
- Mars: Watch for anger that tells the truth, and let it speak once, cleanly.
- Mercury: Watch for news that changes the picture, and give yourself a minute before answering.
- Jupiter: Watch for the bigger room that appears when a wall comes down.
- Venus: Watch for something in a relationship that can't stay hidden, and handle it gently.
- Saturn: Watch for a structure that won't hold, and decide what's worth saving from it.

Reversed
- Sun: Watch for keeping up appearances that are costing you more than they give.
- Moon: Watch for tension you carry home and set down nowhere.
- Mars: Watch for an explosion building slowly, and let out a little steam on purpose.
- Mercury: Watch for denial in conversation: "it's fine," "it's nothing," "it'll pass."
- Jupiter: Watch for adding more to something that's already overloaded.
- Venus: Watch for staying in the comfortable version of something to avoid a hard truth.
- Saturn: Watch for the repair you keep making to something that needs replacing.

### Low tide
- Notice: the crown knocked off the top of the tower, and the small flames falling through the dark.
- Become: the crown. What was it like up there, and what do you see as you fall?

### Lit
- Yours: Mars, this card's planet, holds a strong place in your birth chart, so sudden truths, courage and clearing things out are a lifelong thread for you. Answer about the upheavals that have set you free.
- Touching you: Mars, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so heat, drive or friction is part of today's question. Answer about what's ready to break open.
- Turning: Mars, this card's planet, is retrograde (seeming to move backward), as it is for about two and a half months every two years, a time when anger and drive turn inward. Answer about what needs rebuilding rather than knocking down.

### Essence
- Upright: the wall coming down
- Reversed: the collapse held off
- Figure: the falling crown

---

## The Star
sky: the sign Aquarius · season: about Jan 20 – Feb 18 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What small hope is still alight in me right now, and what is it pointing toward?
2. Cross / boon: Is hope the light I'm walking by toward what's next, or am I gazing up at it instead of walking?
3. Root: What first gave me faith that things could get better, and do I still remember the feeling?
4. Passing away: What hard stretch is easing, and what did I learn about how I heal?
5. Front of mind: What am I hoping for on purpose right now, and what is that hope quietly making real?
6. Coming in: What healing or renewal is on its way, and how can I be open enough to let it in?
7. Who you are: Where am I simply myself in this, with nothing hidden, and how does that feel?
8. What surrounds you: Who around me gives me hope just by being who they are, and do they know it?
9. Hopes / fears: What do I hope for so much I hardly say it out loud, and what am I afraid of if it never comes?
10. Outcome: If I keep pouring myself out this freely, what grows, and what would I need to believe to keep pouring?

### Reversed
1. Central theme: Where have I lost hope, or stopped letting myself want anything?
2. Cross / boon: Is discouragement what's holding me back, or a hope so big it's become a weight?
3. Root: Which hope, long ago, let me down so hard that I stopped hoping out loud?
4. Passing away: What old disappointment am I ready to stop carrying?
5. Front of mind: What am I telling myself won't work before I've even tried?
6. Coming in: What's arriving that will ask me to believe in something again?
7. Who you are: Where am I giving to everyone else and leaving my own cup empty?
8. What surrounds you: Who around me has run dry, and is there a little water I could share?
9. Hopes / fears: What do I brace for if I let myself hope again?
10. Outcome: If I keep my hopes this small, where does that leave me, and what small wish could I let myself want this week?

### Watch for
Upright
- Sun: Watch for a moment when you can let yourself be seen just as you are.
- Moon: Watch for water that soothes: a bath, a glass, the sound of rain, and take it in.
- Mars: Watch for a hope worth acting on, and take one small step toward it.
- Mercury: Watch for a kind word that arrives at the right time, and pass one along.
- Jupiter: Watch for a sign that things are turning for the better, however small.
- Venus: Watch for quiet beauty: the night sky, a clear morning, someone's unguarded face.
- Saturn: Watch for the slow healing you can only see if you look back a few months.

Reversed
- Sun: Watch for hiding your brightness so no one expects too much.
- Moon: Watch for tiredness that's really discouragement, and give it rest rather than a pep talk.
- Mars: Watch for cynicism that's protecting a hope you still have.
- Mercury: Watch for "what's the point," and answer it honestly once.
- Jupiter: Watch for promises of rescue that ask you to give up your own effort.
- Venus: Watch for pouring care into others while you go thirsty.
- Saturn: Watch for despair that calls itself being realistic.

### Low tide
- Notice: one jug pouring into the pool and one onto the land, and the small bird in the tree behind her.
- Become: the bird in the tree. What do you see her doing, and what do you want to say about it?

### Lit
- Yours: You were born with a planet in Aquarius, this card's sign, so hope, freedom and your own odd vision of how things could be are a lifelong thread for you. Answer about what you've always believed could get better.
- Its season: The Sun is in Aquarius, about January 20 to February 18, deep winter with the light starting to come back. Answer about the hope you're carrying through the cold.
- Today's weather: {planet} {is} passing through Aquarius, the Star's sign, so hope sits closer to the surface today. Answer about something you're hoping for now.
- The long season: {planet} {is} moving through Aquarius for months or years, slowly reshaping your hopes and the people you share them with. Answer about the future forming in you.

### Essence
- Upright: hope poured out freely
- Reversed: the cup run dry
- Figure: the bird in the tree

---

## The Moon
sky: the sign Pisces · season: about Feb 19 – Mar 19 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What feels uncertain or half-seen right now, and what do I notice when I stop trying to make it clear?
2. Cross / boon: Is feeling my way in the dark the right way across, or am I lost on the path between the two towers?
3. Root: What old dream, fear or feeling from long ago is rising under all of this?
4. Passing away: What confusion is lifting, and what did I learn by finding my way through it?
5. Front of mind: What am I imagining on purpose right now, and what is that imagining starting to make real?
6. Coming in: What dream, intuition or strange feeling is on its way, and how can I meet it without panicking?
7. Who you are: Where am I both the tame dog and the wild wolf in this?
8. What surrounds you: What around me isn't what it seems, and what does my gut say about it?
9. Hopes / fears: What shapes do I see moving in the dark, and which are hopes and which are fears?
10. Outcome: If I keep walking this path by moonlight, where does it lead, and what would help me see the next step?

### Reversed
1. Central theme: Where is fear or confusion running the show, or where is something I couldn't see finally coming clear?
2. Cross / boon: Is anxiety what's keeping me stuck, or a story I keep telling myself in the dark?
3. Root: Who told me I was imagining things when I wasn't, and do I still doubt what I see?
4. Passing away: What illusion am I finally ready to stop believing?
5. Front of mind: What worry am I feeding with my attention, and how much of it is real?
6. Coming in: What's coming into the light that I've half-known for a while?
7. Who you are: Where am I deceiving myself, even kindly?
8. What surrounds you: Who around me is stirring up fear, and is any of it mine?
9. Hopes / fears: What do I sense is moving just under the surface of the water?
10. Outcome: If I keep letting the fear lead, where does it take me, and what solid thing could I put my foot on next?

### Watch for
Upright
- Sun: Watch for a moment when not knowing is all right, and let it be.
- Moon: Watch for the mood you woke up with, and follow where it drifts through the day.
- Mars: Watch for fear that shows up as an urge to act, and wait for the light.
- Mercury: Watch for rumors, half-truths and mixed signals, and check one.
- Jupiter: Watch for a feeling that seems bigger than the moment, and ask what it's really about.
- Venus: Watch for something beautiful and strange: night light, a song, a picture you can't stop looking at.
- Saturn: Watch for an old fear coming back around, and notice how much smaller it is now.

Reversed
- Sun: Watch for the moment something hidden becomes obvious, and let it.
- Moon: Watch for anxiety in the body, a tight chest, a clenched jaw, and breathe into it once.
- Mars: Watch for lashing out at a shadow.
- Mercury: Watch for the worst-case story you tell yourself, and write the boring version instead.
- Jupiter: Watch for making a fear bigger by talking it over and over.
- Venus: Watch for seeing someone as you wish they were, rather than as they are.
- Saturn: Watch for a nightmare that's really an old lesson asking to be learned again.

### Low tide
- Notice: the crayfish crawling up out of the pool, and the dog and the wolf howling at the same moon.
- Become: the crayfish. Why are you coming out of the water now, and where does the path lead?

### Lit
- Yours: You were born with a planet in Pisces, this card's sign, so dreams, feeling and moving by intuition are a lifelong thread for you. Answer about how you find your way when things aren't clear.
- Its season: The Sun is in Pisces, about February 19 to March 19, the last month of winter, when everything is about to thaw. Answer about what's stirring under the surface.
- Today's weather: {planet} {is} passing through Pisces, the Moon card's sign, so moods, dreams and worries run closer to the surface today. Answer about the one you're living with now.
- The long season: {planet} {is} moving through Pisces for months or years, a long season of blurred edges and strong dreams. Answer about what you're slowly learning to see clearly.

### Essence
- Upright: the path by moonlight
- Reversed: the fear in the dark
- Figure: the crayfish

---

## The Sun
sky: the Sun · lit by: Yours, Touching you

### Upright
1. Central theme: What is going well right now, plainly and simply, and what does it feel like to let myself enjoy it?
2. Cross / boon: Is this warmth lighting the way into the next part of my life, or is the brightness making it hard to see what still needs doing?
3. Root: When was I last as open as a child, arms wide on a horse with no reins, and what made it safe to be?
4. Passing away: What dark stretch am I coming out of, and what helped me find my way to the light?
5. Front of mind: What am I celebrating on purpose right now, and what does celebrating it make real?
6. Coming in: What joy or success is on its way, and how can I let myself have it without bracing for the catch?
7. Who you are: Where am I simply glad to be me in this?
8. What surrounds you: Who around me lights things up, and have I told them?
9. Hopes / fears: What do I hope I'll finally let myself feel, and what makes me nervous about being this happy?
10. Outcome: If I keep living this openly, where does it lead, and what would I stop hiding to shine even more freely?

### Reversed
1. Central theme: Where is my joy dimmed right now, behind a cloud I could name?
2. Cross / boon: Is a forced smile what's keeping real joy out, or doubt that good things are really mine?
3. Root: Who taught me to dim myself so others would be comfortable?
4. Passing away: What way of hiding my light am I ready to stop?
5. Front of mind: What good thing am I so busy waiting for that I miss the one already here?
6. Coming in: What good day is heading my way, and will I let it be good without bracing?
7. Who you are: Where am I performing brightness I don't feel?
8. What surrounds you: Who around me is too dimmed to see clearly right now, and could I be warm with them?
9. Hopes / fears: What would people think if they saw how much I want to be happy, and would they be right?
10. Outcome: If I keep the light turned down, where does that leave me, and what's one warm thing I could let back in today?

### Watch for
Upright
- Sun: Watch for a moment to be openly proud of something, and let it show.
- Moon: Watch for simple comfort in the body: sun on your skin, a good stretch, a full meal.
- Mars: Watch for energy you can spend on something fun, not just something useful.
- Mercury: Watch for a chance to say something plainly, the simple true version.
- Jupiter: Watch for something generous you can do just because you feel good.
- Venus: Watch for joy in color, warmth and play, and join in.
- Saturn: Watch for what you've built that's now bearing fruit, and stop to enjoy it.

Reversed
- Sun: Watch for a moment when you dim yourself so others feel comfortable.
- Moon: Watch for low energy that wants daylight more than effort.
- Mars: Watch for irritation at other people's happiness, and what it's telling you.
- Mercury: Watch for "it's fine" when you mean something else.
- Jupiter: Watch for overdoing the cheer to cover a slump.
- Venus: Watch for a small, silly joy you've decided you're too busy for.
- Saturn: Watch for waiting to enjoy something until everything else is done.

### Low tide
- Notice: the sunflowers leaning over the wall, and that the child rides with no saddle and no reins.
- Become: the child on the horse. Where are you riding to, and why are your arms wide open?

### Lit
- Yours: The Sun, this card's planet, holds a strong place in your birth chart, so joy, vitality and being seen are a lifelong thread for you. Answer about what has always made you feel most alive.
- Touching you: The Sun is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few days, so attention and energy are shining on part of your life. Answer about what wants to be seen right now.

### Essence
- Upright: the plain, open joy
- Reversed: the light turned down
- Figure: the child on the horse

---

## Judgement
sky: Pluto (the element of Fire) · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What is calling me right now, and where did I last hear it: a thought, a person, a line I read?
2. Cross / boon: Is this call the trumpet that gets me up and into what's next, or am I waiting to be completely sure before I rise?
3. Root: When did I first know, even for a moment, what I was here to do, and what was I doing at the time?
4. Passing away: What old version of me is being laid to rest, and what do I want to say to it?
5. Front of mind: What am I deliberately answering with my life right now, and what does answering it make real?
6. Coming in: What awakening or second chance is on its way, and how can I be ready to stand up for it?
7. Who you are: Where am I rising in this, and how does it feel to be called?
8. What surrounds you: Who around me is waking up too, and could we rise together?
9. Hopes / fears: What do I hope I'm being called toward, and what am I afraid it will ask me to leave in the old coffin?
10. Outcome: If I keep answering this call, who do I become, and what would I need to stop waiting for to answer it fully?

### Reversed
1. Central theme: What call am I pretending not to hear?
2. Cross / boon: Is self-doubt keeping me lying down, or someone's harsh verdict, mine or theirs?
3. Root: Whose voice taught me to judge myself so hard that I stay down, and what does it say?
4. Passing away: What old verdict on myself am I ready to stop believing?
5. Front of mind: What decision about my life am I replaying instead of making?
6. Coming in: What's coming that will give me another chance, and will I take it?
7. Who you are: Where am I still lying down when I could be getting up?
8. What surrounds you: Whose judgment around me am I letting speak louder than my own?
9. Hopes / fears: What would I lose, or have to face, if I actually became who I'm meant to be?
10. Outcome: If I keep pretending I didn't hear the trumpet, where does that leave me, and what would finally get me to sit up?

### Watch for
Upright
- Sun: Watch for a moment when you can stand up and be counted.
- Moon: Watch for a feeling of rightness in the body, the yes before the reasons.
- Mars: Watch for the push to finally act on something you've known for a while.
- Mercury: Watch for a message, a song or a line that sounds like it's meant for you.
- Jupiter: Watch for a second chance, and say yes to it.
- Venus: Watch for forgiveness you could offer, to someone else or to yourself.
- Saturn: Watch for what you've earned by the long work, and let it lift you.

Reversed
- Sun: Watch for hiding a calling because it seems too big to say out loud.
- Moon: Watch for heaviness that's really an unanswered call.
- Mars: Watch for harsh self-criticism, and answer it the way you'd answer a friend.
- Mercury: Watch for going over old decisions instead of making the next one.
- Jupiter: Watch for waiting for a sign when you already have one.
- Venus: Watch for judging someone you love more harshly than you'd judge yourself, or the reverse.
- Saturn: Watch for an old verdict you still live under, and ask who gave it.

### Low tide
- Notice: the people rising from their coffins with their arms raised, and that the coffins are floating on water.
- Become: one of the people rising. What woke you, and what's the first thing you want to do?

### Lit
- Yours: Pluto, this card's planet, holds a strong place in your birth chart, so deep change, rebirth and becoming who you're meant to be are a lifelong thread for you. Answer about the times you've been remade.
- Touching you: Pluto, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which can last a year or more, so something in your life is being slowly transformed. Answer about what's rising in you.
- Turning: Pluto, this card's planet, is retrograde (seeming to move backward), as it is for about five months each year, a time to look back at what's changing. Answer about an old call you're ready to hear again.

### Essence
- Upright: the call answered
- Reversed: the call ignored
- Figure: one of the risen

---

## The World
sky: Saturn (and the element of Earth) · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What is coming full circle in my life right now, and what can I point to that tells me it's complete?
2. Cross / boon: Is finishing this the doorway to the next cycle, or am I dancing in the last step so it never quite ends?
3. Root: What long journey led to all of this, and how far have I come since it began?
4. Passing away: What cycle is completing, and how do I want to mark its end?
5. Front of mind: What am I bringing together on purpose right now, and what does making it whole make real?
6. Coming in: What sense of arrival or wholeness is on its way, and how can I let myself feel it?
7. Who you are: Where am I at home in my own life, dancing in the middle of it?
8. What surrounds you: Who around me has been part of this whole journey, and how could I thank them?
9. Hopes / fears: What do I hope it will feel like to be done, and what am I afraid comes after the circle closes?
10. Outcome: If I see this through to the end, where do I stand, and what do I want to carry into the next cycle?

### Reversed
1. Central theme: What's nearly finished that I can't seem to complete?
2. Cross / boon: Is one loose end holding the whole thing open, or am I afraid of what comes after it's tied?
3. Root: Who taught me that nothing I do is ever quite finished, or quite good enough to call done?
4. Passing away: What unfinished thing am I ready to call done, as it is?
5. Front of mind: What am I still trying to perfect when it's already whole?
6. Coming in: Which last page is coming up that I'll need to turn before the next book opens?
7. Who you are: Where do I feel almost at home, and what's the missing piece?
8. What surrounds you: Who around me is waiting for me to finish so they can move on too?
9. Hopes / fears: What would I miss about this if I let it be finished?
10. Outcome: If this stays almost done, what does that cost me, and what's the last small thing that would close the circle?

### Watch for
Upright
- Sun: Watch for a moment to celebrate something finished, and let yourself be seen celebrating.
- Moon: Watch for the feeling of being at home in your own skin, and notice what brings it.
- Mars: Watch for the last push something needs, and give it.
- Mercury: Watch for a chance to tie up a loose end with a single message.
- Jupiter: Watch for how far you've come, and say it out loud.
- Venus: Watch for the joy of something whole: a finished meal, a full circle, a song ending well.
- Saturn: Watch for the long cycle that's closing, and what you want to carry into the next one.

Reversed
- Sun: Watch for downplaying a finish because it doesn't feel big enough.
- Moon: Watch for restlessness at the end of something, and what it's afraid of.
- Mars: Watch for rushing past the ending to get to the next thing.
- Mercury: Watch for the reply you haven't sent, the form you haven't filed, the last step you keep skipping.
- Jupiter: Watch for starting something new to avoid finishing something old.
- Venus: Watch for a relationship or project you keep almost closing.
- Saturn: Watch for perfectionism standing between you and done.

### Low tide
- Notice: the wreath around the dancer, tied with red ribbons at the top and bottom, and the four faces in the corners.
- Become: the dancer. What are you celebrating, and where will you dance next?

### Lit
- Yours: Saturn, this card's planet, holds a strong place in your birth chart, so long work, completion and building something whole are a lifelong thread for you. Answer about the cycles you've seen all the way through.
- Touching you: Saturn, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which can last months, so a long chapter is reaching a turning point. Answer about what's ready to be completed.
- Turning: Saturn, this card's planet, is retrograde (seeming to move backward), as it is for about four and a half months each year, a time to review what you've built. Answer about a loose end you're ready to tie up.

### Essence
- Upright: the circle completed
- Reversed: the last step not taken
- Figure: the dancer
