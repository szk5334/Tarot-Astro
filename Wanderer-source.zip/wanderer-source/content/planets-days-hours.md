# The days and the hours: what they ask

The Clock's day and hour lines open into panels shaped like the cards: Write (a question, with a
ladder for when nothing comes) or Read (what the planet is about, nothing asked).

- **Day questions** rotate weekly (four per planet, so each repeats about once a month).
- **Hour questions** rotate through three per planet.
- **Day ladder**, lowest energy first: Look, Catch, Feel, Lean, Do.
- **Hour ladder**, lowest energy first: Look, One word, One line, Do.
- The shared floor (date, glyph, one word, close the notebook) sits under both.

Edit freely: `parse_cards.py` turns this file into `assets/planets.json`.

---

## Sun

### Day questions
1. What have I made lately that's entirely mine, and who have I let see it?
2. Where did I feel most like myself this week, and what was I doing?
3. What praise did I wave off recently, and what would it be like to let it land?
4. What keeps me lit, and how much of it did I get this week?

### Day ladder
- Look: Name one thing you've seen today that belongs to the Sun: someone shining, something being made, a patch of daylight. Describe it, nothing more.
- Catch: Write one line about a moment you felt fully yourself today, and mark it ☉ in the margin.
- Feel: Where in your body do you feel most alive right now, and where do you feel dim?
- Lean: Has your light been too loud lately, or too hidden? What would bring it back to warm and steady?
- Do: Before the day ends, make one small thing that's yours from start to finish, or get ten minutes of daylight on your skin.

### Day read
- Meaning: The Sun's day is about being who you are where others can see it. It asks for warmth, for making things, and for tending your energy the way you'd tend a fire. Shining takes no light from anyone else.
- Qualities: warm, confident, generous, creative, playful, proud, wholehearted
- Watch for: someone shining or dimming themselves, praise given or held back, something being made, a moment you felt fully yourself.
- Too much: showing off, needing the spotlight, treating light as if there weren't enough to go around. The way back: notice the light in everyone else, and admire it.
- Too little: hiding, shrinking, believing you aren't worth being seen. The way back: find the nerve to step into view; you're worth it.

### Hour questions
1. What would I say right now if I knew it would be received warmly?
2. What could I make, start to finish, before this hour is over?
3. Where am I hiding a little, and what's one way to be seen this hour?

### Hour ladder
- Look: Find one bright thing around you right now: light on a wall, a color, a face. Describe it.
- One word: Write one word for how much energy you have this hour.
- One line: Write one sentence you'd be glad to have someone read over your shoulder.
- Do: Do one thing this hour in plain view: send it, wear it, say it, share it.

### Hour read
- Good for: being seen, creative work, confidence, asking for recognition, play, anything you want to shine.

---

## Moon

### Day questions
1. Which way is my tide running today, coming in or going out, and what does that ask of the day?
2. What does my body want today that I keep overriding?
3. Who did I really listen to this week, and who really listened to me?
4. What feeling has been passing through lately, and what is it saying on its way?

### Day ladder
- Look: Name one thing around you that belongs to the Moon: water, a soft blanket, someone being cared for, the mood of a room. Describe it.
- Catch: Write one honest line about which way your tide is running today, and mark it ☽ in the margin.
- Feel: What does your body feel like right now, before you think about it?
- Lean: Have you been swept away by feelings lately, or numb to them? What would help: giving the feeling a shape, or a little softness?
- Do: Before bed, do one comforting thing on purpose: a warm drink, an early night, a call to someone who lets you be soft.

### Day read
- Meaning: The Moon's day is for following your own tides: going out when you're full and turning inward when you're not, without treating either as a problem. It belongs to home, the body, sleep and dreams, and to caring and being cared for. No mood is final just because you're inside it.
- Qualities: tender, changeable, intuitive, nurturing, protective, dreamy, soft
- Watch for: moods turning, cravings, small acts of care, a memory surfacing, a dream remembered.
- Too much: drowning in feeling, or carrying everyone else's. The way back: give the feeling a container; name it and write it down.
- Too little: numbness, cut off from feeling and intuition. The way back: let pleasure, beauty and the body reopen feeling gently.

### Hour questions
1. What am I feeling right now, before I find a reason for it?
2. What would comfort me this hour, and can I give it to myself?
3. Who could I check on gently before this hour ends?

### Hour ladder
- Look: Notice one thing around you that's soft, quiet or watery. Describe it.
- One word: Write one word for the feeling in your chest right now.
- One line: Write one line about what your body is asking for.
- Do: Give your body one thing it wants this hour: water, food, rest, a stretch.

### Hour read
- Good for: rest, home, cooking, caring for someone, dreams and hunches, listening.

---

## Mars

### Day questions
1. What hard thing have I been circling, and what would it take to do it today?
2. What did my anger point to this week, and what was it guarding?
3. Where did I say yes when I meant no, and what would the clean no sound like?
4. Who needs someone to stand beside them right now, and could that be me, for them or for myself?

### Day ladder
- Look: Name one thing you've seen today that belongs to Mars: a sharp tool, a deadline, someone standing their ground, a flash of temper. Describe it.
- Catch: Write one line about a boundary that held today, or a small courage, and mark it ♂ in the margin.
- Feel: Where is there heat in you right now, and what's it about?
- Lean: Have you been running too hot, or swallowing every no? What would bring you back: a pause to feel first, or a reminder that you're worth defending?
- Do: Before the day is out, do the thing you've been circling, or say one clean no.

### Day read
- Meaning: Mars's day is for the joys on the far side of fear: the hard conversation, the clean no, a body used well. Anger is information; it points to something that needs guarding, and you are one of the things worth guarding.
- Qualities: bold, decisive, energetic, direct, protective, fierce
- Watch for: boundaries held or crossed, friction, a flash of anger and what it was protecting, small courage, someone defending someone else.
- Too much: rage, recklessness, force without feeling. The way back: ask what the anger is protecting, and let feeling decide how much force is needed.
- Too little: no boundaries, never saying no, anger swallowed until it turns inward. The way back: remember you're worth defending.

### Hour questions
1. What's the one hard thing I could do in the next hour?
2. What am I angry about, said plainly in one sentence?
3. Where do I need to say no, and to whom?

### Hour ladder
- Look: Find one thing around you that's sharp, hot or red. Describe it.
- One word: Write one word for what you'd fight for right now.
- One line: Write the no you've been holding back, as one sentence. You don't have to send it.
- Do: Use this hour for one hard thing: the call, the email, the workout, the conversation.

### Hour read
- Good for: hard tasks, exercise, cutting things out, decisions, standing up for someone, starting something difficult.

---

## Mercury

### Day questions
1. What message, coincidence or bit of luck found me this week, and what did it seem to be saying?
2. What did I learn recently that I didn't know before, and who could I tell?
3. What exchange in my life feels uneven right now, and what would make it fair?
4. What belief am I holding a little too tightly, and what would loosening it let in?

### Day ladder
- Look: Name one thing you've noticed today that belongs to Mercury: a message, a detour, a word that made you smile, a stranger. Describe it.
- Catch: Write one line about a coincidence, or a message that arrived right on time, and mark it ☿ in the margin.
- Feel: Where are you quick today, and where are you scattered?
- Lean: Too many roads open at once, or stuck on one? Finish one small thing, or take one small step somewhere new.
- Do: Before the day ends, take a different road, write to someone, or reread an old page of the notebook and answer it.

### Day read
- Meaning: Mercury's day is for curiosity, words, roads and doorways. Learn something, talk to someone new, take the long way round. Hold what you believe loosely enough that the world can correct it; there's almost always another road. It's a good day to reread what you wrote before, and answer it.
- Qualities: quick, curious, witty, versatile, restless, playful, adaptable
- Watch for: messages arriving, coincidences, wordplay, detours, small luck, misunderstandings, deals, a moment you translated between people.
- Too much: scatter, evasion, cleverness that cuts. The way back: finish one thing, and let cleverness serve kindness.
- Too little: stuck, silent, afraid of change. The way back: take one small step out into the bigger world.

### Hour questions
1. What do I need to say, write or send before this hour is up?
2. What am I curious about right now, and where could I look?
3. What could I reread from earlier in the notebook, and how would I answer it now?

### Hour ladder
- Look: Find one word around you, on a sign, a label, a screen, and write it down.
- One word: Write one word for what's on your mind.
- One line: Write one line fast without stopping, and see where the pen goes.
- Do: Send the message, make the call, or reread and answer one old page.

### Hour read
- Good for: writing, messages, learning, errands, short trips, trading, games, opening the notebook.

---

## Jupiter

### Day questions
1. What do I want, bigger than I've let myself say, and who could I say it to?
2. What good fortune found me lately, and how could I pass some along?
3. Who has offered to help me, and have I let them?
4. What am I celebrating this week, even if it's small?

### Day ladder
- Look: Name one thing you've seen today that belongs to Jupiter: a generous act, a full table, a teacher, something growing. Describe it.
- Catch: Write one line about something you gave away, or something that found you, and mark it ♃ in the margin.
- Feel: Where in your life do you feel plenty right now, and where do you feel scarce?
- Lean: Too much lately, or too little? Ask what would be enough, or notice what's already here.
- Do: Before the day ends, feed someone, give something away, or say a big want where someone can hear it.

### Day read
- Meaning: Jupiter's day is for joy that grows when it's shared: hosting, giving, celebrating small things, hoping out loud. Want big. Let others give to you too; receiving keeps the gift moving. The world answers what you want, though it doesn't take orders.
- Qualities: generous, optimistic, expansive, wise, hospitable, abundant
- Watch for: generosity moving between people, good fortune, someone helped along, celebration, growth, fairness or its absence.
- Too much: greed, overindulgence, giving so constantly no one can give back. The way back: ask what's enough.
- Too little: scarcity, cynicism, thinking small. The way back: notice the plenty already here, and let gratitude open your hand.

### Hour questions
1. What's the biggest version of what I want, said out loud this hour?
2. What could I give away in the next hour: a thing, a compliment, my time?
3. Where could I ask for help, or say yes to it?

### Hour ladder
- Look: Find one thing around you that's plentiful. Describe it.
- One word: Write one word for something you're hoping for.
- One line: Write your big want in one sentence, as if it were possible.
- Do: Give something this hour: a tip, a thank-you, a compliment, a lucky find passed along.

### Hour read
- Good for: asking, giving, teaching and learning, planning big, celebrating, anything to do with growth or luck.

---

## Venus

### Day questions
1. What did I savor this week, slowly, and did I say thank you while it was happening?
2. Where could I make my life a little more beautiful today?
3. What's broken between me and someone, and what's one small step toward mending it?
4. What pleasure have I been keeping from myself, and why?

### Day ladder
- Look: Name one beautiful thing you've seen today, however small. Describe it.
- Catch: Write one line about something sweet you noticed while it was happening, with a thank-you, and mark it ♀ in the margin.
- Feel: What is your body enjoying right now: warmth, texture, taste, rest?
- Lean: Has pleasure been an escape lately, or missing altogether? Let it be a choice again, or let yourself have some.
- Do: Before the day ends, savor one thing slowly, set a table, bring home flowers, or take one step toward mending something.

### Day read
- Meaning: Venus's day is for savoring: tasting the peach instead of just eating it, clean sheets, warm light, a song played loud. Pleasure needs no justification. It's also the day of love and kindness, and of mending what's broken between people.
- Qualities: loving, sensual, gracious, artistic, harmonious, peacemaking
- Watch for: beauty in passing, sweetness, flirtation, music, a rift mended, a kindness that told the truth, a moment worth savoring.
- Too much: compulsion, pleasure as escape, pleasing people until you're lost in them. The way back: love as yourself, not instead of yourself, and let pleasure stay a choice.
- Too little: joylessness, believing you don't deserve beauty or love. The way back: be as generous with yourself as you'd be with a friend.

### Hour questions
1. What could I enjoy slowly in the next hour?
2. Who do I love, and what would I want them to know today?
3. What small thing could I make more beautiful before this hour ends?

### Hour ladder
- Look: Find one beautiful thing within reach. Describe it in detail.
- One word: Write one word for what you're enjoying right now, or would like to.
- One line: Write one thank-you for something good, while it's still happening.
- Do: Savor something this hour: a drink, a song, a scent, a slow minute.

### Hour read
- Good for: love, friendship, art, beauty, pleasure, making peace, anything you want to go sweetly.

---

## Saturn

### Day questions
1. What's one thing I could finish today, and what has leaving it open been costing me?
2. Which promises to myself did I keep this week, and which am I ready to release?
3. What's ready to end, and can I let it?
4. What do I rely on that needs tending: a tool, a routine, my body, a friendship?

### Day ladder
- Look: Name one thing you've seen today that belongs to Saturn: something old, a clock, a wall, something made well. Describe it.
- Catch: Write one line about one thing finished, or one thing allowed to end, and mark it ♄ in the margin.
- Feel: Where are you tired in a way that needs real rest, not a reward?
- Lean: Too rigid and hard on yourself lately, or nothing getting finished? Loosen your grip with a little hope, or finish one thing and then rest.
- Do: Before the day ends, finish one small thing, tend one tool, and then rest properly.

### Day read
- Meaning: Saturn's day is slow and careful: finishing what matters, keeping promises, tending what you rely on, and resting without having to earn it. Limits give things their shape. Endings are allowed; pruning is how things grow.
- Qualities: deliberate, patient, disciplined, steadfast, serious, enduring
- Watch for: waiting and delays, rules, things made well, promises kept or slipping, endings, quiet, a structure that held.
- Too much: rigidity, harshness, self-punishment, despair that calls itself realism. The way back: hope loosens the grip; you're allowed to fail and begin again.
- Too little: broken promises, nothing finished, no rest. The way back: the resolve to finish one thing, and rest as part of the cycle.

### Hour questions
1. What could I finish in the next hour?
2. What one true sentence do I need to write right now?
3. What's ready to end, and what would a proper goodbye look like?

### Hour ladder
- Look: Find one old or well-made thing near you. Describe it.
- One word: Write one word for what feels heavy right now.
- One line: Write one true sentence, and stop there.
- Do: Finish one small thing this hour, then rest for a few minutes.

### Hour read
- Good for: finishing, tidying, budgets and plans, keeping promises, endings, quiet work, rest.
