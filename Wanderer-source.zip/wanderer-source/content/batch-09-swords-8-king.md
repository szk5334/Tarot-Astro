# Swords: Eight to King

Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position), 14 watch-for
cues (one per day planet, each orientation), a low-tide pointer, its lit lines, and its essence
(a short phrase per orientation and a figure).

The Eight, Nine and Ten each hold ten degrees of Gemini. The Page shares the air quarter of the
year with the Ace. The Knight, Queen and King each hold a 30° stretch across two signs. The Nine
(worry in the night) and the Ten (the bottom) stay kind: the Ten's low-tide figure is the dawn on
its horizon.

---

## Eight of Swords
sky: Jupiter in Gemini, 0–10° Gemini · season: about May 21 – May 31 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: Where do I feel trapped right now, and which of the swords around me are actually holding me in?
2. Cross / boon: Is this tight spot the passage I have to walk through, or a story about being stuck that I keep telling?
3. Root: When did I first learn to stand still and wait to be rescued?
4. Passing away: What restriction is loosening, and what did it teach me about my own limits?
5. Front of mind: What am I telling myself I can't do, and is it true?
6. Coming in: What way out is opening, and would I see it if I lifted the blindfold an inch?
7. Who you are: Where am I more free in this than I feel?
8. What surrounds you: Who around me could help me see the gap, if I asked?
9. Hopes / fears: What do I hope would happen if someone untied me, and what am I afraid I'd find if I walked out on my own?
10. Outcome: If I stay where I'm standing, what happens, and which belief about being stuck would I need to drop to take the first step?

### Reversed
1. Central theme: Where am I starting to walk out of a trap, one step at a time?
2. Cross / boon: Is fear of what's outside what's in the way, or am I already free and haven't believed it yet?
3. Root: Who first told me I couldn't, and why did I believe them?
4. Passing away: What old limit am I ready to step past?
5. Front of mind: What way out keeps showing up in my thoughts?
6. Coming in: What freedom is arriving, and how will I use it?
7. Who you are: Where have I already taken the blindfold off without noticing?
8. What surrounds you: Who around me is still caught, and what have I learned that might help them?
9. Hopes / fears: If I found out the ring of swords was never closed, what would I have to admit about why I stood still?
10. Outcome: If I keep stepping out, where does it lead, and which first step can I take today?

### Watch for
Upright
- Sun: Watch for a moment you shrink because you think you have to.
- Moon: Watch for the feeling of being stuck, and where in your body it sits.
- Mars: Watch for the one small step you could take right now, and take it.
- Mercury: Watch for the words "I can't," and test one of them.
- Jupiter: Watch for a way out bigger than the one you were looking for.
- Venus: Watch for help offered kindly, and let it loosen something.
- Saturn: Watch for a rule you follow that nobody is enforcing anymore.

Reversed
- Sun: Watch for the moment you realize you can simply leave.
- Moon: Watch for relief arriving in your body as something loosens.
- Mars: Watch for the nerve to say "no more."
- Mercury: Watch for a new way of describing your situation that sets you free.
- Jupiter: Watch for options you didn't know you had.
- Venus: Watch for someone who reminds you of who you were before the trap.
- Saturn: Watch for a limit that was real once and isn't now.

### Low tide
- Notice: the gap in the ring of swords, and that her feet are free.
- Become: the woman in the blindfold. What would happen if you took one step?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Gemini), so feeling trapped by your own thoughts, and finding the way out, are a lifelong thread for you. Answer about the traps you've walked out of.
- Touching you: Jupiter, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so room to grow is part of today's question. Answer about the freedom you have that you haven't used.
- Its season: The Sun is in this card's ten days of the year, about May 21 to 31, late spring heading into summer. Answer about where you feel boxed in.
- Today's weather: {planet} {is} passing through the first ten degrees of Gemini, this card's slice of the sky, so a trapped feeling is close today. Answer about which sword is really holding you.
- The long season: {planet} {is} moving through the first ten degrees of Gemini for months or years, an era of untangling your thoughts. Answer about the trap you're slowly walking out of.
- Turning: Jupiter, this card's planet, is retrograde (seeming to move backward), a time when growth turns inward. Answer about a freedom inside you that's waiting to be used.

### Essence
- Upright: the ring of swords with a gap in it
- Reversed: walking out, one step at a time
- Figure: the bound woman

---

## Nine of Swords
sky: Mars in Gemini, 10–20° Gemini · season: about Jun 1 – Jun 10 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What worry has been keeping me up, and what does it sound like at three in the morning?
2. Cross / boon: Is this anxiety a hard stretch I'm passing through, or a loop I keep walking in the dark?
3. Root: When did I first learn to lie awake running through what could go wrong?
4. Passing away: What fear is losing its grip, now that I've looked at it in daylight?
5. Front of mind: What am I worrying about on purpose, as if worrying were the same as preparing?
6. Coming in: What's coming that I'm dreading, and how much of the dread is about the thing itself?
7. Who you are: Where am I harder on myself in the dark than I'd ever be in daylight?
8. What surrounds you: Who could I tell about this worry, plainly, tomorrow?
9. Hopes / fears: What do I hope I'll feel when this fear is gone, and what am I afraid is actually true?
10. Outcome: If I keep feeding this worry at night, what happens to my days, and what one fear would I say out loud to someone to shrink it?

### Reversed
1. Central theme: Where is a night fear starting to lift, or turning into a quieter, steadier worry?
2. Cross / boon: Is shame what's in the way, or a fear I haven't told anyone?
3. Root: What old nightmare still visits me, and what is it trying to finish?
4. Passing away: What worry am I finally ready to put down for the night?
5. Front of mind: What worst-case story keeps playing, and what's the ordinary version?
6. Coming in: What help is coming, if I let it in?
7. Who you are: Where am I worrying alone about something others would gladly help carry?
8. What surrounds you: Who around me lies awake too, and could we talk about it?
9. Hopes / fears: If I said the three a.m. worry out loud over breakfast, what am I afraid would happen to it, or to me?
10. Outcome: If I keep the fear to myself, what does it cost me, and who would I tell first?

### Watch for
Upright
- Sun: Watch for a worry that looks smaller in daylight, and notice how much smaller.
- Moon: Watch for how you sleep, and what helps you settle.
- Mars: Watch for the one practical thing you could do about the worry, and do it.
- Mercury: Watch for the exact sentence your worry keeps saying, and write it down.
- Jupiter: Watch for reassurance you can actually believe.
- Venus: Watch for something soothing before bed: warm light, soft sound, a kind word.
- Saturn: Watch for a worry that's been answered already and keeps coming back anyway.

Reversed
- Sun: Watch for pretending to be fine all day after a bad night.
- Moon: Watch for tension in your chest or jaw, and breathe out slowly.
- Mars: Watch for irritability from too little sleep, and go easy on yourself.
- Mercury: Watch for late-night doom-reading, and put the phone face down.
- Jupiter: Watch for a small worry being blown up into a big one.
- Venus: Watch for guilt you don't owe anyone.
- Saturn: Watch for a fear that needs a professional ear, and let yourself ask for one.

### Low tide
- Notice: the quilt covered in roses and the symbols of the zodiac, there on the bed even in the dark.
- Become: the quilt. What do you want to tell the one sitting up under you?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Gemini), so worry, a busy mind at night, and learning to settle it are a lifelong thread for you. Answer about what has helped you rest.
- Touching you: Mars, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so restlessness and friction are part of today's question. Answer about the fear behind the restlessness.
- Its season: The Sun is in this card's ten days of the year, about June 1 to 10, early summer, with short nights and long days. Answer about what's keeping you up.
- Today's weather: {planet} {is} passing through the middle ten degrees of Gemini, this card's slice of the sky, so worry runs closer to the surface today. Answer about the fear you can name now.
- The long season: {planet} {is} moving through the middle ten degrees of Gemini for months or years, an era of anxious thinking. Answer about the worry you're slowly learning to put down.
- Turning: Mars, this card's planet, is retrograde (seeming to move backward), a time when old worries resurface. Answer about a fear you've faced before and can face again.

### Essence
- Upright: the worry at three in the morning
- Reversed: the night fear lifting
- Figure: the one sitting up in bed

---

## Ten of Swords
sky: Sun in Gemini, 20–30° Gemini · season: about Jun 11 – Jun 20 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What has reached its end lately, the worst of it, and what tells me it can't get any lower?
2. Cross / boon: Is this ending the floor I can finally push up from, or am I lying here longer than I need to?
3. Root: What earlier low point did I come back from, and what got me up?
4. Passing away: What painful chapter is finally, fully over?
5. Front of mind: What am I deliberately letting be over, so it can stop hurting?
6. Coming in: What dawn is coming, even if I can only see a sliver of it?
7. Who you are: Where have I taken more than my share of blows in this, and who could help me up?
8. What surrounds you: Who around me has hit bottom too, and what did they find there?
9. Hopes / fears: What do I hope is waiting after this, and what am I afraid will keep happening?
10. Outcome: If I let this be the end of it, what begins, and what would I need to stop going over so the light can come in?

### Reversed
1. Central theme: Where am I starting to get up after a hard fall, slowly?
2. Cross / boon: Is reliving it what's in the way, or am I recovering faster than I let myself believe?
3. Root: What old defeat do I keep returning to, as if it still decided who I am?
4. Passing away: What wound am I ready to let close?
5. Front of mind: Which scene from the fall do I keep rewinding, and what would happen if I let the tape run out?
6. Coming in: What healing is arriving now that the worst is behind me?
7. Who you are: Where am I stronger for having been flattened?
8. What surrounds you: Who around me helped pull a sword out, and have I thanked them?
9. Hopes / fears: If the worst truly is behind me, what am I afraid I'll have to face in the daylight?
10. Outcome: If I keep getting up like this, where do I stand, and what's the first thing I want to do with the daylight?

### Watch for
Upright
- Sun: Watch for the first light after a dark stretch, and turn toward it.
- Moon: Watch for exhaustion that needs real care: food, sleep, company.
- Mars: Watch for the urge to keep fighting a battle that's already over.
- Mercury: Watch for the words "it's over," and let them be a relief.
- Jupiter: Watch for one small sign that things are beginning again.
- Venus: Watch for kindness that reaches you when you're down.
- Saturn: Watch for the ending that makes room, and let it.

Reversed
- Sun: Watch for your own laugh, the real one, and notice it's back.
- Moon: Watch for your body recovering, and support it.
- Mars: Watch for strength coming back, a little at a time.
- Mercury: Watch for telling the story of the fall as something you came through.
- Jupiter: Watch for help that shows up now that you can take it.
- Venus: Watch for small pleasures returning: taste, music, laughter.
- Saturn: Watch for the lesson that's left once the pain is gone.

### Low tide
- Notice: the strip of gold dawn along the horizon, and how calm the water is.
- Become: the dawn. What are you about to show them when you rise?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Gemini), so endings, hitting bottom and getting back up are a lifelong thread for you. Answer about the times you've risen again.
- Touching you: The Sun, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few days, so attention and energy are shining on part of your life. Answer about where you're ready to stand up again.
- Its season: The Sun is in this card's ten days of the year, about June 11 to 20, the last days before the longest day of the year. Answer about what's finally over.
- Today's weather: {planet} {is} passing through the last ten degrees of Gemini, this card's slice of the sky, so an ending is close to the surface today. Answer about what you're done with now.
- The long season: {planet} {is} moving through the last ten degrees of Gemini for months or years, an era of endings and starting over. Answer about the life you're slowly rebuilding.

### Essence
- Upright: the worst over, dawn on the horizon
- Reversed: getting up again
- Figure: the dawn

---

## Page of Swords
sky: the air quarter of the year, Capricorn through Pisces · season: about Dec 22 – Mar 20 · lit by: Its season

### Upright
1. Central theme: What new idea or question has hold of my mind lately?
2. Cross / boon: Is this sharp curiosity what gets me to something new, or am I darting at every idea that blows past?
3. Root: When was I first the kid asking "but why?", and what happened to those questions?
4. Passing away: What phase of watching and learning is ending, and what did I notice?
5. Front of mind: What am I deliberately studying or keeping an eye on right now?
6. Coming in: What news, information or new way of thinking is arriving?
7. Who you are: Where am I the alert one in this, watching how things move?
8. What surrounds you: Who around me asks the questions nobody else will?
9. Hopes / fears: What do I hope to find out, and what am I afraid I'll learn?
10. Outcome: If I keep following this question, where does it lead, and what would I need to stop assuming to keep learning?

### Reversed
1. Central theme: Where am I all talk and no follow-through, or watching so closely it's turned into suspicion?
2. Cross / boon: Is gossip what's in the way, or a question I'm too nervous to ask?
3. Root: What got me in trouble for speaking up as a kid?
4. Passing away: What half-formed opinion am I ready to drop?
5. Front of mind: What am I arguing in my head before I know the facts?
6. Coming in: What's coming that will test whether I can listen before I speak?
7. Who you are: Where am I defensive about not knowing?
8. What surrounds you: Who around me spreads more noise than news?
9. Hopes / fears: If I said "I don't know" in front of the people I want to impress, what would I be afraid they'd think?
10. Outcome: If I keep scattering my attention, what slips past me, and which one question would I follow all the way?

### Watch for
Upright
- Sun: Watch for the idea you can't stop talking about, and find someone who wants to hear it.
- Moon: Watch for a hunch that wants checking.
- Mars: Watch for a debate you'd actually enjoy.
- Mercury: Watch for news, a fact or a phrase that makes you curious.
- Jupiter: Watch for a subject you'd love to learn properly.
- Venus: Watch for a remark that's clever and kind at once, and make one.
- Saturn: Watch for the patience to learn something step by step.

Reversed
- Sun: Watch for correcting people to look clever.
- Moon: Watch for restless thoughts that won't settle.
- Mars: Watch for picking an argument just to feel sharp.
- Mercury: Watch for passing on something you haven't checked.
- Jupiter: Watch for big conclusions drawn from little facts.
- Venus: Watch for sarcasm that bites harder than you meant.
- Saturn: Watch for a promise to follow up that you haven't kept.

### Low tide
- Notice: the wind-bent trees and the birds scattered across the sky, and how he looks back over his shoulder.
- Become: one of the birds overhead. What do you see him watching for?

### Lit
- Its season: The Sun is in this card's quarter of the year, Capricorn through Pisces, about December 22 to March 20: winter, the clear, cold season of air. Answer about a new question that's sharpening your mind.

### Essence
- Upright: the sharp new question
- Reversed: the mind darting everywhere
- Figure: the watchful page

---

## Knight of Swords
sky: 20° Taurus to 20° Gemini (the fiery part of Air) · season: about May 10 – Jun 10 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What am I charging toward right now, full speed, and what's driving me?
2. Cross / boon: Is this rush of conviction what gets me across, or am I going so fast I'll miss the turn?
3. Root: When did I first feel the thrill of being completely sure, and where did that certainty take me?
4. Passing away: What campaign or crusade is winding down, and what did all that speed get me?
5. Front of mind: What am I deliberately going after right now, and how sure am I?
6. Coming in: What challenge is arriving that will need quick thinking?
7. Who you are: Where am I the one who says it first and fastest, and is that helping?
8. What surrounds you: Who's standing in the road ahead of me, and will they get out of the way or get run over?
9. Hopes / fears: What do I hope this charge will win, and what am I afraid of leaving behind in the dust?
10. Outcome: If I keep riding this fast, where do I end up, and what would I slow down for so I arrive somewhere worth reaching?

### Reversed
1. Central theme: Where am I rushing headlong without a plan, or stalled when I meant to charge?
2. Cross / boon: Is impatience what's in the way, or an argument I'm determined to win?
3. Root: What early rush got me into trouble, and what did I learn?
4. Passing away: What crusade am I ready to give up?
5. Front of mind: What argument am I rehearsing that I don't need to have?
6. Coming in: What's waiting just over the next hill that I'll want to have thought about before I gallop into it?
7. Who you are: Where am I cutting people off, in conversation or in life?
8. What surrounds you: Who around me is going too fast, and dragging me along?
9. Hopes / fears: If I reined in and let the other side finish talking, what am I afraid I'd hear?
10. Outcome: If I keep charging blind, what do I crash into, and what one thing would I check before I go on?

### Watch for
Upright
- Sun: Watch for the chance to argue for something you believe, in front of people who matter.
- Moon: Watch for adrenaline in your body, and what it's for.
- Mars: Watch for the split second when hesitating would cost more than being wrong.
- Mercury: Watch for a sharp argument you could make clearly and fairly.
- Jupiter: Watch for a cause worth charging toward.
- Venus: Watch for someone you could carry along instead of leaving behind.
- Saturn: Watch for the one bit of planning that keeps speed from becoming a crash.

Reversed
- Sun: Watch for needing to be first.
- Moon: Watch for a racing heart, and slow your breath.
- Mars: Watch for rudeness in a hurry.
- Mercury: Watch for interrupting.
- Jupiter: Watch for overconfidence about how well you know something.
- Venus: Watch for bulldozing someone you care about.
- Saturn: Watch for a rash decision you could still undo.

### Low tide
- Notice: the trees bent by the wind, the birds scattering, and the horse's open mouth.
- Become: the galloping horse. Do you know where you're going?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Taurus to 20° Gemini), so ambition, speed and saying what you think are a lifelong thread for you. Answer about where your convictions have carried you.
- Its season: The Sun is in this card's stretch of the year, about May 10 to June 10, late spring at full speed. Answer about what you're racing toward.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Taurus into Gemini, so the urge to charge is strong today. Answer about the move you want to make now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Taurus into Gemini, for months or years, an era of fast change and strong opinions. Answer about the direction you've been rushing in.

### Essence
- Upright: the full-speed charge
- Reversed: the charge with no map
- Figure: the galloping horse

---

## Queen of Swords
sky: 20° Virgo to 20° Libra (the watery part of Air) · season: about Sep 12 – Oct 12 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What do I see clearly right now that others are missing, and how do I want to say it?
2. Cross / boon: Is my honesty what helps everyone across, or am I so clear-eyed I've forgotten to be warm?
3. Root: What hard experience taught me to see through things, and what did it cost me?
4. Passing away: What illusion have I lost, and what clarity did it leave me with?
5. Front of mind: What am I deliberately cutting through right now, and why?
6. Coming in: What situation is arriving that will need a clear head and a straight answer?
7. Who you are: Where am I the one who tells it like it is in this?
8. What surrounds you: Who around me needs the truth from me, said kindly?
9. Hopes / fears: What do I hope my honesty protects, and what am I afraid it pushes away?
10. Outcome: If I keep speaking this plainly, what changes around me, and what softness would I let in so the truth can be heard?

### Reversed
1. Central theme: Where has my clarity turned cold, or where am I letting someone talk me out of what I see?
2. Cross / boon: Is bitterness what's in the way, or a boundary I haven't set?
3. Root: What hurt made me sharper than I needed to be?
4. Passing away: What old judgment am I ready to soften?
5. Front of mind: What critique of someone keeps sharpening in my head?
6. Coming in: Who is about to need the truth from me, and how do I hold out both the sword and the open hand?
7. Who you are: Where am I keeping people at sword's length?
8. What surrounds you: Who around me cuts with words, and do I cut back?
9. Hopes / fears: If I lowered the sword and let someone see where it hurts, what am I afraid they'd do?
10. Outcome: If I stay this guarded, who stops getting close, and what one boundary would I set clearly instead of sharply?

### Watch for
Upright
- Sun: Watch for a moment to state your view plainly and stand by it.
- Moon: Watch for what your hard-won experience tells you here.
- Mars: Watch for a boundary that needs saying, and say it cleanly.
- Mercury: Watch for the clear, simple sentence that cuts through confusion.
- Jupiter: Watch for wisdom you can offer from what you've lived through.
- Venus: Watch for honesty that's also tender.
- Saturn: Watch for the discipline of saying only what's true.

Reversed
- Sun: Watch for coldness used to look strong.
- Moon: Watch for old grief making you sharp.
- Mars: Watch for criticism that's really a wound.
- Mercury: Watch for a cutting remark, and swallow one.
- Jupiter: Watch for judging people by your worst experience.
- Venus: Watch for warmth withheld to stay safe.
- Saturn: Watch for standards so strict nobody can meet them, including you.

### Low tide
- Notice: her raised, open hand, and the single bird flying high above her.
- Become: the bird high above. What can you see of her life from up there?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Virgo to 20° Libra), so clear judgment, honesty and wisdom earned from experience are a lifelong thread for you. Answer about what you've learned to see clearly.
- Its season: The Sun is in this card's stretch of the year, about September 12 to October 12, the turn from summer into fall. Answer about what has come clear this season.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Virgo into Libra, so clear judgment is needed today. Answer about what you see plainly now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Virgo into Libra, for months or years, an era of hard-won clarity. Answer about the truth you're slowly learning to tell kindly.

### Essence
- Upright: the clear eye and the open hand
- Reversed: clarity gone cold
- Figure: the bird above her

---

## King of Swords
sky: 20° Capricorn to 20° Aquarius (the airy part of Air) · season: about Jan 10 – Feb 8 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What decision rests with me right now, and what facts am I standing on?
2. Cross / boon: Is my reasoning what gets everyone across, or am I so logical I've left the people out?
3. Root: Who first showed me what fair, clear authority looks like?
4. Passing away: What judgment have I made that's now settled, and what did it teach me?
5. Front of mind: What am I deliberately thinking through to the end, without flinching?
6. Coming in: Whose case is about to land on my desk, and what do I need to hear from both sides?
7. Who you are: Where am I the one others trust to be fair in this?
8. What surrounds you: Who around me deserves a clear answer from me?
9. Hopes / fears: What do I hope my good judgment will build, and what am I afraid of getting wrong?
10. Outcome: If I keep deciding this way, what does it build, and what feeling would I need to include so the decision is truly fair?

### Reversed
1. Central theme: Where am I using reason to win rather than to understand, or avoiding a decision that's mine to make?
2. Cross / boon: Is rigid thinking what's in the way, or someone else's authority I keep deferring to?
3. Root: Who used cold logic against me once, and do I use it now?
4. Passing away: Which of my firm opinions has quietly stopped fitting the facts?
5. Front of mind: What case am I building just to prove I'm right?
6. Coming in: What decision is coming where the right answer and the kind answer might not match?
7. Who you are: Where am I hiding behind the facts?
8. What surrounds you: Who around me misuses their authority, and where's my line?
9. Hopes / fears: If I stood up and reversed my own verdict in front of everyone, what am I afraid it would cost me?
10. Outcome: If I keep ruling by logic alone, what gets missed, and what one feeling would I let into the decision?

### Watch for
Upright
- Sun: Watch for a moment to take responsibility for a decision openly.
- Moon: Watch for the feeling underneath a logical choice, and include it.
- Mars: Watch for a firm decision that's been waiting, and make it.
- Mercury: Watch for the fairest way to say a hard thing.
- Jupiter: Watch for a principle bigger than the moment, and stand on it.
- Venus: Watch for fairness that leaves everyone's dignity intact.
- Saturn: Watch for the rules that serve, and the ones that only control.

Reversed
- Sun: Watch for needing to be the smartest one in the room.
- Moon: Watch for a feeling dismissed because it isn't logical.
- Mars: Watch for authority used to end a conversation.
- Mercury: Watch for arguing on a technicality.
- Jupiter: Watch for a judgment made too fast and too wide.
- Venus: Watch for coldness mistaken for fairness.
- Saturn: Watch for a rule enforced past its purpose.

### Low tide
- Notice: the butterflies carved on his throne, and how his sword tips just slightly to one side.
- Become: the king. What are you about to decide, and how did you reach it?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Capricorn to 20° Aquarius), so clear thinking, fairness and authority are a lifelong thread for you. Answer about the judgments you've learned to make.
- Its season: The Sun is in this card's stretch of the year, about January 10 to February 8, deep winter, clear and cold. Answer about the decision in front of you.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Capricorn into Aquarius, so judgment and decisions are in focus today. Answer about the call you need to make now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Capricorn into Aquarius, for months or years, an era of hard decisions and clear thinking. Answer about the authority you're slowly growing into.

### Essence
- Upright: the fair, clear verdict
- Reversed: logic used as a weapon
- Figure: the king with the upright sword
