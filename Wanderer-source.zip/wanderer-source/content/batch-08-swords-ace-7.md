# Swords: Ace to Seven

Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position), 14 watch-for
cues (one per day planet, each orientation), a low-tide pointer, its lit lines, and its essence
(a short phrase per orientation and a figure).

Swords are the suit of air: thought, truth, words, conflict and worry. These hold some of the
deck's hardest cards (heartbreak, a bitter win, a secret), so the questions stay kind: no blame,
no verdicts, room to rest. The Ace holds the air quarter of the year (winter). The Two, Three
and Four each hold ten degrees of Libra; the Five, Six and Seven each hold ten degrees of
Aquarius.

---

## Ace of Swords
sky: the air quarter of the year, Capricorn through Pisces · season: about Dec 22 – Mar 20 · lit by: Its season

### Upright
1. Central theme: What has suddenly come clear to me lately, and what does seeing it this sharply change?
2. Cross / boon: Is this clarity the bridge from what's ending to what's beginning, or am I swinging it at everything in my way?
3. Root: When did the truth first set me free: a moment when someone said it plainly, or I did?
4. Passing away: What confusion is lifting, and what did the fog teach me before it went?
5. Front of mind: What am I deliberately thinking through right now, and what's the cleanest way to say it?
6. Coming in: What new idea, decision or plain truth is about to arrive?
7. Who you are: Where am I the clearest head in the room, and how do I use that?
8. What surrounds you: Who around me tells me the truth even when it's uncomfortable?
9. Hopes / fears: What do I hope the truth will free me from, and what am I afraid it will cut?
10. Outcome: If I keep following this clear thought, where does it take me, and what would I need to stop telling myself to keep it clear?

### Reversed
1. Central theme: Where is my thinking clouded right now, or where am I using the truth as a weapon?
2. Cross / boon: Is confusion what's in the way, or a hard truth I won't pick up?
3. Root: What truth was I punished for telling once, and does that keep me quiet now?
4. Passing away: What half-truth am I ready to stop repeating?
5. Front of mind: What thought keeps circling without landing anywhere?
6. Coming in: What conversation is about to need the sword drawn straight: no hedging, no softening first?
7. Who you are: Where am I being harsh and calling it honest?
8. What surrounds you: Whose voice around me makes it harder to think straight, and how much room do I give it?
9. Hopes / fears: If my words came out as sharp and clear as I mean them, who would I be afraid of cutting?
10. Outcome: If I stay this unclear, what's left undecided, and what one plain sentence would cut through?

### Watch for
Upright
- Sun: Watch for a moment to say what you think, plainly and in full view.
- Moon: Watch for the clear-headed calm that comes after a feeling passes.
- Mars: Watch for the knot you've been untangling for weeks, and whether it would be kinder to cut it.
- Mercury: Watch for the exact word, and use it.
- Jupiter: Watch for an idea big enough to change how you see something.
- Venus: Watch for an honest word that's also a kind one.
- Saturn: Watch for the truth that's been waiting patiently to be faced.

Reversed
- Sun: Watch for winning an argument at the cost of the point.
- Moon: Watch for thoughts racing at night, and write them down to quiet them.
- Mars: Watch for words used as blades.
- Mercury: Watch for overthinking a simple choice.
- Jupiter: Watch for certainty that has outrun the facts.
- Venus: Watch for sugarcoating something that needs saying straight.
- Saturn: Watch for a harsh inner voice dressed up as realism.

### Low tide
- Notice: the crown at the sword's tip with an olive branch and a palm hanging from it, and the bare mountains below.
- Become: the sword. What are you here to cut through?

### Lit
- Its season: The Sun is in this card's quarter of the year, Capricorn through Pisces, about December 22 to March 20: winter, the clear, cold season of air. Answer about what you're finally seeing plainly.

### Essence
- Upright: the sword held straight up
- Reversed: the blade swung wild
- Figure: the sword

---

## Two of Swords
sky: Moon in Libra, 0–10° Libra · season: about Sep 23 – Oct 2 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What choice am I holding off right now, arms crossed, and what keeps me from deciding?
2. Cross / boon: Is this pause the truce that lets me cross safely, or the blindfold that keeps me in place?
3. Root: When did I first learn that not choosing was safer than choosing wrong?
4. Passing away: What standoff is ending, and what did holding still protect me from?
5. Front of mind: What am I deliberately weighing in my mind, and what does each side cost?
6. Coming in: What's coming that will tip the balance one way or the other?
7. Who you are: Where am I keeping the peace inside myself by refusing to look?
8. What surrounds you: Who around me is waiting for me to choose, and what do they need to know in the meantime?
9. Hopes / fears: What do I hope will happen if I wait long enough, and what am I afraid I'll see if I take the blindfold off?
10. Outcome: If I keep holding these two swords, how long can my arms last, and what would I need to admit to set one down?

### Reversed
1. Central theme: Where is the blindfold slipping, and what can I see now that I couldn't before?
2. Cross / boon: Is too much information what's in the way, or a decision I'm finally ready to make?
3. Root: Who taught me to stay neutral so no one gets upset?
4. Passing away: What truce am I ready to end?
5. Front of mind: What am I overthinking in circles?
6. Coming in: What's coming that will make the choice for me if I don't make it?
7. Who you are: Where am I torn so evenly that it's wearing me out?
8. What surrounds you: Who around me is pulling me to pick their side?
9. Hopes / fears: If I took off the blindfold, chose, and got it wrong, what would I be afraid it would say about me?
10. Outcome: If I keep stalling, what decides for me, and what's the smallest choice I could make today to start?

### Watch for
Upright
- Sun: Watch for a moment to say where you stand, even if it's only for now.
- Moon: Watch for what your gut already knows before you weigh it.
- Mars: Watch for the coin you could flip, and notice which side you're hoping for.
- Mercury: Watch for the one question that would settle it.
- Jupiter: Watch for the bigger picture that makes the choice easier.
- Venus: Watch for a peace you can keep without hiding from yourself.
- Saturn: Watch for a deadline quietly getting closer.

Reversed
- Sun: Watch for sitting on the fence to stay likable.
- Moon: Watch for numbness that comes from avoiding a feeling.
- Mars: Watch for snapping under the strain of not deciding.
- Mercury: Watch for gathering one more opinion instead of trusting your own.
- Jupiter: Watch for making the choice bigger than it is.
- Venus: Watch for keeping the peace with someone at your own expense.
- Saturn: Watch for a "later" that keeps moving further away.

### Low tide
- Notice: the blindfold, and the crescent moon over the rocky water behind her.
- Become: the woman on the bench. What would you see if you took the blindfold off?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Libra), so weighing, holding still and keeping the peace inside are a lifelong thread for you. Answer about how you've learned to make hard choices.
- Touching you: The Moon, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few hours, so your mood is close to the surface. Answer about what you feel under the indecision.
- Its season: The Sun is in this card's ten days of the year, about September 23 to October 2, the first days of fall, when day and night are nearly even. Answer about the choice you're balancing.
- Today's weather: {planet} {is} passing through the first ten degrees of Libra, this card's slice of the sky, so a choice is hanging in the balance today. Answer about the one you're holding off on now.
- The long season: {planet} {is} moving through the first ten degrees of Libra for months or years, an era of weighing and waiting. Answer about the decision you've been slowly coming to.

### Essence
- Upright: the two swords held crossed
- Reversed: the blindfold slipping
- Figure: the blindfolded woman

---

## Three of Swords
sky: Saturn in Libra, 10–20° Libra · season: about Oct 3 – Oct 12 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What hurt has gone into my heart lately, and can I name it plainly?
2. Cross / boon: Is this hurt the hard door I have to walk through to reach what's next, or have I stopped in the doorway?
3. Root: What old heartbreak taught me how my heart heals?
4. Passing away: What pain is beginning to ease, even a little, and what helped?
5. Front of mind: What hurt am I deliberately letting myself feel instead of pushing away?
6. Coming in: What truth is arriving that may sting, and who could sit with me when it does?
7. Who you are: Where am I hurting in this, and where am I already healing?
8. What surrounds you: Who around me is carrying a broken heart too?
9. Hopes / fears: What do I hope will be left when the hurt passes, and what am I afraid it has taken for good?
10. Outcome: If I let this hurt run its course, what does it leave me knowing, and what would I need to stop blaming myself for so it can heal?

### Reversed
1. Central theme: Where is an old hurt still lodged, long after the storm passed?
2. Cross / boon: Is grief I haven't let myself feel what's in the way?
3. Root: What heartbreak did I learn to hide rather than heal?
4. Passing away: What sorrow am I ready to let rain out?
5. Front of mind: Which sentence someone said keeps cutting, every time I remember it?
6. Coming in: What's coming that will help me mend?
7. Who you are: Where am I leaving the swords in because pulling them out would hurt more?
8. What surrounds you: Who around me has helped me heal, or could, if I let them?
9. Hopes / fears: If I let the whole storm rain through me at once, what am I afraid would be left standing?
10. Outcome: If I keep holding this hurt, what does it cost me, and what one small act of care would start the mending?

### Watch for
Upright
- Sun: Watch for a moment to let someone you trust see you hurting.
- Moon: Watch for tears that need to come, and let them.
- Mars: Watch for the urge to armor up, and whether you need the armor today.
- Mercury: Watch for words that cut, and the words that would help them heal.
- Jupiter: Watch for comfort from an unexpected place.
- Venus: Watch for gentle things: soft music, rain on the window, a warm hand.
- Saturn: Watch for the slow mending that's already under way.

Reversed
- Sun: Watch for pretending you're fine when you're not.
- Moon: Watch for sorrow sitting in your chest, and give it somewhere to go.
- Mars: Watch for lashing out where you're sore.
- Mercury: Watch for replaying the painful conversation.
- Jupiter: Watch for keeping busy so you don't have to grieve.
- Venus: Watch for closing your heart to avoid being hurt again.
- Saturn: Watch for blaming yourself for a hurt that wasn't your doing.

### Low tide
- Notice: that there's no one in this card, only the heart, the three swords and the rain.
- Become: the rain. What are you washing away, and what will be clean when you stop?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Libra), so heartbreak, hard truths and the way your heart heals are a lifelong thread for you. Answer about what your hurts have taught you about mending.
- Touching you: Saturn, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so endings and the long haul are part of today's question. Answer about a sorrow that's asking for time.
- Its season: The Sun is in this card's ten days of the year, about October 3 to 12, early fall, when the rains come in. Answer about the hurt you're carrying this season.
- Today's weather: {planet} {is} passing through the middle ten degrees of Libra, this card's slice of the sky, so an ache is close to the surface today. Answer about what hurts now, plainly.
- The long season: {planet} {is} moving through the middle ten degrees of Libra for months or years, an era of grief and slow mending. Answer about the heartache you've been slowly healing.
- Turning: Saturn, this card's planet, is retrograde (seeming to move backward), as it is for about four and a half months each year, a time when old hurts come back to be finished. Answer about a sorrow that's returning to be tended.

### Essence
- Upright: the heart in the rain
- Reversed: the old hurt still lodged
- Figure: the rain

---

## Four of Swords
sky: Jupiter in Libra, 20–30° Libra · season: about Oct 13 – Oct 22 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: Where am I worn out right now, and what kind of rest would actually help?
2. Cross / boon: Is this pause what lets me cross into what's next, or am I resting to avoid getting up?
3. Root: When did I first learn I was allowed to stop, and who taught me?
4. Passing away: What hard stretch is ending, and how do I want to recover from it?
5. Front of mind: What am I deliberately setting down for a while?
6. Coming in: What stillness or recovery time is coming, and how can I protect it?
7. Who you are: Where do I need to be still in this, rather than doing more?
8. What surrounds you: Who around me needs quiet, and could I give them some?
9. Hopes / fears: What do I hope rest will restore, and what am I afraid I'll fall behind on if I take it?
10. Outcome: If I let myself rest like this, what comes back, and what would I need to stop believing about rest to take it?

### Reversed
1. Central theme: Where am I restless when I should rest, or lying still when it's time to get up?
2. Cross / boon: Is exhaustion what's in the way, or am I avoiding something by staying in bed?
3. Root: Who taught me that rest has to be earned?
4. Passing away: What busy stretch am I ready to call over?
5. Front of mind: What keeps my mind racing even when my body stops?
6. Coming in: When the rest is over and it's time to rise from the tomb, what will I need to be ready?
7. Who you are: Where am I running on fumes and pretending it's fine?
8. What surrounds you: Who around me makes it hard to rest?
9. Hopes / fears: If I lay still long enough for my own thoughts to catch up, what am I afraid they'd say?
10. Outcome: If I keep pushing without rest, where do I break down, and what one hour would I set aside to recover?

### Watch for
Upright
- Sun: Watch for a chance to step out of the spotlight for a while.
- Moon: Watch for sleepiness, and honor it.
- Mars: Watch for the battle you can put down for today.
- Mercury: Watch for silence: phone off, notifications quiet, a still room.
- Jupiter: Watch for an afternoon with nothing in it, and let it stay that way.
- Venus: Watch for restful comforts: a bath, a nap, clean sheets.
- Saturn: Watch for rest as part of the work, not a break from it.

Reversed
- Sun: Watch for feeling you have to be visible every single day.
- Moon: Watch for tired-but-wired, and what would let you wind down.
- Mars: Watch for restlessness that's looking for a fight.
- Mercury: Watch for scrolling instead of resting.
- Jupiter: Watch for overbooking yourself right after a break.
- Venus: Watch for treats standing in for real rest.
- Saturn: Watch for guilt about resting, and set it down.

### Low tide
- Notice: the knight lying with his hands pressed together, and the stained-glass window above him.
- Become: the figure in the stained-glass window. What do you see when you look down at him resting?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Libra), so rest, recovery and stepping back to heal are a lifelong thread for you. Answer about how you've learned to recover.
- Touching you: Jupiter, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so growth and good fortune are part of today's question. Answer about what rest would let grow.
- Its season: The Sun is in this card's ten days of the year, about October 13 to 22, mid-fall, when the days shorten quickly. Answer about the rest you need before winter.
- Today's weather: {planet} {is} passing through the last ten degrees of Libra, this card's slice of the sky, so your body and mind are asking for a pause today. Answer about where you need to stop now.
- The long season: {planet} {is} moving through the last ten degrees of Libra for months or years, an era of recovery. Answer about what's slowly being restored in you.
- Turning: Jupiter, this card's planet, is retrograde (seeming to move backward), a time when growth turns inward. Answer about a rest that's overdue.

### Essence
- Upright: the rest that restores
- Reversed: the rest that won't come
- Figure: the knight at rest

---

## Five of Swords
sky: Venus in Aquarius, 0–10° Aquarius · season: about Jan 20 – Jan 29 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What conflict have I been in lately, and what did winning, or losing, actually cost?
2. Cross / boon: Is this argument the hard crossing to something better, or a fight that's left everyone worse off?
3. Root: What early fight taught me how to win, or how to give up?
4. Passing away: What conflict is ending, and what am I picking up off the ground, or leaving there?
5. Front of mind: What am I deliberately fighting for right now, and is it worth what it costs?
6. Coming in: What disagreement is coming, and how do I want to come out of it?
7. Who you are: Where am I the one holding the swords in this, and where am I the one walking away?
8. What surrounds you: Who around me is hurt by how this went?
9. Hopes / fears: What do I hope to prove by winning, and what am I afraid of losing along the way?
10. Outcome: If I keep fighting this way, what's left standing, and what would I need to let go of being right about to come out whole?

### Reversed
1. Central theme: Where is an old fight still smoldering, or where am I ready to make peace?
2. Cross / boon: Is pride what's in the way, or a hurt that hasn't been acknowledged?
3. Root: What defeat do I still carry, years later?
4. Passing away: Which score have I kept so long I've forgotten the original point?
5. Front of mind: What argument do I keep winning in my head?
6. Coming in: What's coming that could mend things after a falling-out?
7. Who you are: Where have I walked away from a fight I needed to have?
8. What surrounds you: Who around me picks fights they can't lose?
9. Hopes / fears: If I picked up the swords on the ground and said sorry first, what am I afraid I'd lose?
10. Outcome: If this stays unresolved, what does it keep costing, and what one step would I take toward making it right?

### Watch for
Upright
- Sun: Watch for winning in a way you'd be glad to be seen winning.
- Moon: Watch for the feeling left over after an argument, and tend it.
- Mars: Watch for a fight worth having, and one worth skipping.
- Mercury: Watch for words that win the point and lose the person.
- Jupiter: Watch for a way everyone could come out ahead.
- Venus: Watch for a chance to make peace without giving up what matters.
- Saturn: Watch for the long cost of a short victory.

Reversed
- Sun: Watch for needing to have the last word.
- Moon: Watch for sulking after a loss, and comfort yourself kindly.
- Mars: Watch for reopening a fight that was nearly over.
- Mercury: Watch for talking behind the back of someone you've clashed with.
- Jupiter: Watch for taking more than you need just because you can.
- Venus: Watch for an olive branch held out, and take it if it's real.
- Saturn: Watch for a grudge you've carried long enough.

### Low tide
- Notice: the two swords left on the ground, and the two figures walking away toward the water.
- Become: one of the two walking away. What just happened, and what will you tell someone about it later?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Aquarius), so conflict, standing apart and learning what winning costs are a lifelong thread for you. Answer about the fights that have taught you what matters.
- Touching you: Venus, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so love and what you value are part of today's question. Answer about what matters more than being right.
- Its season: The Sun is in this card's ten days of the year, about January 20 to 29, deep winter, when cabin fever makes tempers short. Answer about the conflict you're in.
- Today's weather: {planet} {is} passing through the first ten degrees of Aquarius, this card's slice of the sky, so friction is in the air today. Answer about the disagreement in front of you now.
- The long season: {planet} {is} moving through the first ten degrees of Aquarius for months or years, an era of conflict and its costs. Answer about the peace you're slowly learning to make.
- Turning: Venus, this card's planet, is retrograde (seeming to move backward), a time when old disagreements resurface. Answer about a fight you'd like to mend.

### Essence
- Upright: the hollow win
- Reversed: the fight left smoldering
- Figure: one of the two walking away

---

## Six of Swords
sky: Mercury in Aquarius, 10–20° Aquarius · season: about Jan 30 – Feb 8 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What am I moving away from right now, slowly, toward calmer water?
2. Cross / boon: Is this quiet crossing the way from the old life to the new, or am I carrying too many swords in the boat?
3. Root: Who first carried me through a hard time, and what did they do that I still remember?
4. Passing away: What rough stretch is behind me now, and what am I bringing across?
5. Front of mind: Where am I deliberately heading, even if I can't see the far shore yet?
6. Coming in: What calmer place, or what journey, is ahead?
7. Who you are: Where am I the one being carried right now, and can I let myself be?
8. What surrounds you: Who around me is poling the boat, and have I thanked them?
9. Hopes / fears: What do I hope is waiting on the other shore, and what am I afraid I'm bringing with me?
10. Outcome: If I keep crossing at this pace, where do I land, and what would I need to set over the side to travel lighter?

### Reversed
1. Central theme: Where am I stuck midstream, or turning back toward rough water?
2. Cross / boon: Is unfinished business what's in the way, or am I afraid of the far shore?
3. Root: What old move or change never quite finished?
4. Passing away: What baggage am I ready to leave in the water?
5. Front of mind: What problem keeps following me from place to place?
6. Coming in: What's coming that will finally let me cross?
7. Who you are: Where am I refusing to be helped?
8. What surrounds you: Who around me can't seem to leave, and can I help without taking their oar?
9. Hopes / fears: If the boat never came back to this shore, what would I miss that I'm not admitting?
10. Outcome: If I stay midstream, what happens, and what one thing would I have to let go of to keep moving?

### Watch for
Upright
- Sun: Watch for a moment of relief, and let it show.
- Moon: Watch for calm returning to your body after a hard stretch.
- Mars: Watch for the steady effort of moving on, one stroke at a time.
- Mercury: Watch for travel, directions, a route away from trouble.
- Jupiter: Watch for help that gets you further than you could go alone.
- Venus: Watch for quiet beauty along the way: still water, a kind face.
- Saturn: Watch for the patience a slow crossing asks of you.

Reversed
- Sun: Watch for acting as if you've moved on when you haven't.
- Moon: Watch for homesickness for something you left for good reason.
- Mars: Watch for fighting the current.
- Mercury: Watch for talking the old trouble over, again.
- Jupiter: Watch for packing every worry to bring along.
- Venus: Watch for missing someone you're better off without.
- Saturn: Watch for delays in a move, and what they're asking of you.

### Low tide
- Notice: the water rough on one side of the boat and smooth on the other, and the six swords standing in the boat.
- Become: the child in the boat. Where do you think you're going?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Aquarius), so moving on, changes of place and being carried through are a lifelong thread for you. Answer about the crossings that have brought you here.
- Touching you: Mercury, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so messages, travel and plans are part of today's question. Answer about the next part of your crossing.
- Its season: The Sun is in this card's ten days of the year, about January 30 to February 8, the long middle of winter. Answer about what you're moving away from.
- Today's weather: {planet} {is} passing through the middle ten degrees of Aquarius, this card's slice of the sky, so a move or a shift is under way today. Answer about the crossing you're making now.
- The long season: {planet} {is} moving through the middle ten degrees of Aquarius for months or years, an era of transition. Answer about where your life is slowly carrying you.
- Turning: Mercury, this card's planet, is retrograde (seeming to move backward), as it is about three times a year for three weeks, a time when plans and journeys stall or circle back. Answer about something you thought you'd left behind.

### Essence
- Upright: the crossing to calmer water
- Reversed: stuck midstream
- Figure: the child in the boat

---

## Seven of Swords
sky: Moon in Aquarius, 20–30° Aquarius · season: about Feb 9 – Feb 18 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What am I quietly carrying off on my own right now, and why am I not asking anyone for help?
2. Cross / boon: Is this clever workaround the way across, or a shortcut that will catch up with me?
3. Root: When did I first learn that doing things alone, and quietly, was safer?
4. Passing away: What secret plan or workaround is ending, and what did it get me?
5. Front of mind: What am I strategizing about on purpose, and who knows the plan?
6. Coming in: What's coming that will need some tact, or a little cunning?
7. Who you are: Where am I keeping something to myself in this, and is that wise or lonely?
8. What surrounds you: Who around me isn't telling the whole story?
9. Hopes / fears: What do I hope to get away with, and what am I afraid will be found out?
10. Outcome: If I keep slipping away with this, where does it leave me, and what would I need to say out loud to stop carrying it alone?

### Reversed
1. Central theme: Where is a secret coming to light, mine or someone else's?
2. Cross / boon: Is something I'm hiding what's in the way, or something hidden from me?
3. Root: What did I learn to hide as a kid, and why?
4. Passing away: What workaround am I ready to stop using?
5. Front of mind: What am I telling myself that I wouldn't want anyone to hear?
6. Coming in: Which of the swords I carried off is about to be noticed missing, and how do I want to bring it back?
7. Who you are: Where am I fooling myself?
8. What surrounds you: Who around me has been honest with me when it would have been easier not to be?
9. Hopes / fears: If someone saw every sword I've ever carried off quietly, what would I be most afraid of them seeing?
10. Outcome: If I keep the secret, what does it cost me, and who is the one person I'd tell first?

### Watch for
Upright
- Sun: Watch for a plan you're keeping in the dark, and ask whether it needs light.
- Moon: Watch for a feeling you're hiding, even from yourself.
- Mars: Watch for a clever move that saves a fight.
- Mercury: Watch for what's left out of a story.
- Jupiter: Watch for a bigger, more honest way to get what you want.
- Venus: Watch for a white lie told to keep things sweet.
- Saturn: Watch for a shortcut that would cost more later.

Reversed
- Sun: Watch for the relief of telling the truth.
- Moon: Watch for a gut feeling that something's off.
- Mars: Watch for being caught out, and meet it without defending too hard.
- Mercury: Watch for a confession, given or received.
- Jupiter: Watch for help offered once the secret is out.
- Venus: Watch for kindness after an honest admission.
- Saturn: Watch for a consequence you can meet squarely.

### Low tide
- Notice: the two swords he's leaving behind, and how he looks back over his shoulder.
- Become: one of the two swords left standing in the ground. What do you know about where he's going?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Aquarius), so strategy, going it alone and keeping your own counsel are a lifelong thread for you. Answer about what you've always carried quietly.
- Touching you: The Moon, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few hours, so private feelings are near the surface. Answer about what you're keeping to yourself today.
- Its season: The Sun is in this card's ten days of the year, about February 9 to 18, late winter, when plans for spring start in secret. Answer about what you're quietly working on.
- Today's weather: {planet} {is} passing through the last ten degrees of Aquarius, this card's slice of the sky, so secrets and strategies are close today. Answer about what you're keeping quiet now.
- The long season: {planet} {is} moving through the last ten degrees of Aquarius for months or years, an era of working alone and in quiet. Answer about the plan you've been slowly carrying out on your own.

### Essence
- Upright: the swords carried off quietly
- Reversed: the secret coming out
- Figure: the man slipping away
