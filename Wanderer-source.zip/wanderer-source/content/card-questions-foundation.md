# The Card Questions: foundation

A tarot app informed by astrology. Its heart is an offline database of what each card asks, by
orientation and by Celtic Cross position, colored by the day's ruling planet and the planetary
hour, with plain-language lines explaining why a card matters today when the sky lights it.
Everything here is written once, and combined by the app at reading time. The app itself uses no
AI at all: no accounts, nothing to subscribe to. It runs entirely on the phone; when online it
only checks the time and fetches quantum noise for shuffling.

The test for every line: does it make it easier to open the notebook and write?

## How a reading is assembled

For each card drawn, the app shows:

1. **The question** for this card, this orientation, in this position. One question, written to be
   answered on the page. Mark it Q in the margin so you find it when rereading.
   Above it, one line from the hour's planet (how to answer). The day's planet shows up in the
   card's own watch-for cue instead, and its general line stays on the Clock.
2. **Why it's lit** (only if it is): one or two sentences in plain words saying how today's sky or
   your birth chart touches this card, ending with how to aim your answer.
3. Nothing else by default. Meanings, keywords and astrology stay one tap away.

One-card draws use the Central theme question. Three-card draws reuse positions: Past = Passing away,
Present = Central theme, Future = Coming in. So the Celtic Cross questions cover every spread.

## Counts

| Layer | Entries |
|---|---|
| Questions: 78 cards × 2 orientations × 10 positions | 1,560 |
| Day's-card watch-for cues: 78 cards × 2 orientations × 7 day rulers | 1,092 |
| Why-it's-lit lines, written per card (only the kinds that apply to that card) | 338 |
| Low-tide pointers: a Notice and a Become per card | 156 |
| Essence: a short phrase per orientation and a figure, per card | 234 |
| The day and the hour: 7 planets × (4 day questions + 3 hour questions), with their ladders and Read notes | 49 questions, 63 ladder steps |
| Day and hour lines (7 + 7), pair prompts (16), low-tide ladder (5 rungs + floor), planet lines, position lenses, lit kinds | about 65 |
| **Total** | **about 3,600** |

The lit lines don't multiply by position or orientation: they explain *why the card matters
today*, which is the same wherever it lands. The day and hour lines are shared by every card:
the day's line sits on the Clock, the hour's above every question.

## The day and the hour

The day's ruling planet turns things toward part of life; the planetary hour you're reading in
sets the way to answer. Only the hour line sits above a question. The day line shows on the
Clock, and the day's planet already shapes each card's own watch-for cue, which is more specific
than a general day line would be.

**The day (what to look at)**
- **Sun's day:** turn it toward what you're seen for and what keeps you lit.
- **Moon's day:** turn it toward home, the body and how you actually feel.
- **Mars's day:** turn it toward courage, anger and what needs cutting.
- **Mercury's day:** turn it toward words, crossings and what you're trading.
- **Jupiter's day:** turn it toward generosity, faith and what wants to grow.
- **Venus's day:** turn it toward love, pleasure and what you value.
- **Saturn's day:** turn it toward time, limits and what you're building to last.

**The hour (how to answer)**
- **Sun's hour:** answer out loud, as if someone you respect were reading over your shoulder.
- **Moon's hour:** answer from the body first: what do you feel before you think?
- **Mars's hour:** answer bluntly, and stop when it's said.
- **Mercury's hour:** answer fast, in plain words; follow where the pen goes.
- **Jupiter's hour:** answer generously: the big version, the one with room in it.
- **Venus's hour:** answer slowly and with pleasure; savor the words.
- **Saturn's hour:** answer honestly and briefly; one true sentence is enough.

## The day's card

One card a day per person, drawn the first time the Clock opens after sunrise and then kept until
the next sunrise. The shuffle mixes quantum noise (when online) with the phone's own secure
randomness, so the draw can't be predicted or repeated, and reopening the app shows the same card
all day.

It shows the card, its Central theme question (with the hour's line), its lit line if
any, and a **watch-for cue**: something to keep an eye out for today, alongside looking for signs
of the day's planet. The cue is written per card, per orientation, per day ruler, so the same
card on a Tuesday and a Friday sends you looking for different things.

## Low tide: when there are no thoughts

Some days the question is too much. Under every question there's a small link, *Nothing
coming?*, that opens the low-tide ladder for that card. It starts with looking instead of
thinking, and each rung is a fine place to stop.

1. **Look.** What's going on in this picture, and what do you see that makes you say that?
   Describe only. (Visual Thinking Strategies: plain observation, no insight required.)
2. **Become.** Step into the card's own figure (each card names one). What are they thinking?
   What happened just before this moment? Write it as them. (The story-about-a-picture method of the Thematic Apperception Test, used
   here as a writing starter, not a diagnosis.)
3. **Lend them your feeling.** If they were feeling what you're feeling, what would they do
   next? What would happen after they do that? (Self-distancing: your feeling, seen from a
   step away, carried forward by someone else.)
4. **Bring it home.** Where have you been [the card's figure] lately? (Each card names its own
   figure in its Essence, such as "the lion" or "the man with the bundle".)
5. **Compare.** Now read the card's meaning. Where does it agree with the story you wrote, and
   where does it go somewhere else? If they don't connect at all, that's fine: which one feels
   truer today, and what does your story know that the meaning doesn't?

The card's meaning stays out of sight until rung 5, so the story
you write is yours first and isn't steered by the book. Each rung asks a little more energy than
the one before; climb as far as today allows.

And if even rung 1 is too much: write the date, the day's planet and the card's name, copy the
card's question underneath, write one word for how today feels, and close the notebook. You
opened it; that counts.

Rungs 1 and 2 get a pointer written for each card: one detail worth noticing and one figure to
step into. Cards with no people (the Eight of Wands, the Three of Swords, some Aces) name an
object to speak as instead. Rungs 3 and 5 are shared by every card, and rung 4 names the card's
figure. The picture is the same either way up, so one pointer per card covers both orientations.

Every step has a way back: "← Back a step" (the first step goes back to the question, and the
floor goes back to step one), and every open Write or Read view has "← Back to Write or Read".

For the Eight of Pentacles:

> **Notice:** the finished coins hung on the post beside him, and the town far off behind him.
> **Become:** the man at the bench. Why are you working out here instead of in town?

## How it shows on screen: Write or Read

Every card opens folded: just the picture, its name, its position, and one small line if it's
lit. Under that, two choices, nothing expanded until you pick:

**Write** *(a question for the page)*
1. The question, with the hour's line above it. Most days this is all.
2. *Nothing coming?* opens rung 1 of the ladder. Each rung has a *One more step* link that
   opens the next, so you only ever see the step you're on.
3. Rung 5 opens the card's meaning and asks you to compare.

**Read** *(the meaning, nothing asked)*
1. The card's meaning and keywords.
2. Why it's lit, in plain words, if it is.
3. *Its piece of the sky:* the card's planet, sign or decan, for curiosity.
4. On the day's card, the watch-for cue.
5. At the very bottom, quietly: *Want one question to carry?* It shows the question without
   asking you to write it. A bridge, never a push.

In a spread, the choice is made once at the top and applies to every card; each card can still
be switched on its own. Write mode ends with the pair prompts; Read mode ends with a short list of
which cards pair with which, by position, so you can see the shape without being asked anything.

The app remembers the choice for the rest of the day, then starts fresh tomorrow: no streaks,
no defaults that turn into expectations.

## The ten positions: what each one pulls from a card

Read in this order.

| # | Position | What it is | The question asks about… |
|---|---|---|---|
| 1 | Central theme | what the whole spread is about | what is true right now |
| 2 | Cross / boon | the obstacle or the help, and the bridge from what's leaving to what's coming | whether this hinders or carries you, and how to cross |
| 3 | Root | the root of everything in the spread | what all of this grows from |
| 4 | Passing away | energy leaving | what to release, finish or thank |
| 5 | Front of mind | what you're consciously thinking about and manifesting; your current direction | what your attention is making real |
| 6 | Coming in | energy arriving | what's on its way and how to make room |
| 7 | Who you are | you in this | how you're carrying yourself |
| 8 | What surrounds you | people, places and influences around you | who and what is shaping this from outside |
| 9 | Hopes / fears | the back of your mind | what you want and dread, often the same thing |
| 10 | Outcome | where the front and back of your mind are leading | where this heads, and which lever would steer it |

### How the positions pair

- **Front of mind (5) and Hopes / fears (9):** the front and the back of your mind.
- **Coming in (6) and What surrounds you (8):** what's arriving, and the world it lands in.
- **Root (3) and Who you are (7):** what you grew from, and who you are because of it.
- **Cross / boon (2) as the bridge:** it stands between Passing away (4) and Coming in (6).
- **Front of mind (5), Hopes / fears (9) and Outcome (10):** what you think, flavored by what you
  hope and fear, leads to the outcome. These are the levers: change 5 or 9 and 10 moves.

Paired positions get questions written to talk to each other. Root and Who you are both ask about
origins and self. Front of mind and Hopes / fears share the language of attention: what you
think on purpose, and what you think without meaning to. Coming in and What surrounds you share
the language of arrival and landing. Cross / boon is always written so it can be either a block
or a help. Outcome always ends with a lever.

### How the cards talk to each other

After the ten cards, the app shows five short prompts that read the pairs together. These are
written once and shared by every reading (16 in all), chosen by which cards came up reversed.
Each card appears as its name plus its own short phrase from its Essence, so the prompt reads as
the cards, not as blanks: "The root of all this: The World (the circle completed)." A reversed
card reads "Strength reversed (the grip that won't relax)".

**Front and back of mind (5 and 9)**
- Both upright: In front of my mind: {5}. At the back of it: {9}. They seem to pull the same way. What are they building together, and what would it take to trust that?
- 5 reversed: My conscious aim looks stuck: {5}. The back of my mind holds {9}. Is the hope or fear behind my direction what's jamming it?
- 9 reversed: My conscious direction is clear: {5}. But the back of my mind is uneasy: {9}. What am I not letting myself say out loud?
- Both reversed: Both are turned inward. What I'm thinking: {5}. What I'm quietly feeling: {9}. If I wrote the honest version of each, what would they say?

**Coming in and what surrounds you (6 and 8)**
- Both upright: Arriving: {6}. The world it lands in: {8}. Who or what around me is ready to welcome it?
- 6 reversed: What's coming in is delayed or tangled: {6}. Around me: {8}. Is something here holding the door shut?
- 8 reversed: Arriving: {6}. But what surrounds me is strained: {8}. What do I need to clear, or set a boundary around, to make room for it?
- Both reversed: What's coming is tangled: {6}. So is what surrounds me: {8}. What's one thing in my circumstances I can change from my side?

**Root and who you are (3 and 7)**
- Both upright: The root of all this: {3}. Who I am in it: {7}. How did that root grow me into this, and what of it do I want to keep feeding?
- 3 reversed: The root is troubled: {3}. Yet I'm standing as {7}. What did I learn to become in answer to that root?
- 7 reversed: The root is sound: {3}. But I'm not quite myself: {7}. Where have I drifted from what I grew from?
- Both reversed: The root is knotted: {3}. So is how I'm carrying myself: {7}. What's the oldest thread here, and what would loosening it change?

**The bridge (4, 2, 6)**
- 2 upright: Leaving: {4}. Arriving: {6}. Standing between them: {2}. How is it helping me cross, and how can I lean on it?
- 2 reversed: Leaving: {4}. Arriving: {6}. In the doorway between them: {2}. What is it asking me to deal with before I can step through?

**The levers (5, 9, 10)**
- 10 upright: Where things are heading: {10}. My conscious direction: {5}. The back of my mind: {9}. If I want to arrive there, what do I keep thinking and feeling? If I don't, which do I change first?
- 10 reversed: Where things head if nothing changes: {10}. My direction: {5}. My hopes and fears: {9}. Which of the two is easier to change this week, and what would I change it to?

## The ways a card can be lit

Each card belongs to a piece of the sky (the Golden Dawn system): a planet, a sign (30°), a
decan (a ten-degree slice of a sign), a court span (30° across two signs), or a quarter of the year.
A card is lit when that piece of sky is active. The kinds, in the order the app shows them
(at most two per card):

| Kind | What happened | What it means for the question |
|---|---|---|
| **Yours** | You were born with a planet in the card's degrees (for planet cards: that planet rules your rising or Sun sign, or sat on a chart angle) | a lifelong thread; answer about the long arc |
| **Touching you** | The card's planet is making an aspect to your birth chart today | the card's planet is personally involved right now |
| **Its season** | The Sun is in the card's degrees: its days of the year | the time of year is asking this |
| **Today's weather** | The Moon, Mercury, Venus or Mars is passing through the card's degrees | the question is live today or this week |
| **The long season** | Jupiter, Saturn, Uranus, Neptune or Pluto is moving through the card's degrees for months or years | the whole era is asking this; answer about what's slowly changing |
| **Turning** | The card's planet is stationing (standing still before reversing) or retrograde (seeming to move backward) | a time to revisit rather than push |
| **Quiet** | None of the above | read the card on its own terms (no line shown) |

Which kinds each card gets:

- 36 decan cards (Twos–Tens): Yours, Touching you, Its season, Today's weather, The long season, Turning (not for the Sun or Moon)
- 12 sign Majors (Emperor, Hierophant, Lovers, Chariot, Strength, Hermit, Justice, Death, Temperance, Devil, Star, Moon): Yours, Its season, Today's weather, The long season
- 12 court cards (Knights, Queens, Kings): Yours, Its season, Today's weather, The long season
- 7 planet Majors (Magician, High Priestess, Empress, Wheel, Tower, Sun, World) and 3 element Majors through their modern planet (Fool: Uranus, Hanged Man: Neptune, Judgement: Pluto): Yours, Touching you, Turning
- 4 Aces and 4 Pages (a quarter of the year each): Its season only (a quarter of the zodiac holds too many planets for the others to mean anything)

## The planet line

When a planet does the lighting, one sentence names it in plain words. These are shared by all cards.

- **Sun**: the planet of attention and vitality, what you're seen for. It stays about ten days in each ten-degree slice.
- **Moon**: the planet of mood, body and home. It crosses a card's degrees in under a day, so this lasts hours.
- **Mercury**: the planet of words, thinking, errands and deals.
- **Venus**: the planet of love, pleasure, beauty and what you value.
- **Mars**: the planet of drive, heat, courage and conflict.
- **Jupiter**: the planet of growth, generosity and faith, and of too much of a good thing. It lingers for months.
- **Saturn**: the planet of the long haul, limits and what's built slowly. It lingers for months.
- **Uranus**: the planet of the sudden, the free and the strange. It lingers for a year or more.
- **Neptune**: the planet of dreams, longing and blur. It lingers for a year or more.
- **Pluto**: the planet of depth, power and what has to change form. It lingers for years.

## Style rules for every question

- One question, answerable on the page in a few lines or a few pages. No exercises, no tasks, no affirmations.
- Plain words, first person ("What am I…", "Where do I…"), specific enough that it couldn't belong to another card.
- Upright asks about the card working; reversed asks about it blocked, overdone or turned inward. Never punishing.
- Each position bends the question toward its lens, and paired positions talk to each other (see above).
  Twenty questions for one card should feel like twenty doors into the same room.
- No fate, sin, guilt or moralizing. Curious, honest, kind.
- Start from something you can point to (a moment, a thing, a person, a habit) before asking what
  it means, so a tired mind has somewhere to begin.
- No stock openings or closings repeated from card to card. Each position still does its job:
  Cross / boon can block or help, Root talks to Who you are, Hopes / fears holds both the hope
  and the fear, Outcome ends with a lever (a thought or a hope/fear to change). But the wording
  belongs to the card. Frames to avoid: "which thought or fear would I change", "In the back of
  my mind", "What do I quietly fear", "what carries me", "blocking the way", "how much of this
  grows from that", "What would I dread about", "What's coming that will ask me to". Openings
  that simply name a position's job, such as "Who around me…" for What surrounds you, are fine.

## Source format (one block per card)

Each card file is written in this markdown format. A build script turns them into the app's JSON.

```
## Eight of Pentacles
sky: Sun in Virgo, 0–10° Virgo · season: about Aug 23 – Sep 2 · lit by: Yours, Touching you, …

### Upright
1. Central theme: …
…
10. Outcome: …

### Reversed
1. Central theme: …
…

### Watch for
Upright
- Sun: … (one per day ruler, Sun to Saturn)
Reversed
- Sun: …

### Low tide
- Notice: one detail in the picture
- Become: one figure (or object) to step into

### Lit
- Yours: …
- Today's weather: {planet} {is} passing through … (the app fills in the real planet: "Mars is",
  "the Moon and Venus are"). Required in Today's weather and The long season.

### Essence
- Upright: a short phrase for the card working ("the lion held gently")
- Reversed: a short phrase for it blocked or turned inward ("the grip that won't relax")
- Figure: who to name in "Where have you been ___ lately?" ("the lion")
```

---

## Worked example: Eight of Pentacles

sky: Sun in Virgo, 0–10° Virgo · season: about Aug 23 – Sep 2 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright

1. Central theme: What am I getting better at just by showing up, and what would I practice next if no one ever saw the result?
2. Cross / boon: Is patient, unglamorous work carrying me from what's ending to what's beginning, or keeping me too busy to notice the change?
3. Root: What long apprenticeship sits under all of this: the hours I've put in that made the rest possible?
4. Passing away: What stage of learning am I finishing, and what did it teach me that I'll keep?
5. Front of mind: What craft has my attention right now, and what am I making real by practicing it every day?
6. Coming in: What new skill or steady work is on its way to me, and how do I want to be ready for it?
7. Who you are: Where do I take quiet pride in doing things properly, and where does that slide into perfectionism?
8. What surrounds you: Who around me is doing patient work I could learn from, or thank?
9. Hopes / fears: What do I hope getting really good at this would finally prove, and what am I afraid it won't?
10. Outcome: If I keep practicing what I'm practicing now, what will I be able to do, and is that what I want to be good at?

### Reversed

1. Central theme: Where am I polishing so I don't have to finish, or working hard at something I've stopped caring about?
2. Cross / boon: Is my need to get it perfect holding the work back, or protecting something that truly needs more time?
3. Root: Who taught me that what I produce is what I'm worth, and do I still believe them?
4. Passing away: What project or habit have I outgrown but keep tending out of duty, and can I let it go?
5. Front of mind: Is the work I keep thinking about actually moving, or am I rehearsing it in my head instead of doing it?
6. Coming in: Where is a rush coming that will tempt me to cut corners on something that deserves care?
7. Who you are: When did I last make something just for the pleasure of making it?
8. What surrounds you: Who around me is asking for more output than the work deserves, and do I agree with them?
9. Hopes / fears: What do I picture happening if I set down the hammer and stopped working this hard?
10. Outcome: If nothing changes, what will I become good at that I don't want, and what would I rather spend my practice on?

### Watch for

Upright
- Sun: Watch for where your work is seen today, and how it feels to be noticed for the craft rather than the result.
- Moon: Watch for small home tasks done with care: a meal, a mended thing, a routine that steadies you.
- Mars: Watch for the moment you want to rush, and what it costs or saves to slow down.
- Mercury: Watch for someone who knows a trick of the trade, and for the right words to ask them about it.
- Jupiter: Watch for a chance to teach what you know, or to learn from someone further along.
- Venus: Watch for beauty in good workmanship: a well-made thing, a careful hand, something built to be enjoyed.
- Saturn: Watch for the unglamorous repetition that's quietly making you better, and give it its due.

Reversed
- Sun: Watch for where you're performing effort instead of doing the work.
- Moon: Watch for tiredness that looks like diligence, and whether your body wants a different pace.
- Mars: Watch for frustration with work that won't come right, and whether it's the work or the way you're doing it.
- Mercury: Watch for over-explaining, re-checking, re-sending: polishing words to avoid the next step.
- Jupiter: Watch for taking on more work than any one person should.
- Venus: Watch for work done without pleasure, and one small thing that could bring the pleasure back.
- Saturn: Watch for duty that's outlived its reason, and the task you'd drop if you were allowed.

### Low tide

- Notice: the finished coins hung on the post beside him, and the town far off behind him.
- Become: the man at the bench. Why are you working out here instead of in town?

### Lit

- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Virgo), so craft and patient improvement are a lifelong thread for you. Answer about the long arc of your work.
- Touching you: The Sun, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few days, so attention and how you show up are part of today's question. Answer about where you want your effort to be seen, or left alone.
- Its season: The Sun is in this card's ten days of the year, about August 23 to September 2, the end of summer, the season of mending tools and going back to work. Answer about what you're returning to.
- Today's weather: {planet} {is} passing through the first ten degrees of Virgo, this card's slice of the sky, so the work in your hands is live today. Answer about something you're making or mending now.
- The long season: {planet} {is} moving through the first ten degrees of Virgo for months or years, a long apprenticeship of an era. Answer about the work that's quietly becoming who you are.

### Essence
- Upright: the patient work at the bench
- Reversed: the polishing that never finishes
- Figure: the man at the bench

## The card files

| File | Cards |
|---|---|
| `batch-01-majors-0-7.md` | The Fool to The Chariot |
| `batch-02-majors-8-14.md` | Strength to Temperance |
| `batch-03-majors-15-21.md` | The Devil to The World |
| `batch-04-wands-ace-7.md` | Wands, Ace to Seven |
| `batch-05-wands-8-king.md` | Wands, Eight to King |
| `batch-06-cups-ace-7.md` | Cups, Ace to Seven |
| `batch-07-cups-8-king.md` | Cups, Eight to King |
| `batch-08-swords-ace-7.md` | Swords, Ace to Seven |
| `batch-09-swords-8-king.md` | Swords, Eight to King |
| `batch-10-pentacles-ace-7.md` | Pentacles, Ace to Seven |
| `batch-11-pentacles-9-king.md` | Pentacles, Nine to King |
| this file (worked example) | Eight of Pentacles |
| `planets-days-hours.md` | What each planet's day and hour ask |

## The day and the hour, opened from the Clock

On the Clock, the day's planet and the hour's planet are tappable. Each opens a sheet shaped like
a card: folded, then **Write** or **Read**.

- **Write:** one question (the day's rotate weekly through four per planet; the hour's through
  three), then *Nothing coming?* opens a ladder that climbs in energy, one step at a time:
  - Day: Look (describe one thing of the planet's you saw) · Catch (one line, marked with the
    glyph) · Feel (where it is in your body) · Lean (too much or too little, and the way back) ·
    Do (one small act before the day ends).
  - Hour: Look (something around you right now) · One word · One line · Do (one small thing
    this hour).
  - Floor: date or time and the planet, one word, close the notebook.
- **Read:** for the day, what it's for, its qualities, what to watch for, too much / too
  little with the way back; for the hour, what it's good for, how to answer, and the next hour.
  Both show where the planet is in the sky now (sign in plain words, retrograde if so), its
  card (Sun: The Sun, Moon: The High Priestess, Mercury: The Magician, Venus: The Empress, Mars:
  The Tower, Jupiter: Wheel of Fortune, Saturn: The World), and *Want one question to carry?*
- **Going back:** the same back buttons as the cards, on every step and every open view.
- The writing lives in `content/planets-days-hours.md`; `parse_cards.py` builds it.

## The app around it

A tarot app first, with astrology as the context that makes each card specific to today.

- **Clock (opens first, never scrolls):** the sky clock, filling one screen: the 24-hour dial with
  the planetary-hour band, today's sky inside it, the hands moving. Under it, the day's planet
  and the hour (tap either to open what it asks), the day's line, and the day's card with its
  watch-for cue. Tap the card for its question.
- **Cards:** draw one, three or a Celtic Cross. Each card shows its question with the hour's line
  and its lit line; after a Celtic Cross, the five pair prompts.
- **People:** the birthday selector. Everyone saved gets the same clock, day's card and spreads.
  Their birth chart and the comparison with someone else stay here as reference, one tap deep.
- Delivered as one HTML file, installable on Android.
- No AI anywhere in the app.
