# The Major Arcana: The Fool to The Chariot

Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position), 14 watch-for
cues (one per day planet, each orientation), a low-tide pointer, its lit lines, and its essence
(a short phrase per orientation and a figure).

The Magician, the High Priestess and the Empress each hold a planet; the Emperor, the
Hierophant, the Lovers and the Chariot each hold a sign; the Fool holds the element of Air,
through its modern planet, Uranus.

---

## The Fool
sky: Uranus (the element of Air) · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What am I about to step into without knowing where it leads, and what makes me willing to go anyway?
2. Cross / boon: Is not knowing where this goes the very thing that gets me from the old life to the new, or is it the cliff edge I keep pacing?
3. Root: When did I first jump without knowing where I'd land, and what did that first yes teach me about falling?
4. Passing away: What careful, over-planned way of living am I finishing with, and what did caution give me that I'll keep?
5. Front of mind: What beginning am I thinking about on purpose, and what am I making real just by imagining it?
6. Coming in: What new start is arriving before I feel ready, and how can I travel light enough to meet it?
7. Who you are: Where am I the beginner in this, and how does it feel to let myself be one?
8. What surrounds you: Who around me is like the little dog, barking a warning or cheering me on, and which is it?
9. Hopes / fears: Is the edge I'm standing on a fresh start or a fall, and why does part of me want it to be both?
10. Outcome: If I keep stepping off with this much trust, where do I land, and what would I want to have noticed before the next step?

### Reversed
1. Central theme: Where am I either refusing to begin, or leaping without looking because looking would scare me?
2. Cross / boon: Is recklessness blocking the crossing, or is the fear of looking foolish keeping me on the cliff?
3. Root: Which beginning, long ago, went badly enough that I still flinch at the first step?
4. Passing away: What reckless phase is ending, and what did it teach me about my own edges?
5. Front of mind: What am I calling a fresh start that's really an escape?
6. Coming in: What's arriving that will tempt me to drop everything, and what do I want to carry with me?
7. Who you are: Where am I playing the fool so I don't have to be taken seriously?
8. What surrounds you: Who around me is urging me to jump, or holding me back, for reasons that are really their own?
9. Hopes / fears: What dignity would I lose if I let myself be clumsy and new at something, and is it worth keeping?
10. Outcome: If I keep hovering at the edge, or keep jumping with my eyes shut, where do I end up, and what would I want to look at before I move?

### Watch for
Upright
- Sun: Watch for a moment when you're seen being new at something, and let it be fine.
- Moon: Watch for what your body wants to try today, before your mind talks it out of it.
- Mars: Watch for a small leap you could take right now, and take it before the doubt arrives.
- Mercury: Watch for a stray idea, a wrong turn or an overheard sentence that opens a door.
- Jupiter: Watch for an invitation you'd normally decline, and wonder what would happen if you said yes.
- Venus: Watch for an unplanned pleasure: a detour, a new taste, a stranger's kindness.
- Saturn: Watch for the one boundary that keeps a leap safe, and keep it.

Reversed
- Sun: Watch for where you're holding back from being seen trying something.
- Moon: Watch for restlessness that's really nerves, and what would actually calm it.
- Mars: Watch for an urge to quit or bolt, and wait an hour before acting on it.
- Mercury: Watch for careless words and half-read messages, and slow down for them.
- Jupiter: Watch for saying yes to everything so you don't have to choose.
- Venus: Watch for spending, eating or flirting on impulse, and ask what you were really after.
- Saturn: Watch for a fear of starting dressed up as being sensible.

### Low tide
- Notice: the white rose in his hand, the little dog at his heel, and how close his next step is to the edge.
- Become: the little dog. What do you see that he doesn't?

### Lit
- Yours: Uranus, this card's planet, holds a strong place in your birth chart, so leaps, odd timing and fresh starts are a lifelong thread for you. Answer about the beginnings that keep finding you.
- Touching you: Uranus, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so something in your life is ready to be shaken loose. Answer about where change is already arriving.
- Turning: Uranus, this card's planet, is retrograde (seeming to move backward), so the urge to break free is turning inward. Answer about what you'd change in yourself before changing anything outside.

### Essence
- Upright: the step off the cliff
- Reversed: the leap refused, or taken blind
- Figure: the little dog

---

## The Magician
sky: Mercury · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What do I already have on the table that's enough to start with, and what would I make with it today?
2. Cross / boon: Are the tools on my table enough to get me across, or am I so busy arranging them that I never pick one up?
3. Root: What's the first thing I ever made happen on purpose, and how did it feel to see it work?
4. Passing away: What way of working am I finishing with, and which of its tools do I keep?
5. Front of mind: What am I deliberately turning from idea into thing right now, and what's the next move?
6. Coming in: What tool, skill or opening is coming my way, and how will I be ready to pick it up?
7. Who you are: Where am I the one with the know-how in this, and how does it feel to own that?
8. What surrounds you: Who around me has the skill or the word I need, and have I asked them?
9. Hopes / fears: What do I hope my know-how will finally prove, and what job am I secretly afraid it's too small for?
10. Outcome: If I keep working with what's on the table this way, what will I have made, and which tool would I reach for differently?

### Reversed
1. Central theme: Where am I talking about it instead of doing it, or using cleverness to dodge the real work?
2. Cross / boon: Is a sleight of hand standing in the doorway: a shortcut, a spin, a half-truth, mine or someone else's?
3. Root: When did I first talk my way out of something I should have owned, and has it become a habit?
4. Passing away: What spin, performance or manipulation am I ready to stop using?
5. Front of mind: What plan keeps living in my head and never reaches my hands?
6. Coming in: What's arriving that will tempt me to oversell or overpromise?
7. Who you are: Where am I doubting skills I actually have?
8. What surrounds you: Who around me is a little too slick, and what does my gut say about them?
9. Hopes / fears: What would people see if I put the wand down and stopped performing that I know what I'm doing?
10. Outcome: If my skills stay scattered across the table, what never gets made, and which one tool would I pick up and use this week?

### Watch for
Upright
- Sun: Watch for a chance to show what you can do, and do it plainly.
- Moon: Watch for a small household magic: a fix, a meal, a rearranged shelf that changes how a room feels.
- Mars: Watch for the moment an idea needs action, and act on it.
- Mercury: Watch for the right word at the right time, and say it.
- Jupiter: Watch for a chance to teach a trick you know.
- Venus: Watch for something you could make beautiful with only what's already at hand.
- Saturn: Watch for a skill worth practicing slowly, and give it ten minutes.

Reversed
- Sun: Watch for showing off, and what's underneath it.
- Moon: Watch for the stories you tell yourself to feel in control.
- Mars: Watch for forcing something that needs finesse.
- Mercury: Watch for half-truths, yours or anyone's, and name them gently.
- Jupiter: Watch for big talk that hasn't met the work yet.
- Venus: Watch for charm used to get your way, and whether you'd want it used on you.
- Saturn: Watch for a tool you have but keep not using.

### Low tide
- Notice: the four objects on the table, and the one hand raised to the sky while the other points to the ground.
- Become: the Magician. What are you about to make, and which of the four tools do you reach for first?

### Lit
- Yours: Mercury, this card's planet, holds a strong place in your birth chart, so words, skill and crossings are a lifelong thread for you. Answer about the craft you keep coming back to.
- Touching you: Mercury, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so a conversation, a message or a decision is part of today's question. Answer about what you need to say, or do with your hands.
- Turning: Mercury, this card's planet, is retrograde (seeming to move backward), a review period for words, plans and travel. Answer about what to redo, reread or reconnect rather than start.

### Essence
- Upright: everything on the table, ready
- Reversed: the trick instead of the work
- Figure: the Magician

---

## The High Priestess
sky: the Moon · lit by: Yours, Touching you

### Upright
1. Central theme: What do I already know about this that I haven't put into words yet?
2. Cross / boon: Is waiting and listening carrying me across, or is silence keeping me from stepping through?
3. Root: What quiet knowledge sits under all of this, older than anything I could explain?
4. Passing away: What secret, or what season of keeping to myself, is ending, and what did it protect?
5. Front of mind: What am I sensing on purpose right now, and what is my attention slowly uncovering?
6. Coming in: What's arriving that I'll only hear if I'm quiet enough?
7. Who you are: Where am I the one who knows and doesn't say, and is that wisdom or habit?
8. What surrounds you: Who around me speaks in hints, and what are they trying to tell me?
9. Hopes / fears: What do I half-know, under the veil, that I both hope and dread is true?
10. Outcome: If I keep trusting what I sense, where does it lead, and what noise would I turn down to hear it more clearly?

### Reversed
1. Central theme: Where am I ignoring a gut feeling because it's inconvenient?
2. Cross / boon: Is something unsaid, mine or someone else's, standing between the pillars?
3. Root: Who first told me my feelings were wrong, and do I still check with them before I trust my gut?
4. Passing away: What am I ready to stop hiding, even from myself?
5. Front of mind: Am I thinking in circles about something I'd simply know if I got quiet?
6. Coming in: Which secret behind the veil is about to be asked for, and am I ready to say it?
7. Who you are: Where am I cut off from my own inner voice right now?
8. What surrounds you: Who around me is keeping something back, and does it matter to me?
9. Hopes / fears: If I sat in silence long enough to hear myself, what would I be afraid to hear?
10. Outcome: If I keep drowning out what I know, what do I miss, and which noise would I switch off first?

### Watch for
Upright
- Sun: Watch for something you know but don't need to announce.
- Moon: Watch for dreams, moods and body signals, and write one down before it fades.
- Mars: Watch for the pause before you react, and what you learn in it.
- Mercury: Watch for what isn't said in a conversation.
- Jupiter: Watch for a coincidence that feels like an answer.
- Venus: Watch for what you're quietly drawn to before you can say why.
- Saturn: Watch for the wisdom in a silence you didn't choose.

Reversed
- Sun: Watch for performing a certainty you don't feel.
- Moon: Watch for a mood you keep explaining away.
- Mars: Watch for snapping at someone when the real trouble is something unspoken.
- Mercury: Watch for gossip, and what it's covering.
- Jupiter: Watch for a "sign" you're bending to fit what you want.
- Venus: Watch for a feeling you're hiding from someone you love.
- Saturn: Watch for loneliness that's really a wish to be known.

### Low tide
- Notice: the scroll half-hidden in her robe, and the water you can just glimpse behind the veil.
- Become: the High Priestess. What's written on the part of the scroll no one can see?

### Lit
- Yours: The Moon, this card's planet, holds a strong place in your birth chart, so intuition, moods and the inner life are a lifelong thread for you. Answer about what you've always known quietly.
- Touching you: The Moon, this card's planet, is making an aspect to your birth chart today (a meaningful angle to one of the planets you were born with), which lasts only a few hours, so your feelings sit near the surface. Answer about what you sense right now.

### Essence
- Upright: the knowing kept quiet
- Reversed: the gut feeling ignored
- Figure: the High Priestess

---

## The Empress
sky: Venus · lit by: Yours, Touching you, Turning

### Upright
1. Central theme: What in my life is growing well right now, and what is it asking from me to keep growing?
2. Cross / boon: Is all this comfort the soil that lets me grow into what's next, or has it gotten too cozy to leave?
3. Root: Who first fed me, in every sense, and what of their care do I still pass on?
4. Passing away: What season of tending is finishing, and what harvest do I carry out of it?
5. Front of mind: What am I lovingly feeding with my attention right now, and what is it becoming?
6. Coming in: What abundance is on its way, and how will I make room to enjoy it?
7. Who you are: Where am I the one who nurtures in this, and do I let myself be nourished too?
8. What surrounds you: Who around me is generous with care, and how could I receive it?
9. Hopes / fears: What do I hope will bloom from all this tending, and what seed am I afraid won't come up?
10. Outcome: If I keep tending things this way, what will flourish, and what would I prune or plant differently?

### Reversed
1. Central theme: Where am I over-giving, smothering, or starving something that needs care?
2. Cross / boon: Is a body I've been ignoring, or a pleasure I've stopped allowing, what's standing in the way?
3. Root: When did I learn that care had to be earned, and who did I watch earning it?
4. Passing away: What way of caring for others am I ready to stop, because it costs me too much?
5. Front of mind: What creation have I been thinking about but not feeding?
6. Coming in: What season is ripening that only grows if I water myself first?
7. Who you are: Where am I cut off from pleasure, beauty or my own body?
8. What surrounds you: Who around me is draining my care, and who is starving for it?
9. Hopes / fears: What makes me uneasy about being cared for, or about being needed so much?
10. Outcome: If I keep holding back care, or pouring out too much, what wilts first, and what would I water instead?

### Watch for
Upright
- Sun: Watch for something you've grown that deserves to be seen.
- Moon: Watch for comfort, a good meal, soft fabric, a warm room, and let yourself have it.
- Mars: Watch for something worth protecting, and protect it.
- Mercury: Watch for kind words you could say, and say them.
- Jupiter: Watch for plenty you could share.
- Venus: Watch for beauty in ordinary things: light, texture, scent, taste.
- Saturn: Watch for slow growth, the kind you only see across seasons.

Reversed
- Sun: Watch for giving so much that you disappear.
- Moon: Watch for skipped meals and skipped rest, and give them back to yourself.
- Mars: Watch for care that turns into control.
- Mercury: Watch for self-talk harsher than you'd ever be to a friend.
- Jupiter: Watch for indulgence that's really emptiness.
- Venus: Watch for a pleasure you've stopped allowing yourself.
- Saturn: Watch for a creative project left unwatered.

### Low tide
- Notice: the wheat growing at her feet, and the stream running down out of the trees.
- Become: the Empress. What are you growing here, and who is it for?

### Lit
- Yours: Venus, this card's planet, holds a strong place in your birth chart, so love, pleasure and making things beautiful are a lifelong thread for you. Answer about what you've always nurtured.
- Touching you: Venus, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so love, comfort or something you value is part of the question. Answer about what you want more of.
- Turning: Venus, this card's planet, is retrograde (seeming to move backward), a review of love, money and what you value. Answer about what you'd reconsider before committing or spending.

### Essence
- Upright: the garden growing
- Reversed: care given until it runs dry
- Figure: the Empress

---

## The Emperor
sky: the sign Aries · season: about Mar 20 – Apr 19 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What in this situation needs structure, and am I the one to build it?
2. Cross / boon: Are the rules I'm setting a solid road across this, or a wall I'm sitting behind?
3. Root: Whose rules did I grow up under, and did they teach me to lead or to obey?
4. Passing away: What old rule or role am I finishing with, and what did it give me that I'll keep?
5. Front of mind: What am I deliberately taking charge of, and what am I building by doing it?
6. Coming in: What responsibility is on its way, and how will I hold it without hardening?
7. Who you are: Where am I the one setting the terms in this, and am I fair?
8. What surrounds you: Who around me holds authority over this, and how do I want to meet them?
9. Hopes / fears: Underneath it all, do I want to be the one in charge, or am I mostly afraid of someone else being in charge of me?
10. Outcome: If I keep leading this way, what gets built, and what would I need to stop guarding to rule more kindly?

### Reversed
1. Central theme: Where am I rigid and controlling, or refusing to take charge of what's mine to take?
2. Cross / boon: Is someone's grip on the throne, maybe mine, what's keeping this stuck?
3. Root: Who taught me that being strong means being hard, and do I still believe them?
4. Passing away: What rule am I still following that no longer serves anyone?
5. Front of mind: What am I trying to control in my head that isn't mine to control?
6. Coming in: What's coming that will test whether I can lead without dominating?
7. Who you are: Where have I given my own authority away?
8. What surrounds you: Who around me is throwing their weight around, and where is my boundary?
9. Hopes / fears: What do I picture happening if I stood up from the throne and let someone else decide?
10. Outcome: If nothing changes, what turns to stone, and which rule would I soften first?

### Watch for
Upright
- Sun: Watch for a moment to step up and lead, plainly.
- Moon: Watch for the routines that make your home feel ordered and safe.
- Mars: Watch for a fight worth having, and fight it fairly.
- Mercury: Watch for a decision that needs one clear sentence.
- Jupiter: Watch for a chance to protect someone with the authority you have.
- Venus: Watch for the beauty in good order: a clean desk, a kept promise.
- Saturn: Watch for the structure that makes everything else possible, and maintain it.

Reversed
- Sun: Watch for ego dressed up as leadership.
- Moon: Watch for control that's really fear of chaos.
- Mars: Watch for anger looking for something to command.
- Mercury: Watch for orders given where questions would work better.
- Jupiter: Watch for taking charge of what isn't yours.
- Venus: Watch for coldness where warmth would lead better.
- Saturn: Watch for a rule you keep that nobody needs anymore.

### Low tide
- Notice: the rams' heads carved into the throne, and how bare the mountains behind him are.
- Become: the Emperor. What are you guarding, and what would happen if you stood up?

### Lit
- Yours: You were born with a planet in Aries, this card's sign, so leadership, beginnings and standing your ground are a lifelong thread for you. Answer about how you've learned to take charge.
- Its season: The Sun is in Aries, about March 20 to April 19, the first month of spring and the start of the zodiac. Answer about what you're beginning, and who's in charge of it.
- Today's weather: {planet} {is} passing through Aries, the Emperor's sign, so who's in charge is stirring today. Answer about something you need to decide or defend now.
- The long season: {planet} {is} moving through Aries for months or years, slowly rebuilding how you hold authority and start things. Answer about the structures you're remaking in this era.

### Essence
- Upright: the structure built and kept
- Reversed: the grip that won't let go
- Figure: the Emperor

---

## The Hierophant
sky: the sign Taurus · season: about Apr 20 – May 20 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What tradition, teacher or tried way is guiding this, and do I still believe in it?
2. Cross / boon: Is the tried-and-true way the bridge I need, or is "how it's done" keeping me on this side?
3. Root: Which beliefs did I inherit before I was old enough to choose them, and which have I kept on purpose?
4. Passing away: What teaching am I graduating from, and what of it do I keep?
5. Front of mind: What am I learning on purpose right now, and from whom?
6. Coming in: What teacher, ritual or community is on its way, and how will I meet it?
7. Who you are: Where am I the one others come to for guidance, and how do I hold that?
8. What surrounds you: Who around me stands for the institution or the rules here, and what do I owe them?
9. Hopes / fears: Do I long to belong to something, or dread having to fit its mold, or both?
10. Outcome: If I keep walking this well-worn path, where does it lead, and what would I change so it's mine and not just inherited?

### Reversed
1. Central theme: Where am I following rules I don't believe, or rejecting wisdom just because it's old?
2. Cross / boon: Is it fitting in, or pushing back just to push back, that's keeping me stuck?
3. Root: When did I learn that someone else always knew better than me about what's sacred?
4. Passing away: What belief am I ready to set down?
5. Front of mind: Whose voice am I hearing in my head that isn't mine?
6. Coming in: What occasion is on its way that no inherited ritual quite fits, so I'll have to make my own?
7. Who you are: Where am I a student who's outgrown the teacher?
8. What surrounds you: Who around me insists there's one right way, and do I agree?
9. Hopes / fears: What scares me more: walking out of the fold, or staying in it for good?
10. Outcome: If I keep handing my questions to someone else to answer, where does that leave me, and which question would I answer myself?

### Watch for
Upright
- Sun: Watch for a chance to share what you've learned with someone who's asking.
- Moon: Watch for the small daily rituals that hold you, and do one on purpose.
- Mars: Watch for a tradition worth defending.
- Mercury: Watch for a teacher's words that come back to you today.
- Jupiter: Watch for wisdom in an unexpected place: a book, an elder, a sign.
- Venus: Watch for a shared ritual, a meal, a song, a ceremony, however small.
- Saturn: Watch for the discipline behind a tradition, and what it protects.

Reversed
- Sun: Watch for performing a belief you don't hold.
- Moon: Watch for guilt that came from someone else's rules.
- Mars: Watch for rebellion that's only reaction.
- Mercury: Watch for dogma, in yourself or in conversation.
- Jupiter: Watch for borrowed answers to questions you haven't asked yet.
- Venus: Watch for love that asks you to be someone else.
- Saturn: Watch for rules whose only job is keeping you small.

### Low tide
- Notice: the two keys crossed at his feet, and the two figures kneeling with their backs to you.
- Become: one of the kneeling figures. What did you come here to ask?

### Lit
- Yours: You were born with a planet in Taurus, this card's sign, so steadiness, the body and the values you were raised with are a lifelong thread for you. Answer about what you were taught to hold sacred.
- Its season: The Sun is in Taurus, about April 20 to May 20, the full green of spring. Answer about what you want to keep and tend.
- Today's weather: {planet} {is} passing through Taurus, the Hierophant's sign, so a value or habit you were taught is being tested today. Answer about which one, and whether you still hold it.
- The long season: {planet} {is} moving through Taurus for months or years, slowly shifting what you believe is worth keeping. Answer about the teaching you're quietly rewriting.

### Essence
- Upright: the teaching handed down
- Reversed: the rule no longer believed
- Figure: the one kneeling to ask

---

## The Lovers
sky: the sign Gemini · season: about May 21 – Jun 20 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What choice of the heart is in front of me, and what do I truly value in it?
2. Cross / boon: Is this bond the bridge to who I'm becoming, or the choice I keep stepping around?
3. Root: Whose love did I learn love from, and what did it teach me to expect?
4. Passing away: What bond or choice is completing itself, and what did it teach me about what I want?
5. Front of mind: Who or what am I choosing with my attention right now, and what does that choice make real?
6. Coming in: What union, partnership or decision is on its way, and how do I want to be ready for it?
7. Who you are: Where am I wholly myself with someone, and where am I not?
8. What surrounds you: Who around me is part of this choice, and what do they need from it?
9. Hopes / fears: What do I hope love will give me, and what price am I afraid it will name?
10. Outcome: If I keep choosing this way, what will I have committed to, and what would I need to admit I want to choose freely?

### Reversed
1. Central theme: Where am I out of step with someone, or with my own values?
2. Cross / boon: Is a choice I keep not making the thing that's holding everything else still?
3. Root: Who did I learn to put first, them or me, and when did that pattern start?
4. Passing away: What relationship pattern am I ready to let end?
5. Front of mind: What choice am I thinking about endlessly so I never have to make it?
6. Coming in: Which fork in the road is getting closer, and have I already started looking the other way?
7. Who you are: Where am I hiding part of myself to be loved?
8. What surrounds you: Who around me is pulling me two ways at once?
9. Hopes / fears: What would I be afraid of if someone I love saw all of me at once?
10. Outcome: If I keep avoiding the choice, who chooses for me, and what would I need to know to choose for myself?

### Watch for
Upright
- Sun: Watch for a moment when someone you care about sees you just as you are.
- Moon: Watch for who makes you feel at home, and tell them.
- Mars: Watch for a choice that takes courage, and choose.
- Mercury: Watch for a conversation that brings two people closer.
- Jupiter: Watch for a yes that opens your heart a little wider.
- Venus: Watch for attraction, to a person, a place or a path, and follow it a step.
- Saturn: Watch for the commitment underneath a feeling, and honor it.

Reversed
- Sun: Watch for performing a version of yourself to be loved.
- Moon: Watch for neediness that's really loneliness.
- Mars: Watch for arguments that are really about something else.
- Mercury: Watch for mixed messages, sent or received.
- Jupiter: Watch for promising more love than you have to give today.
- Venus: Watch for temptation that's really avoidance.
- Saturn: Watch for a choice left unmade so long it's making itself.

### Low tide
- Notice: the angel above them, and that the man looks at the woman while she looks up at the angel.
- Become: the angel. What do you see that the two of them can't?

### Lit
- Yours: You were born with a planet in Gemini, this card's sign, so choices, conversations and the pull between two paths are a lifelong thread for you. Answer about how you've learned to choose.
- Its season: The Sun is in Gemini, about May 21 to June 20, late spring's busy, talkative month. Answer about the choice in front of you.
- Today's weather: {planet} {is} passing through Gemini, the Lovers' sign, so a choice or a conversation is live today. Answer about the one in front of you.
- The long season: {planet} {is} moving through Gemini for months or years, slowly reshaping how you connect and choose. Answer about the relationships changing you in this era.

### Essence
- Upright: the choice made with the heart
- Reversed: the choice put off
- Figure: the angel above them

---

## The Chariot
sky: the sign Cancer · season: about Jun 21 – Jul 22 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: Where am I moving forward on will alone, and what am I steering toward?
2. Cross / boon: Is sheer will what gets me across this, or am I racing past something I should stop for?
3. Root: When did I first learn to grit my teeth and push through, and who was watching?
4. Passing away: What hard-won victory is behind me, and what did winning it cost or give?
5. Front of mind: What am I driving toward on purpose right now, and what does that focus make real?
6. Coming in: What momentum is on its way, and how will I keep it pointed the right way?
7. Who you are: Where am I holding two opposite pulls together by will alone?
8. What surrounds you: Who around me is pulling in a different direction, and can I steer us both?
9. Hopes / fears: What do I hope this drive will win me, and what am I afraid will slip out of my hands on the way?
10. Outcome: If I keep driving this hard, where do I arrive, and what would I need to stop fighting to steer more truly?

### Reversed
1. Central theme: Where am I losing direction, or forcing my way through something that won't move?
2. Cross / boon: Am I stuck because I'm pushing too hard, or because I've stopped pushing at all?
3. Root: When did I decide I had to hold every rein to be safe?
4. Passing away: What battle am I ready to stop fighting?
5. Front of mind: What goal am I chasing that I've stopped wanting?
6. Coming in: What's coming that will tempt me to charge ahead without checking the road?
7. Who you are: Where am I armored up when I could soften?
8. What surrounds you: Who around me is tugging the reins away from me?
9. Hopes / fears: What do I picture happening if I took my foot off the gas, even for a week?
10. Outcome: If I keep going this way, where do I stall or crash, and which way would I turn the chariot instead?

### Watch for
Upright
- Sun: Watch for a win you can claim, and claim it.
- Moon: Watch for what you're protecting when you push this hard, and whether it's home.
- Mars: Watch for a push worth making today, and make it.
- Mercury: Watch for directions, signs and routes; the literal road may have something to say.
- Jupiter: Watch for momentum you can ride instead of create.
- Venus: Watch for a way to move forward without hardening your heart.
- Saturn: Watch for the discipline that keeps you on course.

Reversed
- Sun: Watch for winning that doesn't feel like winning.
- Moon: Watch for armor you put on out of habit.
- Mars: Watch for road rage, literal or otherwise.
- Mercury: Watch for scattered plans pulling you two ways.
- Jupiter: Watch for overconfidence in your own speed.
- Venus: Watch for pushing people away while you chase something.
- Saturn: Watch for exhaustion disguised as drive.

### Low tide
- Notice: the two sphinxes, one black and one white, and that the charioteer holds no reins.
- Become: the charioteer. How are you steering, if not with your hands?

### Lit
- Yours: You were born with a planet in Cancer, this card's sign, so protecting what you love and moving forward with feeling are a lifelong thread for you. Answer about how you've learned to steer.
- Its season: The Sun is in Cancer, about June 21 to July 22, the start of summer. Answer about what you're driving toward and what you're protecting.
- Today's weather: {planet} {is} passing through Cancer, the Chariot's sign, so the pull between pushing ahead and protecting home is live today. Answer about which way you're steering now.
- The long season: {planet} {is} moving through Cancer for months or years, slowly changing where home is and where you're headed. Answer about the direction your life is quietly taking.

### Essence
- Upright: the will that steers without reins
- Reversed: the push with no direction
- Figure: the charioteer
