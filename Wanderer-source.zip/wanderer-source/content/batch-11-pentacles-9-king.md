# Pentacles: Nine to King

Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position), 14 watch-for
cues (one per day planet, each orientation), a low-tide pointer, its lit lines, and its essence
(a short phrase per orientation and a figure).

The Nine and Ten each hold ten degrees of Virgo. The Page shares the earth quarter of the year
with the Ace. The Knight, Queen and King each hold a 30° stretch across two signs. The Eight of
Pentacles is the worked example in the foundation file.

---

## Nine of Pentacles
sky: Venus in Virgo, 10–20° Virgo · season: about Sep 2 – Sep 11 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What have I built for myself that I can stand in the middle of and enjoy right now?
2. Cross / boon: Is this hard-won independence what lets me move into what's next, or a garden wall that keeps everyone out?
3. Root: When did I first realize I could take care of myself, and how did it feel?
4. Passing away: What stretch of hard work has turned into ease, and what do I want to remember about getting here?
5. Front of mind: What comfort am I deliberately creating for myself, and who is it for?
6. Coming in: What reward, ease or leisure is arriving, and will I let myself enjoy it?
7. Who you are: Where am I self-possessed in this, at home in my own company?
8. What surrounds you: Who around me admires what I've made, and who helped make it?
9. Hopes / fears: What do I hope this independence lets me do, and what am I afraid it costs me in closeness?
10. Outcome: If I keep tending my own garden like this, what grows, and who would I let in to share it?

### Reversed
1. Central theme: Where does my independence feel lonely, or where am I leaning on others when I could stand?
2. Cross / boon: Is overwork what's in the way of enjoying it, or comfort I don't think I've earned?
3. Root: Who taught me I had to do it all myself?
4. Passing away: What appearance of having it all together am I ready to drop?
5. Front of mind: What am I buying or polishing to feel secure?
6. Coming in: Whose hand is reaching over my garden wall, and will I take it?
7. Who you are: Where am I keeping up a lifestyle that doesn't actually make me happy?
8. What surrounds you: Who around me would gladly share the garden if I opened the gate?
9. Hopes / fears: If someone saw the weeds behind my garden wall, what would I be afraid they'd think of me?
10. Outcome: If I keep the gate shut, what stays empty, and who would I invite in first?

### Watch for
Upright
- Sun: Watch for the moment you catch yourself admiring your own garden, and don't look away.
- Moon: Watch for the pleasure of your own company at home.
- Mars: Watch for something you can handle on your own, and do it with pride.
- Mercury: Watch for a well-made choice: a smart buy, a good plan.
- Jupiter: Watch for plenty you can enjoy without guilt.
- Venus: Watch for the beauty you've made around you: a garden, a room, a meal.
- Saturn: Watch for the discipline that made this ease possible, and thank it.

Reversed
- Sun: Watch for keeping up appearances.
- Moon: Watch for loneliness behind the independence.
- Mars: Watch for refusing help to prove a point.
- Mercury: Watch for justifying a purchase you didn't need.
- Jupiter: Watch for luxury standing in for joy.
- Venus: Watch for beauty you've stopped noticing.
- Saturn: Watch for working too hard to enjoy what you've built.

### Low tide
- Notice: the hooded falcon on her glove, and the small snail at her feet.
- Become: the falcon. What are you waiting for her to let you do?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Virgo), so self-reliance, earned comfort and enjoying what you've made are a lifelong thread for you. Answer about the life you've built with your own hands.
- Touching you: Venus, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so pleasure and what you value are part of today's question. Answer about a comfort you've earned.
- Its season: The Sun is in this card's ten days of the year, about September 2 to 11, late summer, with the harvest ripening. Answer about the comfort you've worked for.
- Today's weather: {planet} {is} passing through the middle ten degrees of Virgo, this card's slice of the sky, so comfort and self-reliance are in focus today. Answer about what you're enjoying, or could be, now.
- The long season: {planet} {is} moving through the middle ten degrees of Virgo for months or years, an era of building a life of your own. Answer about the independence you're slowly growing into.
- Turning: Venus, this card's planet, is retrograde (seeming to move backward), a review of love, money and what you value. Answer about a pleasure worth coming back to.

### Essence
- Upright: the garden I grew myself
- Reversed: the garden behind a locked gate
- Figure: the falcon on her glove

---

## Ten of Pentacles
sky: Mercury in Virgo, 20–30° Virgo · season: about Sep 12 – Sep 22 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What am I building that will outlast me: a home, a skill, a way of doing things?
2. Cross / boon: Is this lasting security the ground I cross into what's next on, or a family pattern I'm following without choosing it?
3. Root: What did the generations before me hand down, money, habits, stories, and which do I keep?
4. Passing away: What long chapter of building is settling into something solid?
5. Front of mind: What am I deliberately setting down roots for: a house, a fund, a tradition, a name?
6. Coming in: What lasting security, family news or inheritance is arriving?
7. Who you are: Where do I belong in a longer line, family or chosen?
8. What surrounds you: Who around me spans the generations, the old ones and the young ones, and what do they give each other?
9. Hopes / fears: What do I hope to pass on, and what am I afraid will be lost?
10. Outcome: If I keep building for the long haul like this, what's left for those after me, and what would I change so it's something they'd want?

### Reversed
1. Central theme: Where is family money, family expectation or family history weighing on me?
2. Cross / boon: Is an old family pattern what's in the way, or a fear of not having enough later?
3. Root: What did I inherit that I never asked for?
4. Passing away: What family tradition or expectation am I ready to let end with me?
5. Front of mind: What worry about the future keeps me from enjoying now?
6. Coming in: What family moment is coming where I could say "we'll do it my way this time"?
7. Who you are: Where am I living out someone else's idea of success?
8. What surrounds you: Who around me is caught in an old family story, and what would help them out?
9. Hopes / fears: If I were the one in the family who did it differently, whose disappointment am I bracing for?
10. Outcome: If the old pattern keeps running, what does it cost the next generation, and what would I change, starting with me?

### Watch for
Upright
- Sun: Watch for pride in where you come from, or in what you're starting.
- Moon: Watch for home as a place where generations gather.
- Mars: Watch for a family legacy worth defending.
- Mercury: Watch for a will, a family story, a recipe handed down.
- Jupiter: Watch for wealth of any kind you could share across generations.
- Venus: Watch for the comfort of an old house, old things, old faces.
- Saturn: Watch for the long view: what will matter in fifty years.

Reversed
- Sun: Watch for status that's more about the family name than about you.
- Moon: Watch for old family feelings coming up around money.
- Mars: Watch for a fight over an inheritance, literal or not.
- Mercury: Watch for a family secret, and whether it needs airing.
- Jupiter: Watch for spending to keep up with expectations.
- Venus: Watch for love that's tangled up with money in your family.
- Saturn: Watch for a family rule that has run its course.

### Low tide
- Notice: the two dogs at the old man's feet, and the child half-hidden behind its mother.
- Become: one of the dogs. What do you know about this family that they don't say?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Virgo), so legacy, family and building for the long run are a lifelong thread for you. Answer about what you want to leave behind.
- Touching you: Mercury, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so messages and plans are part of today's question. Answer about the family conversation you need to have.
- Its season: The Sun is in this card's ten days of the year, about September 12 to 22, the end of summer, with the harvest in. Answer about what you're building to last.
- Today's weather: {planet} {is} passing through the last ten degrees of Virgo, this card's slice of the sky, so family and long-term plans are in focus today. Answer about what you're putting in place now.
- The long season: {planet} {is} moving through the last ten degrees of Virgo for months or years, an era of building a legacy. Answer about what you're slowly passing on.
- Turning: Mercury, this card's planet, is retrograde (seeming to move backward), as it is about three times a year for three weeks, a time when old stories come back around. Answer about a family story worth retelling.

### Essence
- Upright: the house that lasts
- Reversed: the weight of family money
- Figure: the old man by the archway

---

## Page of Pentacles
sky: the earth quarter of the year, Aries through Gemini · season: about Mar 20 – Jun 20 · lit by: Its season

### Upright
1. Central theme: What practical thing have I started learning lately, and what drew me to it?
2. Cross / boon: Is this steady beginner's focus what gets me to something new, or am I studying instead of doing?
3. Root: What did I first want to be good at as a kid, and did I ever get to try?
4. Passing away: What phase of learning the basics is ending?
5. Front of mind: What am I deliberately studying or practicing right now, and what's the next lesson?
6. Coming in: What chance to learn, train or start small is arriving?
7. Who you are: Where am I the careful student in this?
8. What surrounds you: Who around me could teach me, or is learning alongside me?
9. Hopes / fears: What do I hope this new skill will open up, and what am I afraid will take too long?
10. Outcome: If I keep practicing like this, what can I do in a year, and what would I need to stop expecting of myself to keep going?

### Reversed
1. Central theme: Where am I dawdling, or stuck planning without starting?
2. Cross / boon: Is a lack of focus what's in the way, or a fear of being bad at it at first?
3. Root: What did I give up learning because it was too slow?
4. Passing away: What course, plan or hobby am I ready to admit I'm not going to do?
5. Front of mind: What am I researching endlessly instead of trying?
6. Coming in: What chance is about to land in my open hand that will turn studying into doing?
7. Who you are: Where am I ignoring the practical side of a dream?
8. What surrounds you: Who around me makes learning feel like a test?
9. Hopes / fears: If people watched me fumble the first lessons, what would I be afraid they'd decide about me?
10. Outcome: If I keep putting off the first lesson, what never gets built, and what ten-minute start would I make today?

### Watch for
Upright
- Sun: Watch for a chance to show what you're learning.
- Moon: Watch for a practical comfort you could learn to make.
- Mars: Watch for the first step of a skill, and take it.
- Mercury: Watch for a book, a class or a how-to that answers your question.
- Jupiter: Watch for a teacher, a mentor, an apprenticeship.
- Venus: Watch for the pleasure of learning with your hands.
- Saturn: Watch for the daily practice that adds up.

Reversed
- Sun: Watch for pretending to know more than you do.
- Moon: Watch for the evening you meant to practice, and whether your body wanted bed instead.
- Mars: Watch for impatience with being a beginner.
- Mercury: Watch for collecting tutorials instead of starting one.
- Jupiter: Watch for too many projects lined up at the starting line.
- Venus: Watch for buying supplies instead of using them.
- Saturn: Watch for a practice you dropped that's worth picking up again.

### Low tide
- Notice: the plowed field behind him, and how carefully he holds the coin up to look at it.
- Become: the coin he's holding. What does he see in you?

### Lit
- Its season: The Sun is in this card's quarter of the year, Aries through Gemini, about March 20 to June 20: spring, when the ground wakes up. Answer about a practical thing you'd like to start learning.

### Essence
- Upright: the coin held up and studied
- Reversed: the plan that never starts
- Figure: the page in the field

---

## Knight of Pentacles
sky: 20° Leo to 20° Virgo (the fiery part of Earth) · season: about Aug 12 – Sep 11 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What am I working at steadily right now, one day at a time?
2. Cross / boon: Is this slow, steady pace what gets me across, or am I standing still and calling it patience?
3. Root: Who first showed me the value of showing up every day?
4. Passing away: What routine has done its job, and what did it build?
5. Front of mind: What am I deliberately sticking with, even though it's slow?
6. Coming in: What steady responsibility or long project is arriving?
7. Who you are: Where am I the reliable one in this?
8. What surrounds you: Who around me counts on me, and do I count on them?
9. Hopes / fears: What do I hope steady effort will finally earn, and what am I afraid will never pay off?
10. Outcome: If I keep going at this pace, where do I arrive, and what would I change in my routine to arrive somewhere I want to be?

### Reversed
1. Central theme: Where am I stuck in a rut, or so careful I'm not moving at all?
2. Cross / boon: Is a dull routine what's in the way, or perfectionism?
3. Root: Who taught me that working harder is always the answer?
4. Passing away: What routine am I ready to change?
5. Front of mind: What task am I overthinking instead of doing?
6. Coming in: What's coming down the road that won't wait for my usual careful pace?
7. Who you are: Where am I dependable to the point of being taken for granted?
8. What surrounds you: Who around me is stalling the work, and what part of it is mine to push?
9. Hopes / fears: If I changed the route I've plowed for years, what am I afraid would go wrong?
10. Outcome: If nothing changes in the routine, what goes stale, and what one small change would I try this week?

### Watch for
Upright
- Sun: Watch for steady work that deserves to be noticed.
- Moon: Watch for the routines that comfort you.
- Mars: Watch for the effort of one more round, done well.
- Mercury: Watch for a checklist that keeps you on track.
- Jupiter: Watch for slow growth that's adding up.
- Venus: Watch for the satisfaction of a job done carefully.
- Saturn: Watch for the discipline that makes everything else easier.

Reversed
- Sun: Watch for working hard with no one noticing, and say something.
- Moon: Watch for a routine that has lost its comfort.
- Mars: Watch for stubbornness dressed up as reliability.
- Mercury: Watch for planning that never reaches the doing.
- Jupiter: Watch for taking on more work because you're the dependable one.
- Venus: Watch for no pleasure left in the work.
- Saturn: Watch for boredom, and what it's telling you.

### Low tide
- Notice: that his heavy black horse is standing perfectly still, and the plowed field in front of him.
- Become: the black horse. Why aren't you moving yet?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Leo to 20° Virgo), so reliability, steady effort and seeing things through are a lifelong thread for you. Answer about the long work you've stuck with.
- Its season: The Sun is in this card's stretch of the year, about August 12 to September 11, late summer, back-to-work season. Answer about the steady work in front of you.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Leo into Virgo, so steady work is in focus today. Answer about the task you're plodding through now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Leo into Virgo, for months or years, an era of patient effort. Answer about the long work you're slowly seeing through.

### Essence
- Upright: the slow, steady ride
- Reversed: the rut
- Figure: the black horse standing still

---

## Queen of Pentacles
sky: 20° Sagittarius to 20° Capricorn (the watery part of Earth) · season: about Dec 12 – Jan 9 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: Where am I taking good care of things right now: home, body, people, money?
2. Cross / boon: Is my practical care what gets everyone across, or am I so busy tending that I forget myself?
3. Root: Who first made a home feel warm and well-run, and what did I learn from them?
4. Passing away: What season of caretaking is changing?
5. Front of mind: What's simmering on my stove, literally or not, that I'm tending on purpose?
6. Coming in: What chance to make my home, body or finances more comfortable is arriving?
7. Who you are: Where am I resourceful and grounded in this?
8. What surrounds you: Who around me needs practical care: a meal, a hand, a ride?
9. Hopes / fears: What do I hope my care makes possible, and what am I afraid I'll neglect in myself?
10. Outcome: If I keep tending life this way, what flourishes, and what would I need to let others do so I'm cared for too?

### Reversed
1. Central theme: Where am I neglecting my own body or home while caring for everyone else?
2. Cross / boon: Is overwork what's in the way, or worry about money?
3. Root: Who taught me that my comfort comes last?
4. Passing away: What caretaking job am I ready to hand over?
5. Front of mind: What household or money worry keeps running?
6. Coming in: What's coming that will put my own care at the top of the list for once?
7. Who you are: Where am I smothering with care?
8. What surrounds you: Who around me takes my care for granted?
9. Hopes / fears: If someone else ran the house for a week while I rested, what would I be afraid of finding out?
10. Outcome: If I keep running on empty, what gives out, and what one comfort would I give myself this week?

### Watch for
Upright
- Sun: Watch for the pride of a home or a meal well made.
- Moon: Watch for nourishing food and real rest.
- Mars: Watch for a practical problem you can fix today.
- Mercury: Watch for a smart, homely tip: a recipe, a budget, a remedy.
- Jupiter: Watch for a chance to feed or shelter someone.
- Venus: Watch for comfort and beauty at home: plants, textures, warm light.
- Saturn: Watch for the steady care that keeps everything running.

Reversed
- Sun: Watch for needing to be seen as the one who does everything.
- Moon: Watch for tiredness you're ignoring.
- Mars: Watch for resentment creeping into your caretaking.
- Mercury: Watch for money worry that needs a plan, not a spiral.
- Jupiter: Watch for the extra place you set at the table when you're already running low.
- Venus: Watch for neglecting your own pleasures.
- Saturn: Watch for routines so rigid there's no room for rest.

### Low tide
- Notice: the rabbit in the corner of the garden, and the roses arching over her.
- Become: the rabbit. What have you seen her do when no one's watching?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Sagittarius to 20° Capricorn), so practical care, home and nourishment are a lifelong thread for you. Answer about the ways you've always looked after people.
- Its season: The Sun is in this card's stretch of the year, about December 12 to January 9, the dark of the year, hearth season. Answer about who and what you're caring for.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Sagittarius into Capricorn, so home and practical care are in focus today. Answer about what needs tending now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Sagittarius into Capricorn, for months or years, an era of caretaking and building comfort. Answer about the home you're slowly making.

### Essence
- Upright: the well-tended garden
- Reversed: everyone fed but her
- Figure: the rabbit in the garden

---

## King of Pentacles
sky: 20° Aries to 20° Taurus (the airy part of Earth) · season: about Apr 9 – May 10 · lit by: Yours, Its season, Today's weather, The long season

### Upright
1. Central theme: What have I built that's solid now, and how does it feel to stand on it?
2. Cross / boon: Is my security what helps everyone across, or am I so focused on the material that I've lost the point?
3. Root: Who first showed me what it looks like to provide well?
4. Passing away: What venture has matured, and what did building it teach me?
5. Front of mind: What am I deliberately growing, a business, savings, a garden, and why?
6. Coming in: What chance to look after something bigger is arriving?
7. Who you are: Where am I the steady provider in this?
8. What surrounds you: Who around me depends on what I've built, and what do they actually need?
9. Hopes / fears: What do I hope my success will let me give, and what am I afraid it has cost me?
10. Outcome: If I keep building like this, what's mine in the end, and what would I need to value besides money to call it enough?

### Reversed
1. Central theme: Where is money or status running me, or where am I not stepping up to provide?
2. Cross / boon: Is greed, mine or someone's, what's in the way, or a fear of failing?
3. Root: Who taught me that success means more?
4. Passing away: What possession or status am I ready to stop chasing?
5. Front of mind: What number do I keep checking?
6. Coming in: What offer is on its way that will put money on one side of the scale and something I love on the other?
7. Who you are: Where am I stubborn about how things must be done?
8. What surrounds you: Who around me measures everything in money?
9. Hopes / fears: If the vineyard were finally full and I still felt uneasy, what would that tell me?
10. Outcome: If I keep chasing more, what do I miss, and what would "enough" actually look like?

### Watch for
Upright
- Sun: Watch for a moment to enjoy what you've built, generously.
- Moon: Watch for the security that lets you rest.
- Mars: Watch for a sound decision that protects what you've built.
- Mercury: Watch for a good deal, fairly made.
- Jupiter: Watch for a chance to share your plenty wisely.
- Venus: Watch for enjoying the fruits: good food, good wine, a fine thing.
- Saturn: Watch for the long-term plan that keeps it all steady.

Reversed
- Sun: Watch for status that has become the point.
- Moon: Watch for money anxiety even when things are fine.
- Mars: Watch for control over money used as control over people.
- Mercury: Watch for a shortcut that isn't quite honest.
- Jupiter: Watch for more than anyone could use.
- Venus: Watch for buying things to feel worth something.
- Saturn: Watch for stinginess that's really fear.

### Low tide
- Notice: the grapevines covering his robe until you can hardly tell where he ends and the garden begins, and the castle behind him.
- Become: the grapevines. What do you know about how he grew?

### Lit
- Yours: You were born with a planet in this card's stretch of the sky (from 20° Aries to 20° Taurus), so building, providing and practical leadership are a lifelong thread for you. Answer about what you've made solid.
- Its season: The Sun is in this card's stretch of the year, about April 9 to May 10, the heart of spring, when the ground pays back. Answer about what you're building and providing.
- Today's weather: {planet} {is} passing through this card's stretch of the sky, late Aries into Taurus, so money, work and providing are in focus today. Answer about the decision you're making now.
- The long season: {planet} {is} moving through this card's stretch of the sky, late Aries into Taurus, for months or years, an era of building lasting security. Answer about what you're slowly making solid.

### Essence
- Upright: the vineyard grown and shared
- Reversed: the treasure that never feels like enough
- Figure: the king in the vines
