# Pentacles: Ace to Seven

Each card: 20 questions (10 upright, 10 reversed, one per Celtic Cross position), 14 watch-for
cues (one per day planet, each orientation), a low-tide pointer, its lit lines, and its essence
(a short phrase per orientation and a figure).

Pentacles are the suit of earth: money, work, the body, home and what's built slowly. The
questions stay practical and never about anyone's worth. The Ace holds the earth quarter of the
year (spring). The Two, Three and Four each hold ten degrees of Capricorn; the Five, Six and
Seven each hold ten degrees of Taurus.

---

## Ace of Pentacles
sky: the earth quarter of the year, Aries through Gemini · season: about Mar 20 – Jun 20 · lit by: Its season

### Upright
1. Central theme: What solid new start has been put in my hand lately, a job, a seed, a chance, and what would I plant first?
2. Cross / boon: Is this opportunity the gate from what's ending to what's next, or something I'll hold and admire without ever planting?
3. Root: What was the first thing I ever earned or grew with my own hands, and what did it teach me?
4. Passing away: What old ground has been cleared, and what's left in it that could feed something new?
5. Front of mind: What practical thing am I deliberately starting right now, and what's the first ordinary step?
6. Coming in: What offer, resource or bit of steady ground is arriving, and how will I make room for it?
7. Who you are: Where am I grounded in this, feet on the earth, and how does that feel?
8. What surrounds you: Who around me could help a new thing take root?
9. Hopes / fears: What do I hope this seed grows into, and what am I afraid will keep it from taking?
10. Outcome: If I plant this and tend it, what does it become, and what would I need to stop waiting for to get it into the ground?

### Reversed
1. Central theme: Where is an opportunity slipping through my fingers, or where am I holding out for a better one?
2. Cross / boon: Is a shaky foundation what's in the way, or a plan that's all thinking and no planting?
3. Root: What lesson about money or security did I learn early that still steers me?
4. Passing away: What plan that never got off the ground am I ready to let go?
5. Front of mind: What am I postponing until things are "more stable"?
6. Coming in: What small, plain chance is on its way that I might pass over because it's not the big one?
7. Who you are: Where am I neglecting my body or my practical life while I chase something else?
8. What surrounds you: Who around me promises more than they can deliver?
9. Hopes / fears: If I planted this and nothing came up, what would I be afraid it proved about me?
10. Outcome: If I keep waiting for the perfect start, what never grows, and what one small seed would I plant this week?

### Watch for
Upright
- Sun: Watch for a new opportunity worth stepping toward in plain view.
- Moon: Watch for something nourishing: good food, good sleep, a body cared for.
- Mars: Watch for the first practical step, and take it today.
- Mercury: Watch for an offer, a lead or a useful bit of advice.
- Jupiter: Watch for a gift or a windfall, however small, and use it well.
- Venus: Watch for the simple pleasure of something solid in your hands.
- Saturn: Watch for the foundation you're laying, and lay it well.

Reversed
- Sun: Watch for looking prosperous instead of being steady.
- Moon: Watch for skipped meals and lost sleep, and give them back.
- Mars: Watch for a rushed start that skips the groundwork.
- Mercury: Watch for a deal that sounds better than it is.
- Jupiter: Watch for spending ahead of what you have.
- Venus: Watch for comfort-buying that doesn't comfort.
- Saturn: Watch for a "someday" plan that needs a date.

### Low tide
- Notice: the arch in the hedge of roses, and the mountains you can see through it.
- Become: the archway. What's on the other side, and who walks through you first?

### Lit
- Its season: The Sun is in this card's quarter of the year, Aries through Gemini, about March 20 to June 20: spring, when the ground wakes up. Answer about what you want to plant.

### Essence
- Upright: the seed in an open hand
- Reversed: the chance slipping through fingers
- Figure: the archway in the hedge

---

## Two of Pentacles
sky: Jupiter in Capricorn, 0–10° Capricorn · season: about Dec 22 – Dec 31 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What am I juggling right now, and how many balls are actually in the air?
2. Cross / boon: Is this balancing act what gets me through the change, or am I so busy keeping things up that I can't move forward?
3. Root: When did I first learn to keep several things going at once, and who was I keeping them going for?
4. Passing away: What busy season is winding down, and what did I learn about my own rhythm?
5. Front of mind: Which two things am I deliberately keeping in motion at once, and which would tip if I looked away?
6. Coming in: What change is coming that will ask me to adjust on the fly?
7. Who you are: Where am I light on my feet in this, almost dancing?
8. What surrounds you: Who around me is juggling too, and could we share the load?
9. Hopes / fears: What do I hope to keep up with, and what am I afraid I'll drop?
10. Outcome: If I keep juggling like this, what happens when the waves get bigger, and which one thing would I put down to keep the rest steady?

### Reversed
1. Central theme: Where have I dropped something, or am I about to?
2. Cross / boon: Is overcommitment what's in the way, or a choice about priorities I keep putting off?
3. Root: Who taught me that saying yes to everything was how to be good?
4. Passing away: Which plate have I kept spinning out of habit, and can I let it stop?
5. Front of mind: What to-do list keeps reshuffling itself in my head?
6. Coming in: What's coming that will force me to choose what matters most?
7. Who you are: Where am I stretched so thin it's starting to show?
8. What surrounds you: Who around me keeps adding balls to my juggle?
9. Hopes / fears: If I let one coin fall and it hit the ground, what am I afraid would happen next?
10. Outcome: If nothing gives, what breaks, and which one thing would I drop first, on purpose?

### Watch for
Upright
- Sun: Watch for a moment you handle a lot gracefully, and let yourself enjoy it.
- Moon: Watch for the rhythm of your day, and where it needs a rest.
- Mars: Watch for the priority that needs your energy first.
- Mercury: Watch for a scheduling trick that frees up an hour.
- Jupiter: Watch for a little extra that lets you breathe: money, time, help.
- Venus: Watch for play inside the busyness.
- Saturn: Watch for the one commitment that's really holding everything together.

Reversed
- Sun: Watch for looking busy to look important.
- Moon: Watch for the exhaustion of switching between too many things.
- Mars: Watch for snapping when something slips.
- Mercury: Watch for double-booking, missed messages, crossed wires.
- Jupiter: Watch for one more yes you don't have room for.
- Venus: Watch for no time left for pleasure.
- Saturn: Watch for a bill, a deadline or a promise about to slip, and catch it.

### Low tide
- Notice: the green loop joining the two coins like a figure eight lying on its side, and the ships riding big waves behind him.
- Become: one of the ships on the waves. How does he look from out there?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Capricorn), so juggling, adapting and keeping things in balance are a lifelong thread for you. Answer about how you've learned to keep it all moving.
- Touching you: Jupiter, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so room to grow is part of today's question. Answer about what would give you more breathing room.
- Its season: The Sun is in this card's ten days of the year, about December 22 to 31, the busy, festive days around the turning of the year. Answer about what you're juggling.
- Today's weather: {planet} {is} passing through the first ten degrees of Capricorn, this card's slice of the sky, so a lot is in motion today. Answer about the balls you're keeping in the air now.
- The long season: {planet} {is} moving through the first ten degrees of Capricorn for months or years, an era of constant adjustment. Answer about the rhythm you're slowly finding.
- Turning: Jupiter, this card's planet, is retrograde (seeming to move backward), a time when growth turns inward. Answer about what you'd let fall to make room.

### Essence
- Upright: the juggle kept in the air
- Reversed: the coin about to drop
- Figure: the juggler

---

## Three of Pentacles
sky: Mars in Capricorn, 10–20° Capricorn · season: about Jan 1 – Jan 9 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What am I building with other people right now, and what's my part in it?
2. Cross / boon: Is working together what gets this across the finish, or am I waiting on others when I could act?
3. Root: Who first taught me a skill properly, and what did they see in me?
4. Passing away: What project with others is finishing, and what did I learn from working alongside them?
5. Front of mind: What skill am I deliberately putting to use, and who sees it?
6. Coming in: What collaboration, commission or chance to show my work is arriving?
7. Who you are: Where am I the craftsperson in this, the one who knows how?
8. What surrounds you: Who around me has the plan I need, or needs my hands?
9. Hopes / fears: What do I hope my work will be recognized for, and what am I afraid will be overlooked?
10. Outcome: If we keep building like this, what stands when we're done, and what would I need to share or ask for to build it better?

### Reversed
1. Central theme: Where is teamwork breaking down, or am I trying to do alone what needs other people?
2. Cross / boon: Is a clash over how to do it what's in the way, or a skill I haven't learned yet?
3. Root: What group project in the past left me doing all the work, and does that shape this?
4. Passing away: What collaboration am I ready to step out of?
5. Front of mind: What am I redoing in my head because someone else did it differently?
6. Coming in: Whose piece of the work is about to arrive that I'll have to trust without redoing?
7. Who you are: Where am I hiding my skill so I won't be asked?
8. What surrounds you: Who around me isn't being credited, and could I change that?
9. Hopes / fears: If I showed someone my half-carved arch and asked for help, what would I be afraid they'd see?
10. Outcome: If we keep pulling in different directions, what doesn't get built, and what one conversation would get us on the same page?

### Watch for
Upright
- Sun: Watch for a moment your skill is seen and appreciated.
- Moon: Watch for the comfort of working beside people you trust.
- Mars: Watch for the part of the job that's yours to do, and do it well.
- Mercury: Watch for a plan or a sketch that makes the work clearer.
- Jupiter: Watch for a chance to learn from someone more experienced.
- Venus: Watch for beauty in a well-made thing.
- Saturn: Watch for the slow, careful work that holds the whole thing up.

Reversed
- Sun: Watch for needing the credit more than needing it done well.
- Moon: Watch for feeling left out of a team.
- Mars: Watch for friction over who does what.
- Mercury: Watch for unclear instructions, and ask for clarity.
- Jupiter: Watch for taking on more than your share.
- Venus: Watch for sloppy work done to keep the peace.
- Saturn: Watch for standards so rigid no one can work with you.

### Low tide
- Notice: the plans the two visitors are holding, and the arch the mason is carving above them.
- Become: the one holding the plans. What do you see in his work that he can't?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Capricorn), so craft, teamwork and building something solid with others are a lifelong thread for you. Answer about the things you've built alongside people.
- Touching you: Mars, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so drive and effort are part of today's question. Answer about the work you're putting your hands to.
- Its season: The Sun is in this card's ten days of the year, about January 1 to 9, the first days of the new year, back to work. Answer about what you're building, and with whom.
- Today's weather: {planet} {is} passing through the middle ten degrees of Capricorn, this card's slice of the sky, so the work is in focus today. Answer about the job in front of you now.
- The long season: {planet} {is} moving through the middle ten degrees of Capricorn for months or years, an era of building something with others. Answer about the craft you're slowly mastering.
- Turning: Mars, this card's planet, is retrograde (seeming to move backward), a time to go back over work rather than rush ahead. Answer about work worth redoing properly.

### Essence
- Upright: the work built together
- Reversed: the team pulling apart
- Figure: the stonemason on the bench

---

## Four of Pentacles
sky: Sun in Capricorn, 20–30° Capricorn · season: about Jan 10 – Jan 19 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: What am I holding onto tightly right now, money, a role, a feeling, and what is it keeping safe?
2. Cross / boon: Is this security the ground I stand on to cross into what's next, or am I gripping too hard to move?
3. Root: When did I first learn I'd better hold on to what I have?
4. Passing away: What tight grip is loosening, and what did holding on protect me from?
5. Front of mind: What am I deliberately saving or protecting right now?
6. Coming in: What's heading my way that can only be caught with open hands?
7. Who you are: Where am I steady and secure in this, and where am I clutching?
8. What surrounds you: Who around me is asking for something I'm keeping to myself?
9. Hopes / fears: What do I hope my security will let me do someday, and what am I afraid will happen if I let go?
10. Outcome: If I keep holding on this tightly, what can't get in, and what would I need to believe about "enough" to loosen my grip?

### Reversed
1. Central theme: Where am I letting go too fast, or still clutching after the danger has passed?
2. Cross / boon: Is fear of loss what's in the way, or spending that has run ahead of me?
3. Root: What scarcity from long ago still lives in how I handle things?
4. Passing away: What am I ready to share, give away or stop guarding?
5. Front of mind: What money worry keeps circling?
6. Coming in: What's coming that could help me feel safe without holding so tight?
7. Who you are: Where am I controlling what isn't mine to control?
8. What surrounds you: Who around me is grasping, and how does it affect me?
9. Hopes / fears: If one of the coins slipped out of my grip, what's the real worst case, and is my fear bigger than it?
10. Outcome: If I keep swinging between clutching and letting go, where does that leave me, and what steady middle would I choose?

### Watch for
Upright
- Sun: Watch for a moment to be proud of what you've built and kept.
- Moon: Watch for what makes you feel safe, and whether it's things or people.
- Mars: Watch for what you'd grab if the house were on fire, and notice how short the list is.
- Mercury: Watch for a smart way to save or plan ahead.
- Jupiter: Watch for a chance to share a little of what you've been keeping.
- Venus: Watch for enjoying what you already have.
- Saturn: Watch for the security that's real, and rest in it.

Reversed
- Sun: Watch for status bought instead of earned.
- Moon: Watch for money anxiety showing up in your body.
- Mars: Watch for defensiveness when someone asks for something.
- Mercury: Watch for tallying and re-tallying.
- Jupiter: Watch for spending to feel better.
- Venus: Watch for holding back affection the way you'd hold back money.
- Saturn: Watch for a rule about money that has outlived its reason.

### Low tide
- Notice: the coin balanced on his crown and the two under his feet, and the city behind him.
- Become: one of the coins under his feet. What's it like down there, and what would you say if he moved?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Capricorn), so security, saving and holding on are a lifelong thread for you. Answer about what you've learned about keeping things safe.
- Touching you: The Sun, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few days, so attention and energy are on part of your life. Answer about what you're protecting, and why.
- Its season: The Sun is in this card's ten days of the year, about January 10 to 19, deep winter, when people take stock of what they have. Answer about what you're holding onto.
- Today's weather: {planet} {is} passing through the last ten degrees of Capricorn, this card's slice of the sky, so security is on your mind today. Answer about what you're keeping safe now.
- The long season: {planet} {is} moving through the last ten degrees of Capricorn for months or years, an era of building security. Answer about what you're slowly learning to hold, and to release.

### Essence
- Upright: the coin held close
- Reversed: the grip that won't open
- Figure: the man holding on

---

## Five of Pentacles
sky: Mercury in Taurus, 0–10° Taurus · season: about Apr 20 – Apr 29 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: Where am I out in the cold right now, short of money, health, help or welcome?
2. Cross / boon: Is this hard stretch the way through to something better, or am I walking past the door that would let me in?
3. Root: What hard time in my past taught me how to get through lean seasons?
4. Passing away: What lean season is finally easing?
5. Front of mind: What am I deliberately getting through right now, one step at a time?
6. Coming in: What help is closer than I think, and what would it take to ask?
7. Who you are: Where am I hardest on myself for struggling?
8. What surrounds you: Who around me is out in the cold with me, and could we walk together?
9. Hopes / fears: What do I hope will change, and what am I afraid will stay this hard?
10. Outcome: If I keep walking past the lit window, what do I miss, and what would I need to stop believing about asking for help to go in?

### Reversed
1. Central theme: Where is the cold starting to lift, or where am I finally letting someone help?
2. Cross / boon: Is pride what's in the way, or a door I've been told isn't for me?
3. Root: When did I first learn to hide that I was struggling?
4. Passing away: What hardship is ending, and what did it teach me about what I really need?
5. Front of mind: What worry about getting by keeps running in my head?
6. Coming in: What support is arriving, and how will I let it in?
7. Who you are: Where am I already warmer than I let myself feel?
8. What surrounds you: Who around me helped when I was in the cold, and have I thanked them?
9. Hopes / fears: When the next cold spell comes, what do I want to remember about how I got through this one?
10. Outcome: If I keep coming in from the cold, where do I land, and what's one way I could help someone else in?

### Watch for
Upright
- Sun: Watch for an "I'm fine" you could trade for "it's been a hard month."
- Moon: Watch for what your body needs to get through: warmth, food, sleep.
- Mars: Watch for the nerve it takes to ask for help, and ask.
- Mercury: Watch for a resource you didn't know about: a program, a contact, a tip.
- Jupiter: Watch for generosity offered, and take it without shame.
- Venus: Watch for warmth that costs nothing: a blanket, a library, sun on a bench.
- Saturn: Watch for the patience that gets you through, step by step.

Reversed
- Sun: Watch for the first sign of things getting better.
- Moon: Watch for warmth returning to your body and your days.
- Mars: Watch for the first errand that doesn't feel like a mountain.
- Mercury: Watch for news that eases a worry.
- Jupiter: Watch for a chance to pass on help you once received.
- Venus: Watch for welcome where you expected to be turned away.
- Saturn: Watch for a hard lesson that has become steady ground.

### Low tide
- Notice: the lit window above them, and that neither of them is looking up.
- Become: the lit window. What would you say if they looked up?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the first ten degrees of Taurus), so hard times, lean seasons and finding help are a lifelong thread for you. Answer about how you've come through the cold before.
- Touching you: Mercury, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so messages and asking are part of today's question. Answer about the help you could ask for.
- Its season: The Sun is in this card's ten days of the year, about April 20 to 29, mid-spring, when some things are blooming and others haven't yet. Answer about what still feels lean.
- Today's weather: {planet} {is} passing through the first ten degrees of Taurus, this card's slice of the sky, so a worry about getting by is close today. Answer about where you need help now.
- The long season: {planet} {is} moving through the first ten degrees of Taurus for months or years, an era of hardship and resilience. Answer about how you're slowly getting through.
- Turning: Mercury, this card's planet, is retrograde (seeming to move backward), as it is about three times a year for three weeks, a time to look again at what you've missed. Answer about help you've overlooked.

### Essence
- Upright: out in the cold, near a lit window
- Reversed: coming in from the cold
- Figure: the lit window

---

## Six of Pentacles
sky: Moon in Taurus, 10–20° Taurus · season: about Apr 30 – May 9 · lit by: Yours, Touching you, Its season, Today's weather, The long season

### Upright
1. Central theme: Where am I giving or receiving right now, and how does it feel on each side?
2. Cross / boon: Is this exchange what helps everyone across, or is the balance tipping one way?
3. Root: Who first gave to me when I needed it, and how did it feel to receive?
4. Passing away: What season of giving, or of being helped, is ending?
5. Front of mind: What am I deliberately sharing right now, and with whom?
6. Coming in: What help or generosity is arriving, and can I take it gracefully?
7. Who you are: Where am I the one holding the scales in this?
8. What surrounds you: Who around me is asking, openly or not?
9. Hopes / fears: What do I hope my generosity does for others, and what am I afraid it says about me?
10. Outcome: If I keep giving and receiving this way, what grows between us, and what would I change so it stays fair both ways?

### Reversed
1. Central theme: Where is giving coming with strings attached, mine or someone else's?
2. Cross / boon: Is an imbalance of power what's in the way, or my trouble receiving?
3. Root: Who gave to me in a way that made me feel small?
4. Passing away: What uneven exchange am I ready to end?
5. Front of mind: What am I keeping score on in my head?
6. Coming in: What kindness is on its way that I'll have to take without evening the scales right away?
7. Who you are: Where am I giving so I'll be needed?
8. What surrounds you: Who around me takes more than they give, and where's my limit?
9. Hopes / fears: If I were the one kneeling with an open hand, what would I be afraid it said about me?
10. Outcome: If the scales stay tipped, what does it cost both sides, and what one fair change would I make?

### Watch for
Upright
- Sun: Watch for a chance to give openly and warmly.
- Moon: Watch for care given or received at home.
- Mars: Watch for someone who needs you to stand up for what's fair.
- Mercury: Watch for a fair trade, and make it.
- Jupiter: Watch for an easy way to be generous today.
- Venus: Watch for the sweetness of receiving a kindness.
- Saturn: Watch for generosity you can keep up, not just a burst.

Reversed
- Sun: Watch for giving that's really for show.
- Moon: Watch for giving more than you have left.
- Mars: Watch for resentment after a favor.
- Mercury: Watch for fine print on a gift.
- Jupiter: Watch for overgiving to feel important.
- Venus: Watch for refusing kindness because it feels like owing.
- Saturn: Watch for a debt, of money or of favor, that needs settling.

### Low tide
- Notice: the scales in his left hand, and the two kneeling figures, only one of whom is receiving.
- Become: the scales. What are you weighing, and is it fair?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the middle ten degrees of Taurus), so generosity, giving and receiving, and fairness are a lifelong thread for you. Answer about what you've learned on both sides of the scales.
- Touching you: The Moon, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), which lasts a few hours, so needs and care are near the surface. Answer about what you need, or can give, today.
- Its season: The Sun is in this card's ten days of the year, about April 30 to May 9, full spring, when gardens fill and there's plenty to share. Answer about what you have to give.
- Today's weather: {planet} {is} passing through the middle ten degrees of Taurus, this card's slice of the sky, so giving and receiving are close today. Answer about an exchange happening now.
- The long season: {planet} {is} moving through the middle ten degrees of Taurus for months or years, an era of learning fair exchange. Answer about the balance you're slowly finding.

### Essence
- Upright: the coins passed fairly
- Reversed: the gift with strings
- Figure: the scales

---

## Seven of Pentacles
sky: Saturn in Taurus, 20–30° Taurus · season: about May 10 – May 20 · lit by: Yours, Touching you, Its season, Today's weather, The long season, Turning

### Upright
1. Central theme: What have I been tending for a while, and what can I see growing so far?
2. Cross / boon: Is this pause to look over my work the bridge to the next stage, or am I leaning on the hoe too long?
3. Root: What was the first long, slow thing I ever stuck with, and what did it teach me about waiting?
4. Passing away: What season of hard work is over, and what did it yield?
5. Front of mind: What am I deliberately investing in for the long run?
6. Coming in: What harvest is coming, slowly, and how will I know when it's ripe?
7. Who you are: Where am I patient in this, and where am I just tired?
8. What surrounds you: Who around me has been growing something alongside me?
9. Hopes / fears: What do I hope this effort will add up to, and what am I afraid it won't?
10. Outcome: If I keep tending this, what will it yield, and what would I need to change in how I measure progress to keep going?

### Reversed
1. Central theme: Where am I impatient for results, or pouring effort into something that isn't growing?
2. Cross / boon: Is a lack of results what's in the way, or my unwillingness to change the plan?
3. Root: What early disappointment taught me hard work doesn't always pay?
4. Passing away: What investment of time or money am I ready to stop making?
5. Front of mind: What am I checking over and over, as if checking would make it grow faster?
6. Coming in: What's coming that will show me whether to keep going or change course?
7. Who you are: Where am I working hard without stopping to look at what's working?
8. What surrounds you: Who around me is pushing me to give up, or to keep going past sense?
9. Hopes / fears: If I looked honestly at the vine and saw it hasn't grown the way I hoped, what would I be afraid to admit?
10. Outcome: If I keep going this way, what does it cost, and what would I plant instead?

### Watch for
Upright
- Sun: Watch for a sign that your effort is starting to show.
- Moon: Watch for tiredness that wants rest, not more work.
- Mars: Watch for the one bit of tending that matters most today.
- Mercury: Watch for a progress report: numbers, notes, a check-in.
- Jupiter: Watch for growth bigger than you expected.
- Venus: Watch for the pleasure of watching something grow.
- Saturn: Watch for the slow work that's quietly paying off.

Reversed
- Sun: Watch for wanting credit before the harvest is in.
- Moon: Watch for discouragement, and be gentle with it.
- Mars: Watch for frustration at slow progress.
- Mercury: Watch for peeking over at someone else's field to see if theirs is growing faster.
- Jupiter: Watch for planting more than you can tend.
- Venus: Watch for joyless effort.
- Saturn: Watch for money or time already spent keeping you from changing course.

### Low tide
- Notice: the seven coins growing on the vine like fruit, and the way he rests his chin on the hoe.
- Become: the vine. What do you want him to know about how you grow?

### Lit
- Yours: You were born with a planet in this card's slice of the sky (the last ten degrees of Taurus), so patience, long-term effort and waiting for the harvest are a lifelong thread for you. Answer about the slow things you've grown.
- Touching you: Saturn, this card's planet, is making an aspect to your birth chart (a meaningful angle to one of the planets you were born with), so time and the long haul are part of today's question. Answer about what you're slowly growing.
- Its season: The Sun is in this card's ten days of the year, about May 10 to 20, late spring, when the first crops are only half-grown. Answer about what's growing slowly.
- Today's weather: {planet} {is} passing through the last ten degrees of Taurus, this card's slice of the sky, so progress is on your mind today. Answer about what's growing, and what isn't, now.
- The long season: {planet} {is} moving through the last ten degrees of Taurus for months or years, an era of slow growth. Answer about the long investment of your life.
- Turning: Saturn, this card's planet, is retrograde (seeming to move backward), as it is for about four and a half months each year, a time to look over what you've planted. Answer about whether to keep tending, or plant something else.

### Essence
- Upright: the slow harvest
- Reversed: the waiting gone sour
- Figure: the man leaning on the hoe
